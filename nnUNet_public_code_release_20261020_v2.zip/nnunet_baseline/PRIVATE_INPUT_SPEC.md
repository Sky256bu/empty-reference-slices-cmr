# Controlled inputs required by the preserved nnU-Net scripts

This document describes file interfaces without supplying patient rows. The original v3 audit generator, common module and configuration are supplied under `input_audit_source/`, with a separate README describing exact source hashes, controlled inputs, default writing behavior and read-only verification. The five generated CSVs and summary JSON remain private; the four prerequisites listed below are a subset of those six outputs. All five CSV hashes and 15 selected summary fields were reconstructed on the controlled system without changing the original outputs. This document is an inspection aid, not a replacement dataset: the preserved readers require exact hashes, counts, roles and path relationships. Inventing structurally similar rows will not reproduce the experiment.

## Required working-root layout

```text
BASE/
  mnms/
    seg_lv/
      manifest_mnms2.csv
      all/<relative image, GT and propagated-label PNG paths>
      scope_control_v3_zero_gpu_audit/
        input_audit_summary_v3.json
        patient_partitions_v3.csv
        label_scope_audit_v3.csv
        input_file_manifest_v3.csv
    MnM2/dataset/<key>/
      <key>_SA_ED.nii.gz
      <key>_SA_ES.nii.gz
      <key>_SA_ED_gt.nii.gz
      <key>_SA_ES_gt.nii.gz
  nnunet-2.8.1-venv/bin/<python and nnU-Net CLI programs>
```

Image/GT/propagated-mask paths in the slice manifest are relative to `mnms/seg_lv/all/`. Absolute paths, traversal, empty relative paths, and resolution outside that root are rejected where checked. By contrast, `input_file_manifest_v3.csv` records original **absolute** paths. Changing `BASE` alone does not rewrite or authenticate those records: relocation requires a separately documented provenance-preserving process and cannot silently be presented as the same historical audit.

The raw-image NIfTI files are needed for full pixel/export auditing; the GT NIfTI files are needed for volume reconstruction and GT-to-PNG auditing. The audit compares the GT NIfTI's LV label `1` with the exported binary masks. Image masks must not be inferred from identifier names or substituted from another export.

## Source tables: fields consumed by the readers

These are consumed fields, not a declaration that historical files contain no other columns. Preserve the historical files intact.

| File | Fields read | Interpretation and constraints |
|---|---|---|
| `manifest_mnms2.csv` | `key`, `vendor`, `phase`, `z`, `disease`, `img`, `gt`, `pf`, `gt_px`, `is_anchor`, `in_lvspan` | Patient key, scanner vendor, ED/ES phase, zero-based slice index; `disease` is additionally required by the recovered input-audit generator for patient-level disease stratification; paths relative to `all/`; GT foreground count; anchor/span indicators. File SHA-256 is fixed to `fd9f2eba74f0adba7eff7a11c80e856d49e9aebcdcda17920f4e491d2e7f7a24`. External staging expects 8,128 total rows. |
| `patient_partitions_v3.csv` | `key`, `block_id`, `role` | 219 unique SIEMENS patients; ten training keys in each requested block; 43 keys with `role=validation`; training/validation separation is checked. Do not reconstruct a patient split from public case hashes. |
| `label_scope_audit_v3.csv` | `block_id`, `arm`, `role`, `block_key_sha256`, `gt_rows`, `pf_rows`, `label_rows` | A unique requested unit/arm row with `role=formal`; training-key digest and label counts must agree with the selected manifest rows. |
| `input_file_manifest_v3.csv` | `absolute_path`, `roles`, `sha256` | Frozen content hashes for controlled inputs. External reader role strings include `external_Philips:image`, `external_Philips:gt`, `external_GE:image`, `external_GE:gt`, and external `:volume_gt:` roles. Absolute path strings are part of the lookup. |
| `input_audit_summary_v3.json` | `status`, `manifest_sha256`, `outputs[filename].sha256`, `external_patient_counts` | `status=PASS`, the fixed manifest digest, hashes of the three audit CSVs, and external counts `{"Philips":88,"GE":53}`. A `PASS` label without matching bytes is insufficient. |

Numeric patient keys are normalized to zero-padded three-character strings by the preserved `norm_key` helper. ED/ES labels come from the supplied dataset filenames and manifests. Technical agreement with those labels is not independent clinical phase-selection review.

Source masks must decode as binary 0/255 grayscale PNGs, with image/label dimensions matching. Dataset preparation copies the image bytes and converts masks to 0/1 labels for nnU-Net. It generates case IDs from the first 20 hexadecimal characters of SHA-256 of `key|phase|z`, prefixed `case_`. These deterministic case labels are pseudonymous, not an assurance that individual-level files are safe for public release.

External input checks require 141 unique patients, 3,072 slices in total, 1,536 ED and 1,536 ES slices, contiguous zero-based z indices, matching ED/ES z sets, and no overlap with the SIEMENS partition. Philips and GE contribute 1,796 and 1,276 slices, respectively. All slices, including empty-GT slices, remain in the frozen export.

## Generated controlled artifacts

| Stage | Controlled outputs and requirements |
|---|---|
| Raw paired datasets | `nnUNet_raw/Dataset901_MnMS2_u00_B` through `Dataset920_MnMS2_u09_Cneg`; each has `dataset.json`, `imagesTr`, `labelsTr`, `splits_final.json`, `preflight_summary.json`, and `case_map_PRIVATE.csv`. Dataset ID is `901 + 2*unit_index`, with one added for Cneg. `case_map_PRIVATE.csv` fields: `case_id,role,patient_key,phase,z,vendor,label_source`. The fixed split is a one-element JSON list with `train` and `val` case-ID arrays. Both training and validation cases are stored under `imagesTr`/`labelsTr`; the fixed split governs use. |
| Planning reference | Raw `Dataset900_MnMS2_CommonPlan_u00_GT` includes only 101 training GT cases plus `planning_scope.json`. Its preprocessed reference directory requires exact `nnUNetPlans.json` and the private `dataset_fingerprint.json`; the latter's public hash is `cde585fbb93653bcc9b7c9f5454b8e9372da2b184fa40381748fad8354138671`. The actual fingerprint and case-level arrays are not distributed. |
| Target preprocessing | Per-dataset moved shared plans, copied fixed split/fingerprint, `planning_provenance.json`, preprocessed `.b2nd`, segmentation `.b2nd`, property `.pkl`, copied GT PNGs, and preprocessing audits. Plan copying alone is insufficient. |
| Formal models | `nnUNet_results_formal/rep00/Dataset.../nnUNetTrainer__nnUNetPlansSharedU00GT__2d/fold_0/`, with `checkpoint_final.pth` at epoch 1000 and complete fixed-validation outputs; matching manifests under the repeat's `_audit/` directory. The launcher verifies content and prior PASS records. Only trusted author-generated checkpoints should be loaded. |
| External staging | `nnUNet_external_input/imagesTs/<case_id>_0000.png`, `stage_audit.json`, and private `private_map.csv`. Mapping fields: `case_id,patient_key,phase,z,vendor,image_rel,gt_rel,source_image_sha256,source_gt_sha256`. GT is not copied into inference input. |
| External predictions | `nnUNet_external_predictions/rep00/` model output directories and matching `_audit` records, with 3,072 checked PNG masks per model. |
| External scoring | `nnUNet_external_evaluation/rep00/public/` reviewed aggregates and `private/slice_metrics_PRIVATE.csv`, `private/case_metrics_PRIVATE.csv`, `private/paired_case_metrics_PRIVATE.csv`. Full auditing requires these private metric tables as well as predictions and source NIfTI/PNG files. The public `evaluation_audit.json` hashes the three private CSVs and three public aggregate CSVs. Retain the generated output schema and audit hashes; do not manually fabricate missing tables. |

The same 141 patients recur across ten units and two arms: 2,820 model–patient evaluations and 61,440 model–slice predictions. Do not describe either total as a count of independent subjects.

## Physical-unit limitation

The frozen evaluator computes the voxel factor as `abs(det(affine[:3,:3])) / 1000`. Current source headers have unknown spatial units; no public plan or input schema repairs that omission. Retaining this convention permits stored-metric parity checks but does not certify mL. The full v2 audit requires `--allow-unknown-spatial-units` to make that conditional interpretation explicit; known non-mm declarations are rejected. Do not relabel headers as mm, rescale outputs, clip EF, or exclude failures and then call the result the unchanged frozen experiment.

Dataset access, permitted redistribution, and controlled artifact transfer must follow the applicable data agreements. This package supplies no individual-level transfer or publication authorization.
