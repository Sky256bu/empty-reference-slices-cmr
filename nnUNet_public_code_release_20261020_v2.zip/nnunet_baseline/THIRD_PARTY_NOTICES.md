# Third-party attribution

The `reader_method_source` field in `results/full_audit/rep00_units_provenance_followup_20261020.json` reproduces the `NaturalImage2DIO.read_images` method from nnU-Net v2.8.1. That method is unmodified; its surrounding JSON is an audit record created by this study. nnU-Net is copyright 2019, Division of Medical Image Computing, German Cancer Research Center (DKFZ), Heidelberg, Germany, and distributed under Apache License 2.0. The upstream license is supplied in `licenses/LICENSE-nnUNet-Apache-2.0.txt`; this third-party excerpt is not relicensed under the study's MIT license.

Upstream source: https://github.com/MIC-DKFZ/nnUNet/blob/v2.8.1/nnunetv2/imageio/natural_image_reader_writer.py

Upstream license: https://github.com/MIC-DKFZ/nnUNet/blob/v2.8.1/LICENSE

The package calls installed nnU-Net, PyTorch and other dependencies, and does not redistribute their full implementations. Their own licenses continue to apply. ACDC and M&Ms-2 datasets and weights are not included or licensed by this package.
