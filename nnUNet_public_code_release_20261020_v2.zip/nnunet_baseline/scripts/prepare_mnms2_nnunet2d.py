#!/usr/bin/env python3
"""Prepare one paired M&Ms-2 unit/arm for a 2D nnU-Net sensitivity experiment.

Default is a read-only preflight. --write creates a new nnU-Net raw dataset without
altering the original export, frozen code, source masks, or patient partitions.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import shutil
from collections import Counter
from pathlib import Path


MANIFEST_SHA256 = "fd9f2eba74f0adba7eff7a11c80e856d49e9aebcdcda17920f4e491d2e7f7a24"
UNITS = tuple(f"u{i:02d}" for i in range(10))


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def norm_key(value: object) -> str:
    text = str(value).strip()
    try:
        return str(int(float(text))).zfill(3)
    except ValueError:
        return text


def key_sha256(keys: set[str]) -> str:
    return hashlib.sha256(",".join(sorted(keys)).encode("utf-8")).hexdigest()


def inside(base: Path, relative: str) -> Path:
    """Reject absolute paths and traversal before touching a source file."""
    rel = Path(relative)
    if rel.is_absolute() or ".." in rel.parts or not relative.strip():
        raise ValueError("Source manifest contains an unsafe or empty relative path")
    result = (base / rel).resolve()
    if not result.is_relative_to(base.resolve()):
        raise ValueError("Source file resolves outside the slice-export root")
    return result


def case_id(key: str, phase: str, z: int) -> str:
    token = f"{key}|{phase}|{z}".encode("utf-8")
    return "case_" + hashlib.sha256(token).hexdigest()[:20]


def build_plan(mroot: Path, audit_dir: Path, unit: str, arm: str) -> tuple[list[dict], dict]:
    manifest_path = mroot / "manifest_mnms2.csv"
    partition_path = audit_dir / "patient_partitions_v3.csv"
    scope_path = audit_dir / "label_scope_audit_v3.csv"
    physical_path = audit_dir / "input_file_manifest_v3.csv"
    audit_path = audit_dir / "input_audit_summary_v3.json"
    for path in (manifest_path, partition_path, scope_path, physical_path, audit_path):
        if not path.is_file():
            raise FileNotFoundError(path)
    if sha256(manifest_path) != MANIFEST_SHA256:
        raise RuntimeError("The M&Ms-2 manifest differs from the frozen formal input")
    audit = json.loads(audit_path.read_text(encoding="utf-8"))
    if audit.get("status") != "PASS" or audit.get("manifest_sha256") != MANIFEST_SHA256:
        raise RuntimeError("Input audit is not PASS or cites another manifest")
    for path in (partition_path, scope_path, physical_path):
        declared = audit.get("outputs", {}).get(path.name, {}).get("sha256")
        if declared != sha256(path):
            raise RuntimeError(f"Audit hash mismatch: {path.name}")

    partition = read_csv(partition_path)
    if len(partition) != 219:
        raise RuntimeError("Expected 219 SIEMENS patients in the partition table")
    seen_keys: set[str] = set()
    train_keys: set[str] = set()
    val_keys: set[str] = set()
    for row in partition:
        key = norm_key(row["key"])
        if key in seen_keys:
            raise RuntimeError("Duplicate patient in partition table")
        seen_keys.add(key)
        if row["block_id"] == unit:
            train_keys.add(key)
        if row["role"] == "validation":
            val_keys.add(key)
    if len(train_keys) != 10 or len(val_keys) != 43 or train_keys & val_keys:
        raise RuntimeError("The requested unit/validation patient split does not close")

    scopes = [r for r in read_csv(scope_path) if r["block_id"] == unit and r["arm"] == arm]
    if len(scopes) != 1 or scopes[0]["role"] != "formal":
        raise RuntimeError("The audited formal label-scope row is missing or ambiguous")
    scope = scopes[0]
    if key_sha256(train_keys) != scope["block_key_sha256"]:
        raise RuntimeError("Training patient hash differs from the label-scope audit")

    records: list[dict] = []
    case_ids: set[str] = set()
    train_counts: Counter[str] = Counter()
    val_patients_seen: set[str] = set()
    train_patients_seen: set[str] = set()
    image_root = mroot / "all"
    for row in read_csv(manifest_path):
        key = norm_key(row["key"])
        if key not in train_keys and key not in val_keys:
            continue
        if "siemens" not in row["vendor"].lower():
            raise RuntimeError("Non-SIEMENS patient entered training or validation")
        phase = row["phase"].lower()
        if phase not in {"ed", "es"}:
            raise RuntimeError("Unexpected cardiac phase")
        z = int(row["z"])
        role = "train" if key in train_keys else "val"
        if role == "train":
            train_patients_seen.add(key)
            anchor_or_outside = int(row["is_anchor"]) == 1 or int(row["in_lvspan"]) == 0
            if anchor_or_outside:
                label_kind, label_rel = "gt", row["gt"]
            elif arm == "B":
                label_kind, label_rel = "pf", row["pf"]
            else:
                continue  # Cneg has no supervision on internal non-anchor slices.
            train_counts[label_kind] += 1
        else:
            val_patients_seen.add(key)
            label_kind, label_rel = "gt", row["gt"]

        cid = case_id(key, phase, z)
        if cid in case_ids:
            raise RuntimeError("Duplicate or colliding patient/phase/slice case identifier")
        case_ids.add(cid)
        image = inside(image_root, row["img"])
        label = inside(image_root, label_rel)
        if not image.is_file() or not label.is_file():
            raise FileNotFoundError("A selected image or label is absent from the cloud export")
        records.append({
            "case_id": cid, "role": role, "patient_key": key,
            "phase": phase, "z": z, "vendor": row["vendor"],
            "label_source": label_kind, "image": image, "label": label,
        })
    if train_patients_seen != train_keys or val_patients_seen != val_keys:
        raise RuntimeError("Some partition patients have no selected exported slices")
    if (
        train_counts["gt"] != int(scope["gt_rows"])
        or train_counts["pf"] != int(scope["pf_rows"])
        or sum(train_counts.values()) != int(scope["label_rows"])
    ):
        raise RuntimeError("Training label counts differ from the frozen audit")
    if arm == "Cneg" and train_counts["pf"]:
        raise RuntimeError("Cneg unexpectedly received pseudo-labels")

    summary = {
        "unit": unit, "arm": arm,
        "train_patients": len(train_keys), "validation_patients": len(val_keys),
        "train_gt_slices": train_counts["gt"],
        "train_pseudo_slices": train_counts["pf"],
        "validation_gt_slices": sum(r["role"] == "val" for r in records),
        "manifest_sha256": MANIFEST_SHA256,
        "patient_partition_sha256": sha256(partition_path),
        "label_scope_audit_sha256": sha256(scope_path),
    }
    return records, summary


def write_dataset(records: list[dict], summary: dict, output_root: Path, dataset_id: int) -> Path:
    try:
        import numpy as np
    except ImportError as exc:
        raise RuntimeError("Writing PNG labels requires numpy in the cloud environment") from exc
    try:
        import cv2
    except ImportError:
        cv2 = None
        try:
            from PIL import Image
        except ImportError as exc:
            raise RuntimeError("Writing PNG labels requires cv2 or Pillow") from exc

    def read_grayscale(path: Path):
        if cv2 is not None:
            return cv2.imread(str(path), cv2.IMREAD_GRAYSCALE)
        with Image.open(path) as source:
            return np.asarray(source.convert("L"))

    def save_binary(path: Path, label) -> None:
        binary = (label > 127).astype(np.uint8)
        if cv2 is not None:
            if not cv2.imwrite(str(path), binary):
                raise OSError("Could not write a converted 0/1 label PNG")
        else:
            Image.fromarray(binary, mode="L").save(path)

    output_root = output_root.expanduser().resolve()
    output_root.mkdir(parents=True, exist_ok=True)
    name = f"Dataset{dataset_id:03d}_MnMS2_{summary['unit']}_{summary['arm']}"
    destination = output_root / name
    if destination.exists():
        raise FileExistsError(f"Dataset already exists; refusing to overwrite: {destination}")
    images = destination / "imagesTr"
    labels = destination / "labelsTr"
    images.mkdir(parents=True)
    labels.mkdir()
    mapping_path = destination / "case_map_PRIVATE.csv"
    train_ids: list[str] = []
    val_ids: list[str] = []
    fields = ["case_id", "role", "patient_key", "phase", "z", "vendor", "label_source"]
    with mapping_path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for record in records:
            cid = record["case_id"]
            image = read_grayscale(record["image"])
            label = read_grayscale(record["label"])
            if image is None or label is None or image.shape != label.shape:
                raise RuntimeError("Selected image/label cannot be read or has mismatched dimensions")
            if not set(np.unique(label)).issubset({0, 255}):
                raise RuntimeError("Source mask contains unexpected values; expected binary 0/255")
            shutil.copy2(record["image"], images / f"{cid}_0000.png")
            save_binary(labels / f"{cid}.png", label)
            writer.writerow({field: record[field] for field in fields})
            (train_ids if record["role"] == "train" else val_ids).append(cid)

    dataset_json = {
        "channel_names": {"0": "MRI"},
        "labels": {"background": 0, "LV": 1},
        "numTraining": len(records),
        "file_ending": ".png",
    }
    (destination / "dataset.json").write_text(
        json.dumps(dataset_json, indent=2) + "\n", encoding="utf-8"
    )
    # nnU-Net reads this split from the preprocessed dataset directory. Keep the
    # patient-wise split here for the subsequent preparation/training stage.
    (destination / "splits_final.json").write_text(
        json.dumps([{"train": sorted(train_ids), "val": sorted(val_ids)}], indent=2) + "\n",
        encoding="utf-8",
    )
    (destination / "preflight_summary.json").write_text(
        json.dumps(summary, indent=2) + "\n", encoding="utf-8"
    )
    return destination


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mroot", type=Path, default=Path("/root/autodl-tmp/mnms/seg_lv"))
    parser.add_argument("--audit-dir", type=Path)
    parser.add_argument("--unit", choices=UNITS, required=True)
    parser.add_argument("--arm", choices=("B", "Cneg"), required=True)
    parser.add_argument("--output-root", type=Path, default=Path("/root/autodl-tmp/nnUNet_raw"))
    parser.add_argument("--dataset-id", type=int, help="Required with --write; use a fresh nnU-Net ID")
    parser.add_argument("--write", action="store_true", help="Create a new dataset after preflight")
    args = parser.parse_args()
    audit_dir = args.audit_dir or args.mroot / "scope_control_v3_zero_gpu_audit"
    records, summary = build_plan(args.mroot, audit_dir, args.unit, args.arm)
    print(json.dumps(summary, indent=2))
    if args.write:
        if args.dataset_id is None or not 1 <= args.dataset_id <= 999:
            parser.error("--write requires --dataset-id from 1 to 999")
        if args.output_root.expanduser().resolve().is_relative_to(args.mroot.expanduser().resolve()):
            parser.error("--output-root must be outside the source export directory")
        destination = write_dataset(records, summary, args.output_root, args.dataset_id)
        print(f"Created: {destination}")
        print("Keep case_map_PRIVATE.csv on the cloud; do not publish it.")
    else:
        print("Preflight passed. No files were written.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
