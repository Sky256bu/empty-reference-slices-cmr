#!/usr/bin/env python3
"""Read-only verification of one prepared M&Ms-2 B/Cneg nnU-Net 2D pair.

Checks every prepared PNG plus the private case maps. Prints counts and status only;
never prints patient identifiers or individual image names.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import Counter
from pathlib import Path


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load_png(path: Path) -> tuple[tuple[int, int], set[int], int]:
    try:
        from PIL import Image
    except ImportError:
        Image = None
    if Image is not None:
        with Image.open(path) as source:
            if source.format != "PNG":
                raise RuntimeError("An expected PNG file has another format")
            bands = len(source.getbands())
            if bands != 1:
                raise RuntimeError("Expected one grayscale channel per image/mask")
            import numpy as np

            values = np.asarray(source)
            return values.shape, set(int(v) for v in np.unique(values)), bands
    try:
        import cv2
        import numpy as np
    except ImportError as exc:
        raise RuntimeError("Verification requires Pillow or cv2, plus numpy") from exc
    values = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    if values is None or values.ndim != 2:
        raise RuntimeError("Expected one readable grayscale PNG channel")
    return values.shape, set(int(v) for v in np.unique(values)), 1


def load_arm(directory: Path, arm: str, unit: str) -> tuple[dict, dict[str, dict]]:
    if not directory.is_dir():
        raise FileNotFoundError(directory)
    meta = json.loads((directory / "dataset.json").read_text(encoding="utf-8"))
    preflight = json.loads((directory / "preflight_summary.json").read_text(encoding="utf-8"))
    splits = json.loads((directory / "splits_final.json").read_text(encoding="utf-8"))
    if preflight.get("unit") != unit or preflight.get("arm") != arm:
        raise RuntimeError("Prepared dataset identity differs from the requested unit/arm")
    if meta.get("labels") != {"background": 0, "LV": 1} or meta.get("file_ending") != ".png":
        raise RuntimeError("Unexpected nnU-Net label definition or file type")
    if meta.get("channel_names") != {"0": "MRI"}:
        raise RuntimeError("Unexpected image-channel definition")

    with (directory / "case_map_PRIVATE.csv").open("r", encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))
    by_id = {row["case_id"]: row for row in rows}
    if len(by_id) != len(rows) or len(rows) != int(meta["numTraining"]):
        raise RuntimeError("Case map contains duplicates or differs from dataset.json")
    train = {cid for cid, row in by_id.items() if row["role"] == "train"}
    val = {cid for cid, row in by_id.items() if row["role"] == "val"}
    if len(train) + len(val) != len(by_id) or train & val:
        raise RuntimeError("Case map has an invalid train/validation role")
    if len(splits) != 1 or set(splits[0].get("train", [])) != train or set(splits[0].get("val", [])) != val:
        raise RuntimeError("splits_final.json differs from the private case map")
    train_patients = {by_id[cid]["patient_key"] for cid in train}
    val_patients = {by_id[cid]["patient_key"] for cid in val}
    if train_patients & val_patients:
        raise RuntimeError("Patient-level train/validation leakage")
    if len(train_patients) != int(preflight["train_patients"]) or len(val_patients) != int(preflight["validation_patients"]):
        raise RuntimeError("Patient counts differ from the preflight summary")
    kinds = Counter(by_id[cid]["label_source"] for cid in train)
    if kinds["gt"] != int(preflight["train_gt_slices"]) or kinds["pf"] != int(preflight["train_pseudo_slices"]):
        raise RuntimeError("Training GT/pseudo counts differ from the preflight summary")
    if len(val) != int(preflight["validation_gt_slices"]) or any(by_id[cid]["label_source"] != "gt" for cid in val):
        raise RuntimeError("Validation label count/type differs from the preflight summary")

    images = directory / "imagesTr"
    labels = directory / "labelsTr"
    image_names = {p.name for p in images.glob("*.png")}
    label_names = {p.name for p in labels.glob("*.png")}
    if image_names != {f"{cid}_0000.png" for cid in by_id}:
        raise RuntimeError("Image files differ from the case map")
    if label_names != {f"{cid}.png" for cid in by_id}:
        raise RuntimeError("Label files differ from the case map")
    for cid in by_id:
        image_shape, _, _ = load_png(images / f"{cid}_0000.png")
        label_shape, label_values, _ = load_png(labels / f"{cid}.png")
        if image_shape != label_shape or not label_values.issubset({0, 1}):
            raise RuntimeError("Image/label dimensions differ or a label is not binary 0/1")
    summary = {
        "dataset": directory.name,
        "patients_train": len(train_patients),
        "patients_validation": len(val_patients),
        "train_gt_slices": kinds["gt"],
        "train_pseudo_slices": kinds["pf"],
        "validation_gt_slices": len(val),
        "all_png_pairs_checked": len(by_id),
    }
    return summary, by_id


def verify_pair(base: Path, unit: str, b_id: int, c_id: int) -> dict:
    b_dir = base / f"Dataset{b_id:03d}_MnMS2_{unit}_B"
    c_dir = base / f"Dataset{c_id:03d}_MnMS2_{unit}_Cneg"
    b_summary, b = load_arm(b_dir, "B", unit)
    c_summary, c = load_arm(c_dir, "Cneg", unit)
    b_train = {cid for cid, row in b.items() if row["role"] == "train"}
    c_train = {cid for cid, row in c.items() if row["role"] == "train"}
    b_val = {cid for cid, row in b.items() if row["role"] == "val"}
    c_val = {cid for cid, row in c.items() if row["role"] == "val"}
    if b_val != c_val or c_train != {cid for cid in b_train if b[cid]["label_source"] == "gt"}:
        raise RuntimeError("Paired arms differ in the validation set or shared GT training cases")
    if any(c[cid]["patient_key"] != b[cid]["patient_key"] for cid in c):
        raise RuntimeError("Shared cases map to different patients")
    common = c_train | c_val
    for cid in common:
        if digest(b_dir / "imagesTr" / f"{cid}_0000.png") != digest(c_dir / "imagesTr" / f"{cid}_0000.png"):
            raise RuntimeError("Shared images differ between B and Cneg")
        if digest(b_dir / "labelsTr" / f"{cid}.png") != digest(c_dir / "labelsTr" / f"{cid}.png"):
            raise RuntimeError("Shared GT labels differ between B and Cneg")
    if b_summary["train_pseudo_slices"] <= 0 or c_summary["train_pseudo_slices"] != 0:
        raise RuntimeError("The B/Cneg pseudo-label contrast is missing")
    return {"status": "PASS", "unit": unit, "B": b_summary, "Cneg": c_summary, "shared_cases_byte_identical": len(common)}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, default=Path("/root/autodl-tmp/nnUNet_raw"))
    parser.add_argument("--unit", default="u00")
    parser.add_argument("--b-id", type=int, default=901)
    parser.add_argument("--cneg-id", type=int, default=902)
    args = parser.parse_args()
    result = verify_pair(args.base, args.unit, args.b_id, args.cneg_id)
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
