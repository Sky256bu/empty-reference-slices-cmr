#!/usr/bin/env python3
"""Audit and score the 20 formal nnU-Net models on complete Philips/GE stacks.

The default action is a read-only preflight. ``--write`` creates cloud-local
private slice/case tables and public aggregate tables. Never copy the private
tables, source images, or patient mapping off the cloud instance.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.util
import json
import math
import os
import statistics
from collections import Counter, defaultdict
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
from PIL import Image

from prepare_mnms2_nnunet2d import MANIFEST_SHA256, case_id, inside, norm_key, sha256


EXPECTED_CASES = 3072
EXPECTED_PATIENTS = {"Philips": 88, "GE": 53}
PLAN = "nnUNetPlansSharedU00GT"
TRAINER = "nnUNetTrainer"
BOOTSTRAP_SEED = 20260928
BOOTSTRAP_DRAWS = 2000
ARMS = ("B", "Cneg")
UNITS = tuple(f"u{i:02d}" for i in range(10))


@dataclass(frozen=True)
class Case:
    case_id: str
    key: str
    phase: str
    z: int
    vendor: str
    gt_rel: str
    img_rel: str
    gt_px_manifest: int


def load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as stream:
        return json.load(stream)


def csv_rows(path: Path) -> list[dict[str, str]]:
    with path.open("r", newline="", encoding="utf-8-sig") as stream:
        return list(csv.DictReader(stream))


def write_csv(path: Path, fields: list[str], rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def write_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def domain(vendor: str) -> str | None:
    lower = vendor.lower()
    if "philips" in lower:
        return "Philips"
    if "ge medical" in lower or lower.strip() == "ge":
        return "GE"
    return None


def load_cases(manifest: Path) -> list[Case]:
    if sha256(manifest) != MANIFEST_SHA256:
        raise RuntimeError("Frozen manifest SHA256 mismatch")
    cases: list[Case] = []
    ids: set[str] = set()
    triples: set[tuple[str, str, int]] = set()
    patient_domain: dict[str, str] = {}
    zs: dict[tuple[str, str], set[int]] = defaultdict(set)
    for row in csv_rows(manifest):
        vendor = domain(row["vendor"])
        if vendor is None:
            continue
        key, phase, z = norm_key(row["key"]), row["phase"].lower(), int(row["z"])
        if phase not in ("ed", "es") or z < 0:
            raise RuntimeError("Invalid external phase or slice index in frozen manifest")
        cid = case_id(key, phase, z)
        triple = (key, phase, z)
        if cid in ids or triple in triples:
            raise RuntimeError("Duplicate external patient/phase/slice or case ID")
        ids.add(cid)
        triples.add(triple)
        if key in patient_domain and patient_domain[key] != vendor:
            raise RuntimeError("External patient has conflicting vendors")
        patient_domain[key] = vendor
        zs[key, phase].add(z)
        cases.append(Case(cid, key, phase, z, vendor, row["gt"], row["img"], int(row["gt_px"])))
    counts = Counter(patient_domain.values())
    if len(cases) != EXPECTED_CASES or dict(counts) != EXPECTED_PATIENTS:
        raise RuntimeError("Frozen external case/patient counts differ from 3072/88/53")
    for key in patient_domain:
        if zs[(key, "ed")] != zs[(key, "es")]:
            raise RuntimeError("External ED/ES stacks have different slice indices")
        for phase in ("ed", "es"):
            zset = zs.get((key, phase), set())
            if not zset or zset != set(range(len(zset))):
                raise RuntimeError("External ED/ES stack has missing or nonzero-start slices")
    return sorted(cases, key=lambda item: (item.key, item.phase, item.z))


def checked_file(path: Path, expected_sha: str, purpose: str) -> str:
    if not path.is_file() or sha256(path) != expected_sha:
        raise RuntimeError(f"{purpose} is missing or differs from its frozen SHA256")
    return expected_sha


def load_physical_audit(base: Path, cases: list[Case]) -> tuple[dict[str, str], str]:
    audit_dir = base / "mnms" / "seg_lv" / "scope_control_v3_zero_gpu_audit"
    summary_path = audit_dir / "input_audit_summary_v3.json"
    physical_path = audit_dir / "input_file_manifest_v3.csv"
    summary = load_json(summary_path)
    if summary.get("status") != "PASS" or summary.get("manifest_sha256") != MANIFEST_SHA256:
        raise RuntimeError("Frozen input audit is not PASS")
    if summary.get("outputs", {}).get(physical_path.name, {}).get("sha256") != sha256(physical_path):
        raise RuntimeError("Frozen physical input manifest SHA256 mismatch")
    selected: dict[str, str] = {}
    for row in csv_rows(physical_path):
        if "external_Philips:" not in row["roles"] and "external_GE:" not in row["roles"]:
            continue
        if not any(role in row["roles"] for role in (":gt", ":volume_gt:", ":image")):
            continue
        path = row["absolute_path"]
        if path in selected and selected[path] != row["sha256"]:
            raise RuntimeError("Conflicting frozen source hashes")
        selected[path] = row["sha256"]
    image_root = base / "mnms" / "seg_lv" / "all"
    for case in cases:
        for relative in (case.gt_rel, case.img_rel):
            path = str(inside(image_root, relative))
            if path not in selected:
                raise RuntimeError("Frozen physical audit lacks an external image or GT PNG")
    if len([p for p in selected if p.endswith(".nii.gz")]) != 282:
        raise RuntimeError("Frozen physical audit lacks an external GT volume")
    return selected, sha256(summary_path)


def verify_source_labels(base: Path, cases: list[Case], physical: dict[str, str]) -> None:
    image_root = base / "mnms" / "seg_lv" / "all"
    for case in cases:
        path = inside(image_root, case.gt_rel)
        checked_file(path, physical[str(path)], "Frozen external GT PNG")
    for key, phase in sorted({(case.key, case.phase) for case in cases}):
        path = base / "mnms" / "MnM2" / "dataset" / key / f"{key}_SA_{phase.upper()}_gt.nii.gz"
        checked_file(path, physical.get(str(path)), "Frozen external GT NIfTI")


def load_stage_map(base: Path, cases: list[Case], physical: dict[str, str],
                   physical_audit_sha: str) -> tuple[dict[str, dict[str, str]], str]:
    stage_root = base / "nnUNet_external_input"
    audit_path = stage_root / "stage_audit.json"
    audit = load_json(audit_path)
    if (audit.get("status") != "PASS" or audit.get("manifest_sha256") != MANIFEST_SHA256
            or audit.get("source_audit_sha256") != physical_audit_sha
            or audit.get("cases") != EXPECTED_CASES):
        raise RuntimeError("External input stage audit is incomplete or cites another manifest")
    images = stage_root / "imagesTs"
    if Path(audit.get("input_dir", "")).resolve() != images.resolve():
        raise RuntimeError("External stage audit cites another input directory")
    map_path = stage_root / "private_map.csv"
    rows = csv_rows(map_path)
    by_id: dict[str, dict[str, str]] = {}
    for row in rows:
        cid = row["case_id"]
        if cid in by_id:
            raise RuntimeError("Duplicate case in private input mapping")
        by_id[cid] = row
    expected = {case.case_id for case in cases}
    if set(by_id) != expected:
        raise RuntimeError("Private input mapping differs from frozen external case set")
    for case in cases:
        row = by_id[case.case_id]
        if (row["patient_key"] != case.key or row["phase"] != case.phase
                or int(row["z"]) != case.z or domain(row["vendor"]) != case.vendor
                or row["gt_rel"] != case.gt_rel or row["image_rel"] != case.img_rel):
            raise RuntimeError("Private input mapping differs from frozen manifest")
        image_path = inside(base / "mnms" / "seg_lv" / "all", case.img_rel)
        if row["source_image_sha256"] != physical.get(str(image_path)):
            raise RuntimeError("Private input map image hash differs from frozen physical audit")
    input_names = {f"{case.case_id}_0000.png" for case in cases}
    expected_hashes = {f"{case.case_id}_0000.png": by_id[case.case_id]["source_image_sha256"] for case in cases}
    staged_inventory = inventory(images, input_names, expected_hashes)
    if staged_inventory != audit.get("input_inventory_sha256"):
        raise RuntimeError("Staged input PNG inventory differs from PASS audit")
    return by_id, sha256(audit_path)


def inventory(directory: Path, expected_names: set[str], expected_hashes: dict[str, str] | None = None) -> str:
    if not directory.is_dir():
        raise RuntimeError("External prediction directory is missing")
    names = {p.name for p in directory.glob("*.png")}
    if names != expected_names:
        raise RuntimeError(f"External prediction set differs: {len(expected_names - names)} missing, {len(names - expected_names)} extra")
    digest = hashlib.sha256()
    for name in sorted(expected_names):
        observed_sha = sha256(directory / name)
        if expected_hashes is not None and observed_sha != expected_hashes[name]:
            raise RuntimeError("Staged input PNG differs from frozen source image")
        digest.update(f"{name}\t{observed_sha}\n".encode("utf-8"))
    return digest.hexdigest()


def model_identity(unit: str, arm: str) -> tuple[int, str]:
    dataset_id = 901 + 2 * int(unit[1:]) + (arm == "Cneg")
    return dataset_id, f"Dataset{dataset_id:03d}_MnMS2_{unit}_{arm}"


def verify_predictions(base: Path, rep: int, cases: list[Case], stage_sha: str) -> list[dict]:
    rep_name = f"rep{rep:02d}"
    result_root = base / "nnUNet_results_formal" / rep_name
    pred_root = base / "nnUNet_external_predictions" / rep_name
    expected_names = {f"{case.case_id}.png" for case in cases}
    models: list[dict] = []
    for unit in UNITS:
        for arm in ARMS:
            dataset_id, dataset = model_identity(unit, arm)
            formal_path = result_root / "_audit" / f"{unit}_{arm}.json"
            formal = load_json(formal_path)
            fields = {
                "status": "PASS", "unit": unit, "arm": arm, "rep": rep_name,
                "dataset_id": dataset_id, "dataset": dataset, "trainer": TRAINER,
                "plan_name": PLAN, "configuration": "2d", "fold": "0",
                "planned_epochs": 1000, "final_model_rule": "checkpoint_final.pth_only",
            }
            if any(formal.get(k) != v for k, v in fields.items()):
                raise RuntimeError(f"Formal PASS identity mismatch for {unit}/{arm}")
            if not any(a.get("status") == "PASS" for a in formal.get("attempts", [])):
                raise RuntimeError(f"Formal PASS attempt missing for {unit}/{arm}")
            checkpoint = result_root / dataset / f"{TRAINER}__{PLAN}__2d" / "fold_0" / "checkpoint_final.pth"
            checkpoint_sha = checked_file(checkpoint, formal.get("validated_artifacts", {}).get("checkpoint_final_sha256"), "Audited final checkpoint")
            audit_path = pred_root / "_audit" / f"{unit}_{arm}.json"
            audit = load_json(audit_path)
            pred_dir = pred_root / f"{unit}_{arm}"
            expected_fields = {
                "schema": "mnms2_nnunet_external_predict_v1", "status": "PASS",
                "unit": unit, "arm": arm, "rep": rep_name,
                "dataset_id": dataset_id, "dataset": dataset,
                "checkpoint_final_sha256": checkpoint_sha,
                "stage_audit_sha256": stage_sha,
                "manifest_sha256": MANIFEST_SHA256, "cases_expected": EXPECTED_CASES,
            }
            if any(audit.get(k) != v for k, v in expected_fields.items()):
                raise RuntimeError(f"Prediction PASS audit mismatch for {unit}/{arm}")
            inv = inventory(pred_dir, expected_names)
            if inv != audit.get("predictions_inventory_sha256"):
                raise RuntimeError(f"Prediction PNG inventory changed for {unit}/{arm}")
            models.append({"unit": unit, "arm": arm, "pred_dir": pred_dir,
                           "checkpoint_sha256": checkpoint_sha, "prediction_inventory_sha256": inv,
                           "prediction_audit_sha256": sha256(audit_path)})
    return models


def read_gray(path: Path) -> np.ndarray:
    try:
        with Image.open(path) as image:
            if image.format != "PNG" or len(image.getbands()) != 1:
                raise RuntimeError("Mask PNG is not single channel")
            value = np.asarray(image)
            if value.ndim != 2:
                raise RuntimeError("Mask PNG has unexpected dimensions")
            return value
    except Exception:
        raise RuntimeError("A source or prediction mask could not be decoded") from None


def binary_mask(path: Path, allowed: set[int], threshold: int) -> np.ndarray:
    image = read_gray(path)
    if not set(np.unique(image)).issubset(allowed):
        raise RuntimeError("Mask PNG contains values outside its frozen label encoding")
    return image > threshold


def nifti_scale(base: Path, key: str, phase: str, physical: dict[str, str], slices: int) -> float:
    import nibabel as nib

    suffix = phase.upper()
    path = base / "mnms" / "MnM2" / "dataset" / key / f"{key}_SA_{suffix}_gt.nii.gz"
    checked_file(path, physical.get(str(path)), "Frozen external GT NIfTI")
    try:
        image = nib.load(str(path))
    except Exception:
        raise RuntimeError("Original GT NIfTI could not be decoded") from None
    if len(image.shape) < 3 or image.shape[2] != slices:
        raise RuntimeError("Original GT NIfTI stack depth differs from frozen manifest")
    scale = abs(float(np.linalg.det(image.affine[:3, :3]))) / 1000.0
    if not math.isfinite(scale) or scale <= 0:
        raise RuntimeError("Original GT NIfTI has invalid affine voxel volume")
    return scale


def dice(intersection: int, prediction: int, ground_truth: int) -> float:
    denominator = prediction + ground_truth
    return 1.0 if denominator == 0 else 2.0 * intersection / denominator


def ef(edv: float, esv: float) -> float | None:
    # Matches the frozen ResNet-34 U-Net evaluator's 1e-6 mL EDV guard.
    return 100.0 * (edv - esv) / edv if edv > 1e-6 else None


def mean(values: list[float]) -> float | None:
    return float(statistics.fmean(values)) if values else None


def quantile(values: list[float], q: float) -> float | None:
    return float(np.quantile(values, q)) if values else None


def build_reference(base: Path, cases: list[Case], stage_map: dict[str, dict[str, str]],
                    physical: dict[str, str]) -> tuple[dict[str, np.ndarray], dict[tuple[str, str], float]]:
    image_root = base / "mnms" / "seg_lv" / "all"
    references: dict[str, np.ndarray] = {}
    grouped: dict[tuple[str, str], int] = Counter((c.key, c.phase) for c in cases)
    scales = {key_phase: nifti_scale(base, key_phase[0], key_phase[1], physical, count)
              for key_phase, count in grouped.items()}
    for case in cases:
        path = inside(image_root, case.gt_rel)
        expected_sha = physical[str(path)]
        if stage_map[case.case_id]["source_gt_sha256"] != expected_sha:
            raise RuntimeError("Private input map GT hash differs from frozen physical audit")
        checked_file(path, expected_sha, "Frozen external GT PNG")
        mask = binary_mask(path, {0, 255}, 127)
        if int(mask.sum()) != case.gt_px_manifest:
            raise RuntimeError("Frozen manifest GT pixel count differs from source mask")
        references[case.case_id] = mask
    return references, scales


def evaluate_model(model: dict, cases: list[Case], references: dict[str, np.ndarray],
                   scales: dict[tuple[str, str], float], slice_writer: csv.DictWriter) -> list[dict]:
    accum: dict[tuple[str, str], dict[str, float]] = defaultdict(lambda: defaultdict(float))
    vendor_by_key: dict[str, str] = {}
    for case in cases:
        prediction = binary_mask(model["pred_dir"] / f"{case.case_id}.png", {0, 1}, 0)
        ground_truth = references[case.case_id]
        if prediction.shape != ground_truth.shape:
            raise RuntimeError("Prediction mask shape differs from original GT PNG")
        gt_px, pred_px = int(ground_truth.sum()), int(prediction.sum())
        intersection = int(np.logical_and(ground_truth, prediction).sum())
        present = gt_px > 0
        empty_fp_px = pred_px if not present else 0
        item = accum[case.key, case.phase]
        item["gt_px"] += gt_px
        item["pred_px"] += pred_px
        item["intersection_px"] += intersection
        item["slices"] += 1
        item["empty_gt_slices"] += not present
        item["empty_gt_fp_slices"] += not present and pred_px > 0
        item["empty_gt_fp_px"] += empty_fp_px
        if present:
            item["present_gt_px"] += gt_px
            item["present_pred_px"] += pred_px
            item["present_intersection_px"] += intersection
            item["present_slices"] += 1
            item["present_slice_dice_sum"] += dice(intersection, pred_px, gt_px)
        vendor_by_key[case.key] = case.vendor
        slice_writer.writerow({
            "unit": model["unit"], "arm": model["arm"], "vendor": case.vendor,
            "patient_key": case.key, "phase": case.phase, "z": case.z,
            "case_id": case.case_id, "gt_px": gt_px, "pred_px": pred_px,
            "intersection_px": intersection, "dice": dice(intersection, pred_px, gt_px),
            "gt_present": int(present), "empty_gt_fp_px": empty_fp_px,
        })
    rows: list[dict] = []
    for key in sorted(vendor_by_key):
        phase_rows: dict[str, dict] = {}
        for phase in ("ed", "es"):
            item = accum[key, phase]
            scale = scales[key, phase]
            present_count = int(item["present_slices"])
            phase_rows[phase] = {
                "gt_volume_ml": item["gt_px"] * scale,
                "pred_volume_ml": item["pred_px"] * scale,
                "dice_full_stack": dice(int(item["intersection_px"]), int(item["pred_px"]), int(item["gt_px"])),
                "dice_volume_present": dice(int(item["present_intersection_px"]), int(item["present_pred_px"]), int(item["present_gt_px"])) if present_count else None,
                "dice_slice_present": (item["present_slice_dice_sum"] / present_count) if present_count else None,
                "slices": int(item["slices"]), "present_slices": present_count,
                "empty_gt_slices": int(item["empty_gt_slices"]),
                "empty_gt_fp_slices": int(item["empty_gt_fp_slices"]),
                "empty_gt_fp_px": int(item["empty_gt_fp_px"]),
            }
        ed, es = phase_rows["ed"], phase_rows["es"]
        ef_gt = ef(ed["gt_volume_ml"], es["gt_volume_ml"])
        ef_pred = ef(ed["pred_volume_ml"], es["pred_volume_ml"])
        if ef_gt is None or not math.isfinite(ef_gt):
            raise RuntimeError("External GT has invalid EF")
        invalid = ef_pred is None or not math.isfinite(ef_pred)
        out_of_range = not invalid and not 0.0 <= ef_pred <= 100.0
        error = None if invalid else ef_pred - ef_gt
        row = {
            "unit": model["unit"], "arm": model["arm"], "vendor": vendor_by_key[key],
            "patient_key": key, "edv_gt_ml": ed["gt_volume_ml"],
            "esv_gt_ml": es["gt_volume_ml"], "ef_gt_pct": ef_gt,
            "edv_pred_ml": ed["pred_volume_ml"], "esv_pred_ml": es["pred_volume_ml"],
            "ef_pred_pct": ef_pred, "ef_invalid": int(invalid),
            "ef_out_of_range": int(out_of_range),
            "ef_error_pp": error, "ef_abs_error_pp": abs(error) if error is not None else None,
            "edv_abs_error_ml": abs(ed["pred_volume_ml"] - ed["gt_volume_ml"]),
            "esv_abs_error_ml": abs(es["pred_volume_ml"] - es["gt_volume_ml"]),
        }
        for phase, phase_row in phase_rows.items():
            for metric, value in phase_row.items():
                row[f"{phase}_{metric}"] = value
        rows.append(row)
    return rows


PHASE_METRICS = ("dice_full_stack", "dice_volume_present", "dice_slice_present",
                 "slices", "present_slices", "empty_gt_slices", "empty_gt_fp_slices", "empty_gt_fp_px")


def aggregate_arm(rows: list[dict], vendor: str) -> dict:
    selected = [r for r in rows if vendor == "All" or r["vendor"] == vendor]
    valid = [r for r in selected if not r["ef_invalid"]]
    abs_errors = [r["ef_abs_error_pp"] for r in valid]
    result = {
        "vendor": vendor, "patients": len(selected), "ef_valid_patients": len(valid),
        "ef_invalid_patients": len(selected) - len(valid),
        "ef_out_of_range_patients": sum(r["ef_out_of_range"] for r in selected),
        "ef_mae_pp": mean(abs_errors), "ef_ae_median_pp": quantile(abs_errors, 0.5),
        "ef_ae_p90_pp": quantile(abs_errors, 0.9),
        "ef_ae_gt20_patients": sum(value > 20 for value in abs_errors),
        "ef_ae_gt40_patients": sum(value > 40 for value in abs_errors),
        "edv_mae_ml": mean([r["edv_abs_error_ml"] for r in selected]),
        "esv_mae_ml": mean([r["esv_abs_error_ml"] for r in selected]),
    }
    for phase in ("ed", "es"):
        for metric in PHASE_METRICS:
            values = [r[f"{phase}_{metric}"] for r in selected if r[f"{phase}_{metric}"] is not None]
            result[f"{phase}_{metric}_{'total' if metric in ('slices', 'present_slices', 'empty_gt_slices', 'empty_gt_fp_slices', 'empty_gt_fp_px') else 'mean'}"] = (
                sum(values) if metric in ("slices", "present_slices", "empty_gt_slices", "empty_gt_fp_slices", "empty_gt_fp_px") else mean(values)
            )
    return result


def aggregate_pairs(case_rows: list[dict]) -> tuple[list[dict], list[dict], list[dict]]:
    index = {(r["unit"], r["arm"], r["patient_key"]): r for r in case_rows}
    by_unit: list[dict] = []
    private_pairs: list[dict] = []
    for unit in UNITS:
        for vendor in ("Philips", "GE", "All"):
            differences: list[float] = []
            invalid_b = invalid_c = 0
            patients = sorted({r["patient_key"] for r in case_rows if r["unit"] == unit and (vendor == "All" or r["vendor"] == vendor)})
            for key in patients:
                b, c = index[unit, "B", key], index[unit, "Cneg", key]
                invalid_b += b["ef_invalid"]
                invalid_c += c["ef_invalid"]
                value = None if b["ef_invalid"] or c["ef_invalid"] else b["ef_abs_error_pp"] - c["ef_abs_error_pp"]
                if value is not None:
                    differences.append(value)
                if vendor != "All":
                    private_pairs.append({"unit": unit, "vendor": vendor, "patient_key": key,
                                          "b_ef_abs_error_pp": b["ef_abs_error_pp"],
                                          "cneg_ef_abs_error_pp": c["ef_abs_error_pp"],
                                          "b_minus_cneg_ef_ae_pp": value,
                                          "b_ef_invalid": b["ef_invalid"], "cneg_ef_invalid": c["ef_invalid"]})
            by_unit.append({"unit": unit, "vendor": vendor, "patients": len(patients),
                            "paired_valid_patients": len(differences), "b_invalid_patients": invalid_b,
                            "cneg_invalid_patients": invalid_c, "b_minus_cneg_ef_ae_mean_pp": mean(differences),
                            "b_minus_cneg_ef_ae_median_pp": quantile(differences, 0.5)})
    summary: list[dict] = []
    for vendor in ("Philips", "GE", "All"):
        units = [r for r in by_unit if r["vendor"] == vendor]
        complete = all(r["patients"] > 0 and r["paired_valid_patients"] == r["patients"] for r in units)
        deltas = [r["b_minus_cneg_ef_ae_mean_pp"] for r in units]
        finite_deltas = [value for value in deltas if value is not None]
        selected = [r for r in case_rows if vendor == "All" or r["vendor"] == vendor]
        b_rows = [r for r in selected if r["arm"] == "B"]
        c_rows = [r for r in selected if r["arm"] == "Cneg"]
        row = {
            "vendor": vendor, "units": len(units), "patients_per_unit": units[0]["patients"],
            "complete_ef_endpoint": int(complete),
            "b_invalid_evaluations": sum(r["ef_invalid"] for r in b_rows),
            "cneg_invalid_evaluations": sum(r["ef_invalid"] for r in c_rows),
            "b_ef_mae_pp": mean([r["ef_abs_error_pp"] for r in b_rows if not r["ef_invalid"]]),
            "cneg_ef_mae_pp": mean([r["ef_abs_error_pp"] for r in c_rows if not r["ef_invalid"]]),
            "paired_b_minus_cneg_mean_pp": mean(deltas) if complete else None,
            "paired_unit_sd_pp": statistics.stdev(deltas) if complete and len(deltas) > 1 else None,
            "units_favoring_b": sum(delta < 0 for delta in deltas) if complete else None,
            "partial_paired_valid_unit_mean_pp": mean(finite_deltas),
            "bootstrap_seed": BOOTSTRAP_SEED, "bootstrap_draws": BOOTSTRAP_DRAWS if complete else 0,
            "bootstrap_ci_low_pp": None, "bootstrap_ci_high_pp": None,
        }
        summary.append(row)
    if any(row["complete_ef_endpoint"] for row in summary):
        bootstrap_ci(case_rows, summary)
    return private_pairs, by_unit, summary


def bootstrap_ci(case_rows: list[dict], summaries: list[dict]) -> None:
    complete = {row["vendor"] for row in summaries if row["complete_ef_endpoint"]}
    keys = {vendor: sorted({r["patient_key"] for r in case_rows if r["vendor"] == vendor})
            for vendor in ("Philips", "GE") if vendor in complete}
    by_index = {(r["unit"], r["arm"], r["patient_key"]): r["ef_abs_error_pp"] for r in case_rows}
    matrices = {vendor: np.array([[by_index[unit, "B", key] - by_index[unit, "Cneg", key]
                                   for key in keys[vendor]] for unit in UNITS], dtype=float)
                for vendor in keys}
    rng = np.random.default_rng(BOOTSTRAP_SEED)
    draws: dict[str, list[float]] = {vendor: [] for vendor in complete}
    for _ in range(BOOTSTRAP_DRAWS):
        sampled_units = rng.integers(len(UNITS), size=len(UNITS))
        values: dict[str, float] = {}
        for vendor, matrix in matrices.items():
            sampled_patients = rng.integers(matrix.shape[1], size=matrix.shape[1])
            values[vendor] = float(matrix[np.ix_(sampled_units, sampled_patients)].mean())
            draws[vendor].append(values[vendor])
        if "All" in complete:
            draws["All"].append((values["Philips"] * len(keys["Philips"]) + values["GE"] * len(keys["GE"])) / sum(EXPECTED_PATIENTS.values()))
    for row in summaries:
        if row["vendor"] in complete:
            row["bootstrap_ci_low_pp"] = quantile(draws[row["vendor"]], 0.025)
            row["bootstrap_ci_high_pp"] = quantile(draws[row["vendor"]], 0.975)


def write_evaluation(base: Path, rep: int, cases: list[Case], stage_map: dict[str, dict[str, str]],
                     physical: dict[str, str], models: list[dict], stage_sha: str,
                     physical_audit_sha: str, output: Path) -> None:
    script_sha = sha256(Path(__file__).resolve())
    expected_outputs = {
        "private/slice_metrics_PRIVATE.csv", "private/case_metrics_PRIVATE.csv",
        "private/paired_case_metrics_PRIVATE.csv", "public/unit_arm_vendor_summary.csv",
        "public/paired_unit_vendor_summary.csv", "public/paired_overall_summary.csv",
    }
    if output.exists():
        audit = load_json(output / "public" / "evaluation_audit.json")
        expected = {f"{m['unit']}_{m['arm']}": m["prediction_inventory_sha256"] for m in models}
        if (audit.get("status") != "PASS" or audit.get("stage_audit_sha256") != stage_sha
                or audit.get("physical_input_audit_sha256") != physical_audit_sha
                or audit.get("evaluator_script_sha256") != script_sha
                or audit.get("prediction_inventories") != expected
                or audit.get("checkpoint_sha256") != {f"{m['unit']}_{m['arm']}": m["checkpoint_sha256"] for m in models}
                or set(audit.get("output_sha256", {})) != expected_outputs):
            raise RuntimeError("Existing evaluation output differs from current audited inputs")
        for rel, expected_hash in audit.get("output_sha256", {}).items():
            checked_file(output / rel, expected_hash, "Existing evaluation output")
        print("Evaluation PASS: existing audited output verified; no files changed.")
        return
    staging = output.with_name(output.name + ".STAGING")
    if staging.exists():
        raise RuntimeError("Interrupted evaluation staging directory exists; inspect it before retrying")
    os.umask(0o077)
    private = staging / "private"
    public = staging / "public"
    private.mkdir(parents=True)
    public.mkdir(parents=True)
    references, scales = build_reference(base, cases, stage_map, physical)
    slice_fields = ["unit", "arm", "vendor", "patient_key", "phase", "z", "case_id", "gt_px",
                    "pred_px", "intersection_px", "dice", "gt_present", "empty_gt_fp_px"]
    case_rows: list[dict] = []
    with (private / "slice_metrics_PRIVATE.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=slice_fields)
        writer.writeheader()
        for model in models:
            case_rows.extend(evaluate_model(model, cases, references, scales, writer))
            print(f"Scored {model['unit']}/{model['arm']}: {EXPECTED_CASES} slices, {sum(EXPECTED_PATIENTS.values())} patients.", flush=True)
    if len(case_rows) != len(models) * sum(EXPECTED_PATIENTS.values()):
        raise RuntimeError("Case-level evaluation count is incomplete")
    write_csv(private / "case_metrics_PRIVATE.csv", list(case_rows[0]), case_rows)
    private_pairs, pair_units, pair_summary = aggregate_pairs(case_rows)
    write_csv(private / "paired_case_metrics_PRIVATE.csv", list(private_pairs[0]), private_pairs)
    arm_summaries = []
    for model in models:
        subset = [r for r in case_rows if r["unit"] == model["unit"] and r["arm"] == model["arm"]]
        for vendor in ("Philips", "GE", "All"):
            arm_summaries.append({"unit": model["unit"], "arm": model["arm"], **aggregate_arm(subset, vendor)})
    write_csv(public / "unit_arm_vendor_summary.csv", list(arm_summaries[0]), arm_summaries)
    write_csv(public / "paired_unit_vendor_summary.csv", list(pair_units[0]), pair_units)
    write_csv(public / "paired_overall_summary.csv", list(pair_summary[0]), pair_summary)
    hashes = {str(path.relative_to(staging)).replace("\\", "/"): sha256(path)
              for path in staging.rglob("*.csv")}
    audit = {
        "schema": "mnms2_nnunet_external_evaluation_v1", "status": "PASS",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "purpose": "exploratory_additional_analysis_on_previously_used_held_out_vendors",
        "rep": f"rep{rep:02d}", "models": len(models), "cases_per_model": EXPECTED_CASES,
        "evaluator_script_sha256": script_sha,
        "patients_per_model": sum(EXPECTED_PATIENTS.values()), "manifest_sha256": MANIFEST_SHA256,
        "stage_audit_sha256": stage_sha, "physical_input_audit_sha256": physical_audit_sha,
        "checkpoint_sha256": {f"{m['unit']}_{m['arm']}": m["checkpoint_sha256"] for m in models},
        "prediction_inventories": {f"{m['unit']}_{m['arm']}": m["prediction_inventory_sha256"] for m in models},
        "prediction_audit_sha256": {f"{m['unit']}_{m['arm']}": m["prediction_audit_sha256"] for m in models},
        "thresholds": {"source_gt_png": ">127 of 0/255", "nnunet_prediction_png": ">0 of 0/1"},
        "voxel_ml": "abs(det(original_GT_NIfTI_affine_3x3))/1000",
        "ef_formula": "100*(EDV-ESV)/EDV; EDV<=1e-6 mL is invalid",
        "dice_definition": "full_stack counts all slices; volume_present pools GT-positive slices; slice_present averages GT-positive slice Dice; empty-empty slice Dice=1",
        "invalid_ef_policy": "Retained in private case rows and public denominators; no full-endpoint bootstrap if any invalid EF",
        "bootstrap": {"seed": BOOTSTRAP_SEED, "draws": BOOTSTRAP_DRAWS,
                       "resampling": "training unit and vendor-stratified patient, preserving repeated patient measurements across units"},
        "output_sha256": hashes,
    }
    write_json(public / "evaluation_audit.json", audit)
    staging.rename(output)
    print("Evaluation PASS: public aggregates and cloud-private case/slice tables saved.")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, default=Path("/root/autodl-tmp"))
    parser.add_argument("--rep", type=int, choices=range(3), default=0)
    parser.add_argument("--write", action="store_true", help="Score complete audited predictions and create outputs")
    args = parser.parse_args()
    base = args.base.expanduser().resolve()
    cases = load_cases(base / "mnms" / "seg_lv" / "manifest_mnms2.csv")
    physical, physical_audit_sha = load_physical_audit(base, cases)
    verify_source_labels(base, cases, physical)
    stage_map, stage_sha = load_stage_map(base, cases, physical, physical_audit_sha)
    models = verify_predictions(base, args.rep, cases, stage_sha)
    print(f"Preflight PASS: {len(models)} audited models; {EXPECTED_CASES} complete Philips/GE slices per model; {sum(EXPECTED_PATIENTS.values())} patients.")
    if args.write:
        if importlib.util.find_spec("nibabel") is None:
            raise RuntimeError("Evaluation requires nibabel to read original GT NIfTI affines")
        output = base / "nnUNet_external_evaluation" / f"rep{args.rep:02d}"
        output.parent.mkdir(parents=True, exist_ok=True)
        write_evaluation(base, args.rep, cases, stage_map, physical, models, stage_sha, physical_audit_sha, output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
