#!/usr/bin/env python3
"""Read-only, non-identifying nnU-Net environment check for M&Ms-2.

Run this on the AutoDL machine before planning/preprocessing. It neither
installs packages nor reads image pixels or patient identifiers.
"""

from __future__ import annotations

import importlib.metadata
import json
import os
import platform
import shutil
import sys
from pathlib import Path


BASE = Path("/root/autodl-tmp")


def package_version(name: str) -> str | None:
    try:
        return importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        return None


def free_gib(path: Path) -> float | None:
    existing = path
    while not existing.exists() and existing != existing.parent:
        existing = existing.parent
    try:
        return round(shutil.disk_usage(existing).free / 1024**3, 2)
    except OSError:
        return None


def memory_gib() -> float | None:
    try:
        pages = os.sysconf("SC_PHYS_PAGES")
        page_size = os.sysconf("SC_PAGE_SIZE")
        return round(pages * page_size / 1024**3, 2)
    except (AttributeError, OSError, ValueError):
        return None


def cgroup_memory_limit_gib() -> float | None:
    for candidate in (Path("/sys/fs/cgroup/memory.max"), Path("/sys/fs/cgroup/memory/memory.limit_in_bytes")):
        try:
            value = candidate.read_text(encoding="ascii").strip()
            if value != "max":
                limit = int(value)
                if limit < 2**60:
                    return round(limit / 1024**3, 2)
        except (OSError, ValueError):
            pass
    return None


def main() -> None:
    raw = Path(os.environ.get("nnUNet_raw", str(BASE / "nnUNet_raw"))).expanduser()
    preprocessed = Path(os.environ.get("nnUNet_preprocessed", str(BASE / "nnUNet_preprocessed"))).expanduser()
    results = Path(os.environ.get("nnUNet_results", str(BASE / "nnUNet_results"))).expanduser()
    raw_status = []
    preprocessed_status = []
    for index in range(10):
        for offset, arm in ((1, "B"), (2, "Cneg")):
            dataset_id = 900 + 2 * index + offset
            name = f"Dataset{dataset_id:03d}_MnMS2_u{index:02d}_{arm}"
            directory = raw / name
            raw_status.append({
                "dataset": name,
                "exists": directory.is_dir(),
                "has_dataset_json": (directory / "dataset.json").is_file(),
                "has_split": (directory / "splits_final.json").is_file(),
            })
            pp = preprocessed / name
            preprocessed_status.append({
                "dataset": name,
                "exists": pp.is_dir(),
                "has_plans": (pp / "nnUNetPlans.json").is_file(),
                "has_split": (pp / "splits_final.json").is_file(),
            })
    report = {
        "python": sys.version.split()[0],
        "platform": platform.platform(),
        "cpu_count": os.cpu_count(),
        "ram_gib": memory_gib(),
        "container_memory_limit_gib": cgroup_memory_limit_gib(),
        "packages": {name: package_version(name) for name in ("torch", "nnunetv2", "numpy", "Pillow")},
        "commands": {
            name: bool(shutil.which(name))
            for name in (
                "nnUNetv2_plan_and_preprocess", "nnUNetv2_extract_fingerprint",
                "nnUNetv2_plan_experiment", "nnUNetv2_preprocess", "nnUNetv2_train",
            )
        },
        "environment": {
            "nnUNet_raw": os.environ.get("nnUNet_raw"),
            "nnUNet_preprocessed": os.environ.get("nnUNet_preprocessed"),
            "nnUNet_results": os.environ.get("nnUNet_results"),
        },
        "paths": {
            "raw": str(raw),
            "preprocessed": str(preprocessed),
            "results": str(results),
        },
        "free_gib": {
            "raw": free_gib(raw),
            "preprocessed": free_gib(preprocessed),
            "results": free_gib(results),
        },
        "raw_datasets_complete": sum(
            item["exists"] and item["has_dataset_json"] and item["has_split"] for item in raw_status
        ),
        "preprocessed_datasets_with_plans": sum(item["has_plans"] for item in preprocessed_status),
        "preprocessed_datasets_with_splits": sum(item["has_split"] for item in preprocessed_status),
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
