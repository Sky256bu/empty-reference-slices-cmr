#!/usr/bin/env python3
"""Safely preprocess a staged M&Ms-2 B/Cneg pair with the frozen 2D plan.

Default is a read-only preflight. --write runs nnU-Net v2.8.1 for missing
outputs only; complete outputs are verified and skipped, and partial outputs
are never deleted. Run u00 first before expanding to other paired units.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import subprocess
from copy import deepcopy
from datetime import datetime, timezone
from pathlib import Path


REFERENCE = "Dataset900_MnMS2_CommonPlan_u00_GT"
PLAN_NAME = "nnUNetPlansSharedU00GT"
PLAN_SHA256 = "99e7f68f6a700511d41d0e69e9226ad2a8e8e3ffe36eac79d2140c339afe3bae"
FINGERPRINT_SHA256 = "cde585fbb93653bcc9b7c9f5454b8e9372da2b184fa40381748fad8354138671"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def read_json(path: Path) -> dict | list:
    return json.loads(path.read_text(encoding="utf-8"))


def same_2d_plan(left: dict, right: dict) -> bool:
    a = deepcopy(left["configurations"]["2d"])
    b = deepcopy(right["configurations"]["2d"])
    a.pop("data_identifier", None)
    b.pop("data_identifier", None)
    return a == b


def expected_name(unit: str, arm: str) -> tuple[int, str]:
    dataset_id = 901 + 2 * int(unit[1:]) + (0 if arm == "B" else 1)
    return dataset_id, f"Dataset{dataset_id:03d}_MnMS2_{unit}_{arm}"


def verify_output(output: Path, gt_dir: Path, raw_labels_dir: Path, expected: set[str]) -> None:
    if not output.is_dir():
        raise RuntimeError(f"Missing preprocessed output: {output}")

    def check_set(label: str, found: set[str]) -> None:
        if found != expected:
            missing = sorted(expected - found)[:3]
            extra = sorted(found - expected)[:3]
            raise RuntimeError(
                f"Incomplete {label}: expected {len(expected)}, found {len(found)}; "
                f"missing={missing}, extra={extra}"
            )

    data_files = {p.name[:-5]: p for p in output.glob("*.b2nd") if not p.name.endswith("_seg.b2nd")}
    seg_files = {p.name[:-9]: p for p in output.glob("*_seg.b2nd")}
    property_files = {p.stem: p for p in output.glob("*.pkl")}
    gt_files = {p.stem: p for p in gt_dir.glob("*.png")} if gt_dir.is_dir() else {}
    for label, files in (
        ("image .b2nd", data_files),
        ("label _seg.b2nd", seg_files),
        ("properties .pkl", property_files),
        ("original GT .png", gt_files),
    ):
        check_set(label, set(files))
        if any(not p.is_file() or p.stat().st_size == 0 for p in files.values()):
            raise RuntimeError(f"Zero-byte file in {label}: {output}")
    for case_id in expected:
        if sha256(raw_labels_dir / f"{case_id}.png") != sha256(gt_files[case_id]):
            raise RuntimeError(f"Copied original GT differs from raw label: {case_id}")


def inspect_target(
    base: Path, unit: str, arm: str, source_plan: dict
) -> dict:
    dataset_id, name = expected_name(unit, arm)
    raw = base / "nnUNet_raw" / name
    staged = base / "nnUNet_preprocessed" / name
    for filename in ("dataset.json", "splits_final.json", "preflight_summary.json"):
        if not (raw / filename).is_file():
            raise FileNotFoundError(f"Missing raw {filename}: {name}")
    for filename in ("dataset.json", "splits_final.json", "dataset_fingerprint.json", f"{PLAN_NAME}.json", "planning_provenance.json"):
        if not (staged / filename).is_file():
            raise FileNotFoundError(f"Missing staged {filename}: {name}")
    if sha256(raw / "dataset.json") != sha256(staged / "dataset.json"):
        raise RuntimeError(f"Staged dataset.json differs from raw: {name}")
    if sha256(raw / "splits_final.json") != sha256(staged / "splits_final.json"):
        raise RuntimeError(f"Staged fixed split differs from raw: {name}")
    if sha256(staged / "dataset_fingerprint.json") != FINGERPRINT_SHA256:
        raise RuntimeError(f"Shared train-only fingerprint differs: {name}")
    provenance = read_json(staged / "planning_provenance.json")
    if (
        provenance.get("plans_source_dataset") != REFERENCE
        or provenance.get("plans_source_sha256") != PLAN_SHA256
        or provenance.get("fingerprint_source_sha256") != FINGERPRINT_SHA256
        or provenance.get("fingerprint_is_reference_not_target_statistic") is not True
        or provenance.get("target_split_sha256") != sha256(raw / "splits_final.json")
        or provenance.get("nnunetv2_version") != "2.8.1"
    ):
        raise RuntimeError(f"Planning provenance differs from frozen protocol: {name}")

    plan = read_json(staged / f"{PLAN_NAME}.json")
    if (
        plan.get("dataset_name") != name
        or plan.get("plans_name") != PLAN_NAME
        or plan.get("image_reader_writer") != source_plan.get("image_reader_writer")
        or not same_2d_plan(source_plan, plan)
    ):
        raise RuntimeError(f"Target 2D plan differs from shared reference: {name}")
    config = plan["configurations"]["2d"]
    identifier = config.get("data_identifier")
    if identifier != f"{PLAN_NAME}_2d" or not re.fullmatch(r"[A-Za-z0-9_]+", identifier):
        raise RuntimeError(f"Unexpected 2D output identifier: {name}")
    if config.get("use_mask_for_norm") != [False]:
        raise RuntimeError(f"Unexpected label-dependent normalization: {name}")

    dataset = read_json(raw / "dataset.json")
    split = read_json(raw / "splits_final.json")
    summary = read_json(raw / "preflight_summary.json")
    if dataset.get("labels") != {"background": 0, "LV": 1} or dataset.get("file_ending") != ".png":
        raise RuntimeError(f"Unexpected image/label specification: {name}")
    if not isinstance(split, list) or len(split) != 1:
        raise RuntimeError(f"Expected one frozen fold: {name}")
    train = split[0]["train"]
    val = split[0]["val"]
    if (
        summary.get("unit") != unit
        or summary.get("arm") != arm
        or summary.get("train_patients") != 10
        or summary.get("validation_patients") != 43
        or summary.get("validation_gt_slices") != 964
        or len(train) != summary["train_gt_slices"] + summary["train_pseudo_slices"]
        or len(val) != 964
        or len(train) + len(val) != dataset.get("numTraining")
        or len(train) != len(set(train))
        or len(val) != len(set(val))
        or set(train) & set(val)
        or (arm == "Cneg" and summary["train_pseudo_slices"] != 0)
    ):
        raise RuntimeError(f"Frozen patient/slice split does not close: {name}")
    expected = set(train) | set(val)
    raw_labels = {p.stem for p in (raw / "labelsTr").glob("*.png")}
    if raw_labels != expected:
        raise RuntimeError(f"Raw label cases differ from fixed split: {name}")
    output = staged / identifier
    if output.exists():
        verify_output(output, staged / "gt_segmentations", raw / "labelsTr", expected)
        state = "complete; verified; will not rerun"
    else:
        state = "not preprocessed"
    return {
        "id": dataset_id,
        "name": name,
        "staged": staged,
        "output": output,
        "expected": expected,
        "train": len(train),
        "val": len(val),
        "state": state,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, default=Path("/root/autodl-tmp"))
    parser.add_argument("--unit", choices=[f"u{i:02d}" for i in range(10)], default="u00")
    parser.add_argument("--arm", choices=("both", "B", "Cneg"), default="both")
    parser.add_argument("--write", action="store_true", help="Run 2D preprocessing for missing complete outputs")
    args = parser.parse_args()
    base = args.base.expanduser().resolve()
    source_plan_path = base / "nnUNet_preprocessed" / REFERENCE / "nnUNetPlans.json"
    source_fingerprint = base / "nnUNet_preprocessed" / REFERENCE / "dataset_fingerprint.json"
    if sha256(source_plan_path) != PLAN_SHA256 or sha256(source_fingerprint) != FINGERPRINT_SHA256:
        raise RuntimeError("Dataset900 shared plan or fingerprint differs from frozen u00-GT reference")
    source_plan = read_json(source_plan_path)
    if source_plan.get("dataset_name") != REFERENCE:
        raise RuntimeError("Dataset900 plan has unexpected dataset identity")

    venv = base / "nnunet-2.8.1-venv" / "bin"
    python = venv / "python"
    cli = venv / "nnUNetv2_preprocess"
    if not python.is_file() or not cli.is_file():
        raise FileNotFoundError("Pinned nnU-Net v2.8.1 environment or preprocessing CLI is missing")
    version = subprocess.check_output(
        [str(python), "-c", "import importlib.metadata as m; print(m.version('nnunetv2'))"],
        text=True,
    ).strip()
    if version != "2.8.1":
        raise RuntimeError(f"Expected nnunetv2 2.8.1, found {version}")
    subprocess.run(
        [str(python), "-c", "from distutils.file_util import copy_file; "
         "from nnunetv2.preprocessing.preprocessors.default_preprocessor import DefaultPreprocessor"],
        check=True,
    )

    arms = ("B", "Cneg") if args.arm == "both" else (args.arm,)
    targets = [inspect_target(base, args.unit, arm, source_plan) for arm in arms]
    for target in targets:
        print(
            f"{target['name']}: {target['train']} training + {target['val']} validation cases; "
            f"{target['state']}", flush=True
        )
    if not args.write:
        print(f"Preflight PASS: {len(targets)} staged arm(s). No files were written.")
        return 0

    env = os.environ.copy()
    env.update({
        "nnUNet_raw": str(base / "nnUNet_raw"),
        "nnUNet_preprocessed": str(base / "nnUNet_preprocessed"),
        "nnUNet_results": str(base / "nnUNet_results"),
    })
    for target in targets:
        if target["output"].exists():
            verify_output(
                target["output"], target["staged"] / "gt_segmentations",
                base / "nnUNet_raw" / target["name"] / "labelsTr", target["expected"]
            )
            print(f"Skipped existing complete output: {target['name']}", flush=True)
            continue  # never let nnU-Net delete a complete output
        command = [
            str(cli), "-d", str(target["id"]), "-c", "2d", "-np", "2",
            "-plans_name", PLAN_NAME,
        ]
        print(f"Preprocessing {target['name']} with 2 CPU workers...", flush=True)
        subprocess.run(command, check=True, env=env)
        verify_output(
            target["output"], target["staged"] / "gt_segmentations",
            base / "nnUNet_raw" / target["name"] / "labelsTr", target["expected"]
        )
        audit = {
            "status": "PASS",
            "dataset": target["name"],
            "unit": args.unit,
            "configuration": "2d",
            "plans_name": PLAN_NAME,
            "shared_plan_sha256": PLAN_SHA256,
            "shared_fingerprint_sha256": FINGERPRINT_SHA256,
            "target_plan_sha256": sha256(target["staged"] / f"{PLAN_NAME}.json"),
            "fixed_split_sha256": sha256(target["staged"] / "splits_final.json"),
            "cases_verified": len(target["expected"]),
            "training_cases": target["train"],
            "validation_cases": target["val"],
            "nnunetv2_version": version,
            "completed_utc": datetime.now(timezone.utc).isoformat(),
        }
        (target["staged"] / "preprocessing_audit.json").write_text(
            json.dumps(audit, indent=2) + "\n", encoding="utf-8"
        )
        print(f"Verified {target['name']}: {len(target['expected'])} complete cases", flush=True)
    print(f"PASS: {len(targets)} staged arm(s) complete; no training started.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
