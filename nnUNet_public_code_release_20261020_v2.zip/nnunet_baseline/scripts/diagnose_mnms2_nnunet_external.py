#!/usr/bin/env python3
"""Read-only, aggregate-only diagnostics for the audited nnU-Net external EF run.

Run on the cloud instance. The private case table is read into memory only;
patient keys and individual case values are never written or printed.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import statistics
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path


UNITS = tuple(f"u{i:02d}" for i in range(10))
ARMS = ("B", "Cneg")
VENDORS = {"Philips": 88, "GE": 53}
EXPECTED_MODELS = {(unit, arm) for unit in UNITS for arm in ARMS}
EXPECTED_OUTPUTS = {
    "private/slice_metrics_PRIVATE.csv",
    "private/case_metrics_PRIVATE.csv",
    "private/paired_case_metrics_PRIVATE.csv",
    "public/unit_arm_vendor_summary.csv",
    "public/paired_unit_vendor_summary.csv",
    "public/paired_overall_summary.csv",
}
FIELDS = {
    "unit", "arm", "vendor", "patient_key", "edv_gt_ml", "esv_gt_ml",
    "ef_gt_pct", "edv_pred_ml", "esv_pred_ml", "ef_pred_pct",
    "ef_invalid", "ef_out_of_range", "ef_error_pp", "ef_abs_error_pp",
    "edv_abs_error_ml", "esv_abs_error_ml",
}
EF_MIN_EDV_ML = 1e-6


class DiagnosticError(Exception):
    """A sanitized diagnostic failure with no private row contents."""


@dataclass(frozen=True)
class Case:
    unit: str
    arm: str
    vendor: str
    patient_key: str
    edv_pred_ml: float
    ef_pred_pct: float | None
    ef_invalid: bool
    ef_out_of_range: bool
    ef_abs_error_pp: float | None


def require(condition: bool, message: str) -> None:
    if not condition:
        raise DiagnosticError(message)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    try:
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(chunk)
    except OSError:
        raise DiagnosticError("An audited output file is missing or unreadable") from None
    return digest.hexdigest()


def verify_audit(root: Path) -> int:
    try:
        with (root / "public" / "evaluation_audit.json").open(encoding="utf-8") as stream:
            audit = json.load(stream)
    except (OSError, ValueError):
        raise DiagnosticError("The evaluation audit is missing or unreadable") from None
    require(isinstance(audit, dict), "The evaluation audit has the wrong structure")
    required = {
        "schema": "mnms2_nnunet_external_evaluation_v1", "status": "PASS",
        "rep": "rep00", "models": 20, "cases_per_model": 3072,
        "patients_per_model": 141,
        "ef_formula": "100*(EDV-ESV)/EDV; EDV<=1e-6 mL is invalid",
    }
    require(all(audit.get(key) == value for key, value in required.items()),
            "The evaluation audit identity or EF policy differs from rep00")
    model_names = {f"{unit}_{arm}" for unit, arm in EXPECTED_MODELS}
    for name in ("checkpoint_sha256", "prediction_inventories", "prediction_audit_sha256"):
        values = audit.get(name)
        require(isinstance(values, dict) and set(values) == model_names,
                "The evaluation audit lacks the expected 20 models")
    hashes = audit.get("output_sha256")
    require(isinstance(hashes, dict) and set(hashes) == EXPECTED_OUTPUTS,
            "The evaluation audit has an incomplete output inventory")
    for relative in sorted(EXPECTED_OUTPUTS):
        expected = hashes[relative]
        require(isinstance(expected, str) and len(expected) == 64
                and all(char in "0123456789abcdef" for char in expected),
                "The evaluation audit contains an invalid output checksum")
        require(sha256(root / relative) == expected,
                "An evaluation output differs from its audited SHA256")
    return len(EXPECTED_OUTPUTS)


def number(row: dict[str, str], field: str, *, blank: bool = False) -> float | None:
    raw = row.get(field)
    if raw is None or raw == "":
        if blank:
            return None
        raise DiagnosticError("The private case table has a missing numeric field")
    try:
        value = float(raw)
    except ValueError:
        raise DiagnosticError("The private case table has a nonnumeric field") from None
    require(math.isfinite(value), "The private case table has a nonfinite numeric field")
    return value


def flag(row: dict[str, str], field: str) -> bool:
    require(row.get(field) in ("0", "1"), "The private case table has an invalid flag")
    return row[field] == "1"


def close(observed: float, expected: float) -> bool:
    return math.isclose(observed, expected, rel_tol=1e-9, abs_tol=1e-7)


def checked_case(row: dict[str, str]) -> Case:
    unit, arm, vendor, patient_key = (row.get(field, "") for field in
                                      ("unit", "arm", "vendor", "patient_key"))
    require((unit, arm) in EXPECTED_MODELS and vendor in VENDORS and bool(patient_key),
            "The private case table has an unexpected model, vendor, or empty patient key")
    edv_gt = number(row, "edv_gt_ml")
    esv_gt = number(row, "esv_gt_ml")
    edv_pred = number(row, "edv_pred_ml")
    esv_pred = number(row, "esv_pred_ml")
    ef_gt = number(row, "ef_gt_pct")
    ef_pred = number(row, "ef_pred_pct", blank=True)
    error = number(row, "ef_error_pp", blank=True)
    abs_error = number(row, "ef_abs_error_pp", blank=True)
    edv_abs_error = number(row, "edv_abs_error_ml")
    esv_abs_error = number(row, "esv_abs_error_ml")
    invalid = flag(row, "ef_invalid")
    out_of_range = flag(row, "ef_out_of_range")
    require(all(volume >= 0 for volume in (edv_gt, esv_gt, edv_pred, esv_pred))
            and edv_gt > EF_MIN_EDV_ML,
            "The private case table has an invalid volume")
    expected_gt = 100.0 * (edv_gt - esv_gt) / edv_gt
    require(math.isfinite(expected_gt) and close(ef_gt, expected_gt),
            "Ground-truth EF does not match EDV and ESV")
    expected_pred = (100.0 * (edv_pred - esv_pred) / edv_pred
                     if edv_pred > EF_MIN_EDV_ML else None)
    expected_invalid = expected_pred is None or not math.isfinite(expected_pred)
    require(invalid == expected_invalid, "An EF invalid flag contradicts the EDV rule")
    require(close(edv_abs_error, abs(edv_pred - edv_gt))
            and close(esv_abs_error, abs(esv_pred - esv_gt)),
            "A volume absolute error does not match its volumes")
    if invalid:
        require(ef_pred is None and error is None and abs_error is None and not out_of_range,
                "An invalid EF row has inconsistent result fields")
    else:
        require(ef_pred is not None and error is not None and abs_error is not None,
                "A valid EF row has missing result fields")
        require(close(ef_pred, expected_pred)
                and close(error, expected_pred - expected_gt)
                and close(abs_error, abs(expected_pred - expected_gt)),
                "A valid EF row does not match the independent EF calculation")
        require(out_of_range == (expected_pred < 0.0 or expected_pred > 100.0),
                "An EF out-of-range flag contradicts the calculated EF")
    return Case(unit, arm, vendor, patient_key, edv_pred, ef_pred,
                invalid, out_of_range, abs_error)


def read_cases(root: Path) -> dict[tuple[str, str, str], Case]:
    path = root / "private" / "case_metrics_PRIVATE.csv"
    result: dict[tuple[str, str, str], Case] = {}
    patients_by_model: dict[tuple[str, str], dict[str, str]] = defaultdict(dict)
    reference_gt: dict[str, tuple[float, float, float]] = {}
    try:
        with path.open(newline="", encoding="utf-8-sig") as stream:
            reader = csv.DictReader(stream)
            require(reader.fieldnames is not None and FIELDS <= set(reader.fieldnames),
                    "The private case table is missing required columns")
            for row in reader:
                case = checked_case(row)
                key = (case.unit, case.arm, case.patient_key)
                require(key not in result, "The private case table has duplicate model-patient rows")
                result[key] = case
                patients_by_model[case.unit, case.arm][case.patient_key] = case.vendor
                gt = (number(row, "edv_gt_ml"), number(row, "esv_gt_ml"),
                      number(row, "ef_gt_pct"))
                prior = reference_gt.setdefault(case.patient_key, gt)
                require(all(close(a, b) for a, b in zip(prior, gt)),
                        "Ground-truth measurements differ across models")
    except (OSError, UnicodeError, csv.Error):
        raise DiagnosticError("The private case table is missing or unreadable") from None
    require(len(result) == 20 * 141 and set(patients_by_model) == EXPECTED_MODELS,
            "The private case table does not contain exactly 20 x 141 rows")
    reference = patients_by_model[UNITS[0], ARMS[0]]
    require(Counter(reference.values()) == Counter(VENDORS),
            "The private case table differs from the 88 Philips / 53 GE cohort")
    require(all(mapping == reference for mapping in patients_by_model.values()),
            "The patient-vendor cohort differs across models")
    return result


def quantile(values: list[float], q: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    pos = (len(ordered) - 1) * q
    low, high = math.floor(pos), math.ceil(pos)
    return ordered[low] + (ordered[high] - ordered[low]) * (pos - low)


def summarize_arm(rows: list[Case]) -> dict:
    errors = [row.ef_abs_error_pp for row in rows if not row.ef_invalid]
    predictions = [row.ef_pred_pct for row in rows if not row.ef_invalid]
    return {
        "evaluations": len(rows),
        "valid": len(errors),
        "invalid": len(rows) - len(errors),
        "pred_edv_le_1e_6_ml": sum(row.edv_pred_ml <= EF_MIN_EDV_ML for row in rows),
        "ef_out_of_range": sum(row.ef_out_of_range for row in rows),
        "ef_below_0_pct": sum(value < 0.0 for value in predictions),
        "ef_above_100_pct": sum(value > 100.0 for value in predictions),
        "ae_gt_20_pp": sum(value > 20.0 for value in errors),
        "ae_gt_40_pp": sum(value > 40.0 for value in errors),
        "ae_gt_100_pp": sum(value > 100.0 for value in errors),
        "ae_gt_500_pp": sum(value > 500.0 for value in errors),
        "ae_mean_pp": statistics.fmean(errors) if errors else None,
        "ae_median_pp": quantile(errors, 0.5),
        "ae_p90_pp": quantile(errors, 0.9),
        "ae_p99_pp": quantile(errors, 0.99),
        "ae_max_pp": max(errors) if errors else None,
    }


def summarize_pairs(rows: list[Case]) -> dict:
    by_patient_unit: dict[tuple[str, str], dict[str, Case]] = defaultdict(dict)
    for row in rows:
        by_patient_unit[row.unit, row.patient_key][row.arm] = row
    differences: list[float] = []
    b_invalid = c_invalid = both_invalid = 0
    valid_first_b_wins = valid_first_c_wins = valid_first_ties = 0
    for arms in by_patient_unit.values():
        require(set(arms) == set(ARMS), "A paired model-patient row is missing")
        b, c = arms["B"], arms["Cneg"]
        b_invalid += b.ef_invalid
        c_invalid += c.ef_invalid
        both_invalid += b.ef_invalid and c.ef_invalid
        if b.ef_invalid and c.ef_invalid:
            valid_first_ties += 1
        elif b.ef_invalid:
            valid_first_c_wins += 1
        elif c.ef_invalid:
            valid_first_b_wins += 1
        else:
            delta = b.ef_abs_error_pp - c.ef_abs_error_pp
            differences.append(delta)
            if delta < 0:
                valid_first_b_wins += 1
            elif delta > 0:
                valid_first_c_wins += 1
            else:
                valid_first_ties += 1
    return {
        "pairs": len(by_patient_unit),
        "validity_2x2": {
            "both_valid": len(differences),
            "b_only_valid": c_invalid - both_invalid,
            "cneg_only_valid": b_invalid - both_invalid,
            "both_invalid": both_invalid,
        },
        "paired_valid": len(differences),
        "paired_missing": len(by_patient_unit) - len(differences),
        "b_invalid": b_invalid,
        "cneg_invalid": c_invalid,
        "both_invalid": both_invalid,
        "b_only_invalid": b_invalid - both_invalid,
        "cneg_only_invalid": c_invalid - both_invalid,
        "delta_valid_pair_weighted_mean_pp": statistics.fmean(differences) if differences else None,
        "delta_pooled_valid_pair_median_pp": quantile(differences, 0.5),
        "delta_pooled_valid_pair_p90_pp": quantile(differences, 0.9),
        "delta_pooled_valid_pair_p99_pp": quantile(differences, 0.99),
        "delta_pooled_valid_pair_max_pp": max(differences) if differences else None,
        "delta_gt_100_pp": sum(value > 100.0 for value in differences),
        "delta_gt_500_pp": sum(value > 500.0 for value in differences),
        "exploratory_posthoc_valid_first": {
            "rule": "valid EF wins over invalid; if both valid, lower EF absolute error wins; equal status/error ties",
            "b_wins": valid_first_b_wins,
            "cneg_wins": valid_first_c_wins,
            "ties": valid_first_ties,
        },
    }


def diagnose(root: Path) -> dict:
    verified = verify_audit(root)
    cases = read_cases(root)
    rows = list(cases.values())
    vendor_results = []
    for vendor in ("Philips", "GE", "All"):
        selected = [row for row in rows if vendor == "All" or row.vendor == vendor]
        vendor_results.append({
            "vendor": vendor,
            "arms": {arm: summarize_arm([row for row in selected if row.arm == arm])
                     for arm in ARMS},
            "paired": summarize_pairs(selected),
        })
    focus_results = []
    for unit, vendor in (("u03", "GE"), ("u02", "Philips"), ("u04", "All")):
        selected = [row for row in rows if row.unit == unit
                    and (vendor == "All" or row.vendor == vendor)]
        focus_results.append({
            "unit": unit, "vendor": vendor,
            "arms": {arm: summarize_arm([row for row in selected if row.arm == arm])
                     for arm in ARMS},
            "paired": summarize_pairs(selected),
        })
    return {
        "status": "PASS", "rep": "rep00", "audited_csv_checksums_verified": verified,
        "models": 20, "case_rows": len(rows),
        "interpretation": (
            "Negative paired B-minus-Cneg delta favors B. All 1410 unit-patient pairs reuse the same "
            "141 patients across 10 units. The diagnostic delta mean pools available valid pairs and weights "
            "units by their valid-pair counts; it is not the frozen equal-unit partial mean or the primary "
            "complete EF-MAE endpoint. Invalid EF is excluded from numerical EF errors. Valid-first "
            "win/loss/tie counts are post-hoc exploratory."
        ),
        "by_vendor": vendor_results,
        "focus": focus_results,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evaluation-dir", type=Path,
                        default=Path("/root/autodl-tmp/nnUNet_external_evaluation/rep00"),
                        help="Existing audited rep00 evaluation directory (read only)")
    args = parser.parse_args()
    try:
        result = diagnose(args.evaluation_dir.expanduser())
    except DiagnosticError as exc:
        print(f"Diagnostic FAIL: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, indent=2, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
