#!/usr/bin/env python3
"""Conditional technical audit of frozen rep00 Philips/GE nnU-Net EF failures.

This separate v2 preserves the strict v1 file. Unknown spatial units require
the explicit --allow-unknown-spatial-units flag. Known non-mm units still fail.
An accepted unknown header is not evidence that its axes are millimetres:
recomputed volumes retain the frozen abs(det(affine))/1000 convention only as
an assumption. This script never emits the unqualified status PASS.

Run on the original cloud instance, with the same Python environment as the
frozen evaluator. The default verifies the six audited CSV checksums, all
20 model/checkpoint/prediction inventories, every source/staged ED/ES slice,
the original GT NIfTI LV label against exported GT PNGs, and independently
recomputes all 61,440 slice and 2,820 case metrics. It prints only aggregate
JSON. ``--write`` additionally saves this same aggregate JSON outside the
frozen evaluation directory; it never writes patient-level data.

The cutoffs below are post-hoc quality-control flags, not replacement EF
endpoints. In particular, the frozen EF-invalid rule is EDV <= 1e-6 mL and
remains unchanged. A file/phase match does not certify independent clinical
truth of the ED/ES frame annotation.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import os
import sys
from collections import Counter, defaultdict
from pathlib import Path

# Importing these frozen scripts must not create bytecode next to them.
sys.dont_write_bytecode = True

import numpy as np

import diagnose_mnms2_nnunet_external as diagnostic
import evaluate_mnms2_nnunet_external as evaluator


REP = "rep00"
FIXED_TAIL_THRESHOLDS_PP = (100.0, 500.0)
EXPECTED_CASE_ROWS = 20 * 141
EXPECTED_SLICE_ROWS = 20 * evaluator.EXPECTED_CASES
DEFAULT_NEAR_ZERO_ML = 1.0
DEFAULT_NEAR_ZERO_FRACTION = 0.05
FLAG_NAMES = (
    "undefined_ef", "finite_ef_out_of_range", "finite_ef_below_0_pct",
    "finite_ef_above_100_pct", "finite_above_100_precision_boundary",
    "finite_abs_ef_error_gt_100_pp", "finite_abs_ef_error_gt_500_pp",
    "pred_edv_lt_configured_ml", "pred_edv_lt_configured_fraction_of_gt",
    "pred_esv_gt_edv", "core_failure_or_tail_union", "all_flag_union",
)
COUNT_ONLY_NAMES = (
    "equal_numeric_ed_es_scale_evaluations",
    "unequal_numeric_ed_es_scale_evaluations_skipped",
    "reference_ef_checked_from_counts", "predicted_finite_ef_checked_from_counts",
    "zero_predicted_ed_foreground_count", "positive_count_threshold_invalid",
    "undefined_matches_zero_predicted_ed_count",
)


class FullAuditError(Exception):
    """A fixed failure category with no patient key, path, or row content."""


def require(condition: bool, category: str) -> None:
    if not condition:
        raise FullAuditError(category)


def protected(category: str, function, *args):
    """Suppress exceptions from private input paths and rows."""
    try:
        return function(*args)
    except FullAuditError:
        raise
    except Exception:
        raise FullAuditError(category) from None


def rows(path: Path, category: str) -> list[dict[str, str]]:
    try:
        with path.open(newline="", encoding="utf-8-sig") as stream:
            reader = csv.DictReader(stream)
            require(reader.fieldnames is not None, category)
            return list(reader)
    except (OSError, UnicodeError, csv.Error):
        raise FullAuditError(category) from None


def number(row: dict[str, str], name: str, category: str,
           *, nullable: bool = False) -> float | None:
    raw = row.get(name)
    if raw is None or raw == "":
        require(nullable and raw == "", category)
        return None
    try:
        value = float(raw)
    except (TypeError, ValueError):
        raise FullAuditError(category) from None
    require(math.isfinite(value), category)
    return value


def integer(row: dict[str, str], name: str, category: str) -> int:
    try:
        value = int(row[name])
    except (KeyError, TypeError, ValueError):
        raise FullAuditError(category) from None
    return value


def close(observed: float, expected: float) -> bool:
    return math.isclose(observed, expected, rel_tol=1e-9, abs_tol=1e-7)


def check_number(row: dict[str, str], name: str, actual: float,
                 category: str = "case_metrics") -> None:
    require(close(number(row, name, category), actual), category)


def check_nullable_number(row: dict[str, str], name: str,
                          actual: float | None, category: str) -> None:
    observed = number(row, name, category, nullable=True)
    require((observed is None and actual is None)
            or (observed is not None and actual is not None and close(observed, actual)),
            category)


def dice(intersection: int, prediction: int, ground_truth: int) -> float:
    denominator = prediction + ground_truth
    return 1.0 if denominator == 0 else 2.0 * intersection / denominator


def ef(edv: float, esv: float) -> float | None:
    return 100.0 * (edv - esv) / edv if edv > diagnostic.EF_MIN_EDV_ML else None


def load_private_case_rows(root: Path, diagnostic_cases: dict) -> dict:
    result = {}
    for row in rows(root / "private" / "case_metrics_PRIVATE.csv", "case_table"):
        key = (row.get("unit"), row.get("arm"), row.get("patient_key"))
        require(key in diagnostic_cases and key not in result
                and row.get("vendor") == diagnostic_cases[key].vendor,
                "case_table")
        result[key] = row
    require(len(result) == EXPECTED_CASE_ROWS, "case_table")
    return result


def load_private_slice_rows(root: Path, external_cases: list[evaluator.Case]) -> dict:
    expected = {case.case_id: case for case in external_cases}
    result = {}
    for row in rows(root / "private" / "slice_metrics_PRIVATE.csv", "slice_table"):
        unit, arm, case_id = row.get("unit"), row.get("arm"), row.get("case_id")
        require(unit in evaluator.UNITS and arm in evaluator.ARMS
                and case_id in expected, "slice_table")
        case = expected[case_id]
        key = (unit, arm, case_id)
        require(key not in result and row.get("patient_key") == case.key
                and row.get("vendor") == case.vendor
                and row.get("phase") == case.phase
                and integer(row, "z", "slice_table") == case.z,
                "slice_table")
        result[key] = row
    require(len(result) == EXPECTED_SLICE_ROWS, "slice_table")
    return result


def verify_frozen_identity(base: Path, root: Path, audit: dict,
                           models: list[dict], stage_sha: str,
                           physical_sha: str) -> None:
    expected_names = {f"{unit}_{arm}" for unit in evaluator.UNITS
                      for arm in evaluator.ARMS}
    require(audit.get("manifest_sha256") == evaluator.MANIFEST_SHA256
            and audit.get("stage_audit_sha256") == stage_sha
            and audit.get("physical_input_audit_sha256") == physical_sha
            and audit.get("evaluator_script_sha256")
            == evaluator.sha256(Path(evaluator.__file__).resolve()),
            "evaluation_provenance")
    for field, value_field in (
        ("checkpoint_sha256", "checkpoint_sha256"),
        ("prediction_inventories", "prediction_inventory_sha256"),
        ("prediction_audit_sha256", "prediction_audit_sha256"),
    ):
        observed = audit.get(field)
        require(isinstance(observed, dict) and set(observed) == expected_names,
                "evaluation_provenance")
        for model in models:
            name = f"{model['unit']}_{model['arm']}"
            require(observed[name] == model[value_field], "evaluation_provenance")
    # The stage and physical audit paths are frozen; this check needs no writes.
    require((base / "nnUNet_external_evaluation" / REP).resolve() == root.resolve(),
            "evaluation_provenance")


def exported_u8_frames(raw_volume: np.ndarray) -> np.ndarray:
    """Independently reproduce the frozen exporter's volume-wide 1/99 stretch."""
    frames = np.transpose(raw_volume, (2, 0, 1)).astype(np.float32)
    low, high = np.percentile(frames, 1.0), np.percentile(frames, 99.0)
    if high <= low:
        low, high = float(frames.min()), float(frames.max() + 1e-6)
    return np.ascontiguousarray(
        (np.clip((frames - low) / (high - low), 0, 1) * 255 + 0.5)
        .astype(np.uint8))


def spatial_unit_category(unit: str, allow_unknown: bool) -> str:
    """Permit only mm or nibabel's explicit unspecified-unit representation."""
    if unit == "mm":
        return "mm"
    require(unit == "unknown" and allow_unknown, "nifti_spatial_units")
    return "unknown"


def source_reference_and_geometry(
    base: Path, external_cases: list[evaluator.Case],
    stage_map: dict[str, dict[str, str]], physical: dict[str, str],
    allow_unknown_spatial_units: bool = False,
) -> tuple[dict[str, np.ndarray], dict[tuple[str, str], float], dict[str, int]]:
    """Check exported LV PNG exactly against label 1 in its phase-specific NIfTI."""
    import nibabel as nib

    source_root = base / "mnms" / "seg_lv" / "all"
    grouped: dict[tuple[str, str], list[evaluator.Case]] = defaultdict(list)
    for case in external_cases:
        grouped[case.key, case.phase].append(case)
    references: dict[str, np.ndarray] = {}
    scales: dict[tuple[str, str], float] = {}
    affines: dict[str, dict[str, np.ndarray]] = defaultdict(dict)
    raw_image_nifti_hashed = 0
    unit_counts = Counter()
    unknown_patients = set()
    for (key, phase), stack in sorted(grouped.items()):
        nii_path = (base / "mnms" / "MnM2" / "dataset" / key
                    / f"{key}_SA_{phase.upper()}_gt.nii.gz")
        raw_path = (base / "mnms" / "MnM2" / "dataset" / key
                    / f"{key}_SA_{phase.upper()}.nii.gz")
        evaluator.checked_file(nii_path, physical.get(str(nii_path)),
                               "Original GT NIfTI")
        image = nib.load(str(nii_path))
        raw_image = nib.load(str(raw_path))
        require(len(image.shape) == 3 and image.shape[2] == len(stack),
                "nifti_geometry")
        require(raw_image.shape == image.shape, "raw_image_nifti_geometry")
        affine = np.asarray(image.affine, dtype=float)
        raw_affine = np.asarray(raw_image.affine, dtype=float)
        require(affine.shape == (4, 4) and np.isfinite(affine).all(),
                "nifti_geometry")
        require(raw_affine.shape == (4, 4) and np.isfinite(raw_affine).all()
                and np.allclose(raw_affine, affine, rtol=1e-6, atol=1e-5),
                "raw_image_gt_affine")
        # Preserve the frozen numerical formula. With unknown units, its mL
        # interpretation is explicitly unverified rather than silently repaired.
        gt_unit = spatial_unit_category(image.header.get_xyzt_units()[0],
                                        allow_unknown_spatial_units)
        raw_unit = spatial_unit_category(raw_image.header.get_xyzt_units()[0],
                                         allow_unknown_spatial_units)
        unit_counts[f"gt_{gt_unit}"] += 1
        unit_counts[f"raw_{raw_unit}"] += 1
        if "unknown" in (gt_unit, raw_unit):
            unit_counts["any_unknown"] += 1
            unknown_patients.add(key)
        else:
            unit_counts["both_mm"] += 1
        scale = abs(float(np.linalg.det(affine[:3, :3]))) / 1000.0
        require(math.isfinite(scale) and scale > 0.0, "nifti_geometry")
        raw_expected_sha = physical.get(str(raw_path))
        if raw_expected_sha is not None:
            evaluator.checked_file(raw_path, raw_expected_sha,
                                   "Original raw-image NIfTI")
            raw_image_nifti_hashed += 1
        scales[key, phase] = scale
        affines[key][phase] = affine
        volume = image.get_fdata()
        raw_volume = raw_image.get_fdata()
        require(np.isfinite(volume).all(), "nifti_gt_labels")
        require(np.isfinite(raw_volume).all(), "raw_image_nifti")
        exported_frames = exported_u8_frames(raw_volume)
        for case in stack:
            mapped = stage_map.get(case.case_id)
            source_gt = evaluator.inside(source_root, case.gt_rel)
            source_img = evaluator.inside(source_root, case.img_rel)
            require(mapped is not None
                    and mapped.get("patient_key") == case.key
                    and mapped.get("phase") == phase
                    and mapped.get("z") == str(case.z)
                    and mapped.get("gt_rel") == case.gt_rel
                    and mapped.get("image_rel") == case.img_rel
                    and mapped.get("source_gt_sha256") == physical.get(str(source_gt))
                    and mapped.get("source_image_sha256") == physical.get(str(source_img)),
                    "source_stage_mapping")
            evaluator.checked_file(source_img, physical.get(str(source_img)),
                                   "Original source image PNG")
            exported = evaluator.binary_mask(source_gt, {0, 255}, 127)
            source_image = evaluator.read_gray(source_img)
            require(exported.shape == source_image.shape == image.shape[:2],
                    "source_png_geometry")
            require(np.array_equal(source_image, exported_frames[case.z]),
                    "raw_image_png_export")
            original_lv = np.rint(volume[:, :, case.z]) == 1
            require(np.array_equal(exported, original_lv), "nifti_png_lv_mapping")
            require(int(exported.sum()) == case.gt_px_manifest,
                    "manifest_gt_pixels")
            references[case.case_id] = exported
    require(len(references) == evaluator.EXPECTED_CASES
            and len(scales) == 2 * len(affines),
            "source_reference_coverage")
    affine_changed = 0
    voxel_scale_changed = 0
    for phases in affines.values():
        require(set(phases) == {"ed", "es"}, "nifti_geometry")
        if not np.allclose(phases["ed"], phases["es"], rtol=1e-7, atol=1e-7):
            affine_changed += 1
        # Different ED/ES geometry is reported, not silently coerced.
    for key in affines:
        if not close(scales[key, "ed"], scales[key, "es"]):
            voxel_scale_changed += 1
    return references, scales, {
        "source_gt_pngs_compared_to_nifti_lv_label": len(references),
        "source_image_pngs_compared_to_current_raw_nifti_export": len(references),
        "raw_image_nifti_stacks_with_frozen_sha256": raw_image_nifti_hashed,
        "nifti_spatial_units_mm_stacks": unit_counts["both_mm"],
        "nifti_gt_spatial_units_mm_stacks": unit_counts["gt_mm"],
        "nifti_gt_spatial_units_unknown_stacks": unit_counts["gt_unknown"],
        "nifti_raw_spatial_units_mm_stacks": unit_counts["raw_mm"],
        "nifti_raw_spatial_units_unknown_stacks": unit_counts["raw_unknown"],
        "nifti_phase_stacks_with_any_unknown_spatial_units": unit_counts["any_unknown"],
        "patients_with_any_unknown_spatial_units": len(unknown_patients),
        "nifti_known_non_mm_spatial_units_accepted": 0,
        "unknown_spatial_units_allowed_by_explicit_flag": allow_unknown_spatial_units,
        "ed_es_affine_different_patients": affine_changed,
        "ed_es_voxel_volume_different_patients": voxel_scale_changed,
    }


def fresh_phase_counts() -> dict[str, float]:
    return {
        "gt_px": 0, "pred_px": 0, "intersection_px": 0, "slices": 0,
        "present_slices": 0, "empty_gt_slices": 0,
        "empty_gt_fp_slices": 0, "empty_gt_fp_px": 0,
        "present_gt_px": 0, "present_pred_px": 0,
        "present_intersection_px": 0, "present_slice_dice_sum": 0.0,
    }


def verify_slice(prediction: np.ndarray, ground_truth: np.ndarray,
                 stored: dict[str, str]) -> dict[str, float]:
    require(prediction.shape == ground_truth.shape, "prediction_png_geometry")
    gt_px = int(ground_truth.sum())
    pred_px = int(prediction.sum())
    intersection = int(np.logical_and(prediction, ground_truth).sum())
    present = gt_px > 0
    empty_fp_px = pred_px if not present else 0
    observed = dice(intersection, pred_px, gt_px)
    for field, actual in (
        ("gt_px", gt_px), ("pred_px", pred_px),
        ("intersection_px", intersection), ("gt_present", int(present)),
        ("empty_gt_fp_px", empty_fp_px),
    ):
        require(integer(stored, field, "slice_metrics") == actual,
                "slice_metrics")
    check_number(stored, "dice", observed, "slice_metrics")
    return {
        "gt_px": gt_px, "pred_px": pred_px,
        "intersection_px": intersection, "slices": 1,
        "present_slices": int(present),
        "empty_gt_slices": int(not present),
        "empty_gt_fp_slices": int(not present and pred_px > 0),
        "empty_gt_fp_px": empty_fp_px,
        "present_gt_px": gt_px if present else 0,
        "present_pred_px": pred_px if present else 0,
        "present_intersection_px": intersection if present else 0,
        "present_slice_dice_sum": observed if present else 0.0,
    }


def phase_metrics(counts: dict[str, float], scale: float) -> dict[str, float | None]:
    present = int(counts["present_slices"])
    return {
        "gt_volume_ml": counts["gt_px"] * scale,
        "pred_volume_ml": counts["pred_px"] * scale,
        "dice_full_stack": dice(int(counts["intersection_px"]),
                                int(counts["pred_px"]), int(counts["gt_px"])),
        "dice_volume_present": (
            dice(int(counts["present_intersection_px"]),
                 int(counts["present_pred_px"]),
                 int(counts["present_gt_px"])) if present else None
        ),
        "dice_slice_present": counts["present_slice_dice_sum"] / present
        if present else None,
        **{name: counts[name] for name in (
            "slices", "present_slices", "empty_gt_slices",
            "empty_gt_fp_slices", "empty_gt_fp_px")},
    }


def verify_case(stored: dict[str, str], ed: dict, es: dict) -> dict[str, float | bool | None]:
    for phase, actual in (("ed", ed), ("es", es)):
        for field, value in actual.items():
            check_nullable_number(stored, f"{phase}_{field}", value,
                                  "case_metrics")
    for field, actual in (
        ("edv_gt_ml", ed["gt_volume_ml"]),
        ("edv_pred_ml", ed["pred_volume_ml"]),
        ("esv_gt_ml", es["gt_volume_ml"]),
        ("esv_pred_ml", es["pred_volume_ml"]),
        ("edv_abs_error_ml", abs(ed["pred_volume_ml"] - ed["gt_volume_ml"])),
        ("esv_abs_error_ml", abs(es["pred_volume_ml"] - es["gt_volume_ml"])),
    ):
        check_number(stored, field, actual)
    ground_truth_ef = ef(ed["gt_volume_ml"], es["gt_volume_ml"])
    predicted_ef = ef(ed["pred_volume_ml"], es["pred_volume_ml"])
    require(ground_truth_ef is not None and math.isfinite(ground_truth_ef),
            "reference_ef")
    invalid = predicted_ef is None or not math.isfinite(predicted_ef)
    out_of_range = not invalid and not 0.0 <= predicted_ef <= 100.0
    error = None if invalid else predicted_ef - ground_truth_ef
    absolute_error = None if error is None else abs(error)
    check_number(stored, "ef_gt_pct", ground_truth_ef)
    for field, actual in (
        ("ef_pred_pct", None if invalid else predicted_ef),
        ("ef_error_pp", error), ("ef_abs_error_pp", absolute_error),
    ):
        check_nullable_number(stored, field, actual, "case_metrics")
    require(integer(stored, "ef_invalid", "case_metrics") == int(invalid)
            and integer(stored, "ef_out_of_range", "case_metrics")
            == int(out_of_range), "case_metrics")
    return {
        "gt_edv_ml": ed["gt_volume_ml"],
        "pred_edv_ml": ed["pred_volume_ml"],
        "pred_esv_ml": es["pred_volume_ml"],
        "pred_ef_pct": None if invalid else predicted_ef,
        "undefined_ef": invalid,
        "finite_ef_out_of_range": out_of_range,
        "abs_error_pp": absolute_error,
    }


def classify_case(case: dict, near_zero_ml: float,
                  near_zero_fraction: float) -> dict[str, bool]:
    ef_pred = case["pred_ef_pct"]
    abs_error = case["abs_error_pp"]
    finite = not case["undefined_ef"]
    above_100 = finite and ef_pred > 100.0
    # Preserve the evaluator's exact out-of-range flag. The separate boundary
    # count describes EF > 100 at ESV=0 by floating-point arithmetic only.
    precision_boundary = (above_100 and case["pred_esv_ml"] == 0.0
                          and ef_pred - 100.0 <= 64.0 * math.ulp(100.0))
    flags = {
        "undefined_ef": case["undefined_ef"],
        "finite_ef_out_of_range": case["finite_ef_out_of_range"],
        "finite_ef_below_0_pct": finite and ef_pred < 0.0,
        "finite_ef_above_100_pct": above_100,
        "finite_above_100_precision_boundary": precision_boundary,
        "finite_abs_ef_error_gt_100_pp": finite and abs_error > 100.0,
        "finite_abs_ef_error_gt_500_pp": finite and abs_error > 500.0,
        "pred_edv_lt_configured_ml": case["pred_edv_ml"] < near_zero_ml,
        "pred_edv_lt_configured_fraction_of_gt": (
            case["pred_edv_ml"] < near_zero_fraction * case["gt_edv_ml"]
        ),
        "pred_esv_gt_edv": case["pred_esv_ml"] > case["pred_edv_ml"],
    }
    flags["core_failure_or_tail_union"] = any(flags[name] for name in (
        "undefined_ef", "finite_ef_out_of_range",
        "finite_abs_ef_error_gt_100_pp"))
    flags["all_flag_union"] = any(flags.values())
    require(set(flags) == set(FLAG_NAMES), "diagnostic_flag_policy")
    require(flags["finite_abs_ef_error_gt_500_pp"]
            <= flags["finite_abs_ef_error_gt_100_pp"], "diagnostic_flag_policy")
    require(flags["finite_above_100_precision_boundary"]
            <= flags["finite_ef_above_100_pct"], "diagnostic_flag_policy")
    return flags


def verify_count_only_ef(ed_counts: dict, es_counts: dict,
                         ed_scale: float, es_scale: float,
                         stored: dict, measured: dict) -> dict[str, int]:
    """Independently check EF from foreground counts without physical-unit claims.

    This numeric cancellation check is eligible only when the numeric ED/ES
    scale factors agree (relative tolerance 1e-12, no absolute tolerance).
    It deliberately does not recalculate or replace frozen out-of-range flags.
    """
    counts = {name: 0 for name in COUNT_ONLY_NAMES}
    ed_prediction = int(ed_counts["pred_px"])
    es_prediction = int(es_counts["pred_px"])
    ed_reference = int(ed_counts["gt_px"])
    es_reference = int(es_counts["gt_px"])
    require(ed_prediction >= 0 and es_prediction >= 0
            and ed_reference > 0 and es_reference >= 0,
            "count_only_ef_counts")
    zero_prediction = ed_prediction == 0
    invalid = measured["undefined_ef"]
    counts["zero_predicted_ed_foreground_count"] = int(zero_prediction)
    counts["positive_count_threshold_invalid"] = int(invalid and not zero_prediction)
    require(invalid == zero_prediction, "count_only_undefined_not_zero_ed")
    counts["undefined_matches_zero_predicted_ed_count"] = int(invalid)
    equal = math.isclose(ed_scale, es_scale, rel_tol=1e-12, abs_tol=0.0)
    if not equal:
        counts["unequal_numeric_ed_es_scale_evaluations_skipped"] = 1
        return counts
    counts["equal_numeric_ed_es_scale_evaluations"] = 1
    reference_ef = 100.0 * (1.0 - es_reference / ed_reference)
    check_number(stored, "ef_gt_pct", reference_ef, "count_only_reference_ef")
    counts["reference_ef_checked_from_counts"] = 1
    if not zero_prediction:
        predicted_ef = 100.0 * (1.0 - es_prediction / ed_prediction)
        check_number(stored, "ef_pred_pct", predicted_ef, "count_only_predicted_ef")
        check_number(stored, "ef_abs_error_pp", abs(predicted_ef - reference_ef),
                     "count_only_ef_absolute_error")
        counts["predicted_finite_ef_checked_from_counts"] = 1
    return counts


def model_results(model: dict, external_cases: list[evaluator.Case],
                  references: dict[str, np.ndarray], scales: dict,
                  slice_rows: dict, case_rows: dict,
                  near_zero_ml: float, near_zero_fraction: float) -> list[dict]:
    unit, arm = model["unit"], model["arm"]
    per_patient = defaultdict(lambda: {"ed": fresh_phase_counts(),
                                      "es": fresh_phase_counts()})
    vendor_by_patient = {}
    for case in external_cases:
        prediction = evaluator.binary_mask(
            model["pred_dir"] / f"{case.case_id}.png", {0, 1}, 0)
        stored = slice_rows[unit, arm, case.case_id]
        checked = verify_slice(prediction, references[case.case_id], stored)
        counts = per_patient[case.key][case.phase]
        for name, value in checked.items():
            counts[name] += value
        vendor_by_patient[case.key] = case.vendor
    require(len(per_patient) == 141, "prediction_case_coverage")
    result = []
    for key, phase_counts in per_patient.items():
        ed = phase_metrics(phase_counts["ed"], scales[key, "ed"])
        es = phase_metrics(phase_counts["es"], scales[key, "es"])
        measured = verify_case(case_rows[unit, arm, key], ed, es)
        count_only = verify_count_only_ef(
            phase_counts["ed"], phase_counts["es"],
            scales[key, "ed"], scales[key, "es"],
            case_rows[unit, arm, key], measured)
        result.append({"unit": unit, "arm": arm,
                       "vendor": vendor_by_patient[key],
                       "count_only_ef_audit": count_only,
                       "flags": classify_case(measured, near_zero_ml,
                                              near_zero_fraction)})
    return result


def verify_public_parity(root: Path, results: list[dict]) -> None:
    published = rows(root / "public" / "unit_arm_vendor_summary.csv",
                     "public_summary")
    require(len(published) == 60, "public_summary")
    seen = set()
    for row in published:
        unit, arm, vendor = row.get("unit"), row.get("arm"), row.get("vendor")
        key = (unit, arm, vendor)
        require(unit in evaluator.UNITS and arm in evaluator.ARMS
                and vendor in ("Philips", "GE", "All") and key not in seen,
                "public_summary")
        seen.add(key)
        selected = [r for r in results if r["unit"] == unit and r["arm"] == arm
                    and (vendor == "All" or r["vendor"] == vendor)]
        require(len(selected) == (141 if vendor == "All" else
                                 evaluator.EXPECTED_PATIENTS[vendor]),
                "public_summary")
        for field, flag in (
            ("ef_invalid_patients", "undefined_ef"),
            ("ef_out_of_range_patients", "finite_ef_out_of_range"),
        ):
            require(integer(row, field, "public_summary")
                    == sum(r["flags"][flag] for r in selected),
                    "public_summary")
    require(len(seen) == 60, "public_summary")
    for arm, expected in (("B", 27), ("Cneg", 115)):
        require(sum(r["flags"]["undefined_ef"] for r in results
                    if r["arm"] == arm) == expected,
                "published_invalid_totals")
    historical_flags = {
        "B": (75, 74, 1, 30, 8),
        "Cneg": (167, 164, 3, 88, 12),
    }
    for arm, expected in historical_flags.items():
        observed = tuple(
            sum(r["flags"][name] for r in results if r["arm"] == arm)
            for name in (
                "finite_ef_out_of_range", "finite_ef_below_0_pct",
                "finite_ef_above_100_pct", "finite_abs_ef_error_gt_100_pp",
                "finite_abs_ef_error_gt_500_pp",
            )
        )
        require(observed == expected, "published_tail_totals")


def summarize(results: list[dict], geometry: dict, audited_csvs: int,
              near_zero_ml: float, near_zero_fraction: float,
              evaluation_audit_sha: str, manifest_sha: str,
              stage_sha: str, source_audit_sha: str) -> dict:
    def group(selected: list[dict]) -> dict:
        return {"model_patient_evaluations": len(selected),
                "flag_counts": {name: sum(row["flags"][name]
                                      for row in selected) for name in FLAG_NAMES},
                "count_only_ef_audit": {
                    name: sum(row["count_only_ef_audit"][name] for row in selected)
                    for name in COUNT_ONLY_NAMES}}

    require(len(results) == EXPECTED_CASE_ROWS, "audit_coverage")
    by_vendor = []
    for vendor, patients in (("Philips", 88), ("GE", 53), ("All", 141)):
        selected = [row for row in results
                    if vendor == "All" or row["vendor"] == vendor]
        by_vendor.append({
            "vendor": vendor, "unique_patients_per_unit": patients,
            "arms": {arm: group([row for row in selected if row["arm"] == arm])
                     for arm in evaluator.ARMS},
        })
    return {
        "status": ("TECHNICAL_PASS_WITH_UNVERIFIED_SPATIAL_UNITS"
                   if geometry["nifti_phase_stacks_with_any_unknown_spatial_units"]
                   else "TECHNICAL_PASS_SPATIAL_UNITS_MM"),
        "schema": "mnms2_nnunet_external_full_ef_audit_v2_conditional",
        "scope": "frozen_rep00_all_20_models_141_external_patients",
        "source_consistency": {
            "audited_csv_checksums_verified": audited_csvs,
            "prediction_png_inventories_checked": 20,
            "staged_image_pngs_checked": evaluator.EXPECTED_CASES,
            "source_image_pngs_hashed": evaluator.EXPECTED_CASES,
            "source_gt_nifti_stacks_hashed": 282,
            **geometry,
            "prediction_slices_recomputed": EXPECTED_SLICE_ROWS,
            "case_rows_recomputed": EXPECTED_CASE_ROWS,
            "source_phase_verification_limit": (
                "Original ED/ES filenames, frozen manifest/stage map, current "
                "raw-image NIfTI-to-PNG export, and GT NIfTI LV label-to-PNG "
                "pixels agree; this does not independently establish the "
                "clinical truth of ED/ES frame selection."
            ),
            "raw_image_nifti_provenance_limit": (
                "Raw-image NIfTI files are compared as current content; only "
                "those present in the frozen physical input manifest have "
                "audited SHA-256 provenance."
            ),
        },
        "provenance_sha256": {
            "auditor_script_py": evaluator.sha256(Path(__file__).resolve()),
            "evaluation_audit_json": evaluation_audit_sha,
            "frozen_manifest_csv": manifest_sha,
            "external_stage_audit_json": stage_sha,
            "physical_input_audit_summary_json": source_audit_sha,
        },
        "frozen_ef_rule": "100*(EDV-ESV)/EDV; predicted EDV<=1e-6 mL is undefined",
        "spatial_units_interpretation": {
            "volume_conversion": "Frozen abs(det(affine[:3,:3]))/1000 retained exactly; no unit conversion or header correction applied.",
            "unknown_units_assumption": "When header spatial units are unknown, numerical axes are assumed to be mm solely to reproduce the frozen evaluator; physical mL units remain unverified.",
            "ef_scale_cancellation_limit": "A common physical conversion scale cancels in EF only if the true ED and ES conversion factors are equal. Equal numeric affine determinants do not establish that equality for unknown-unit headers. The EDV<=1e-6 rule and absolute-mL flags also depend on scale.",
            "frozen_metric_parity_limit": "Exact reproduction of stored metrics establishes computational consistency under the frozen convention, not independent validation of physical volume units or clinical ED/ES selection.",
            "count_only_ef_check": "When numeric ED/ES voxel factors agree within 1e-12 relative tolerance (zero absolute tolerance), compare stored reference EF, finite predicted EF and absolute error with 100*(1-N_ES/N_ED) from independently recomputed foreground counts. This checks numerical cancellation without assuming mm; it does not certify physical ED/ES conversion equality. Frozen out-of-range flags remain unchanged.",
        },
        "count_only_ef_audit": {
            name: sum(row["count_only_ef_audit"][name] for row in results)
            for name in COUNT_ONLY_NAMES},
        "diagnostic_flags_only": {
            "purpose": "Post-hoc error audit; no new endpoint or revised prediction",
            "fixed_finite_abs_error_thresholds_pp_strictly_greater_than":
                list(FIXED_TAIL_THRESHOLDS_PP),
            "configured_pred_edv_below_ml_strict": near_zero_ml,
            "configured_pred_edv_below_fraction_of_gt_strict":
                near_zero_fraction,
            "precision_boundary_definition": (
                "Finite EF>100 with predicted ESV exactly zero and excess "
                "over 100 no greater than 64 ULP at 100; original out-of-range "
                "flag remains unchanged."
            ),
            "core_union": "undefined EF OR finite EF out of [0,100] OR finite absolute EF error >100 pp",
            "all_union": "core union OR configured near-zero EDV OR predicted ESV>EDV",
        },
        "denominator_note": "The same 141 patients recur across 10 training units; 2820 are model-patient evaluations, not unique people.",
        "by_vendor": by_vendor,
    }


def audit_all(base: Path, near_zero_ml: float,
              near_zero_fraction: float,
              allow_unknown_spatial_units: bool = False) -> dict:
    root = base / "nnUNet_external_evaluation" / REP
    audited_csvs = protected("frozen_csv_checksums", diagnostic.verify_audit, root)
    diagnostic_cases = protected("frozen_case_table", diagnostic.read_cases, root)
    require(len(diagnostic_cases) == EXPECTED_CASE_ROWS, "case_table")
    case_rows = load_private_case_rows(root, diagnostic_cases)
    external_cases = protected("frozen_manifest", evaluator.load_cases,
                               base / "mnms" / "seg_lv" / "manifest_mnms2.csv")
    slice_rows = load_private_slice_rows(root, external_cases)
    physical, physical_sha = protected("source_physical_audit",
                                       evaluator.load_physical_audit,
                                       base, external_cases)
    protected("source_file_hashes", evaluator.verify_source_labels,
              base, external_cases, physical)
    stage_map, stage_sha = protected("staged_image_inventory",
                                     evaluator.load_stage_map, base,
                                     external_cases, physical, physical_sha)
    models = protected("prediction_checkpoint_inventory",
                       evaluator.verify_predictions, base, 0,
                       external_cases, stage_sha)
    require(len(models) == 20, "prediction_checkpoint_inventory")
    audit = protected("evaluation_provenance", evaluator.load_json,
                      root / "public" / "evaluation_audit.json")
    verify_frozen_identity(base, root, audit, models, stage_sha, physical_sha)
    references, scales, geometry = protected(
        "source_nifti_png_mapping", source_reference_and_geometry,
        base, external_cases, stage_map, physical, allow_unknown_spatial_units)
    results = []
    for model in models:
        results.extend(protected("prediction_or_stored_metric_mismatch",
                                 model_results, model, external_cases,
                                 references, scales, slice_rows, case_rows,
                                 near_zero_ml, near_zero_fraction))
    verify_public_parity(root, results)
    return summarize(
        results, geometry, audited_csvs, near_zero_ml, near_zero_fraction,
        protected("evaluation_provenance", evaluator.sha256,
                  root / "public" / "evaluation_audit.json"),
        evaluator.MANIFEST_SHA256, stage_sha, physical_sha,
    )


def write_aggregate(base: Path, result: dict) -> Path:
    destination = (base / "nnUNet_ef_failure_tail_audit"
                   / "rep00_conditional_units_v2_aggregate.json")
    content = json.dumps(result, indent=2, allow_nan=False) + "\n"
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists():
        require(destination.is_file() and destination.read_text(encoding="utf-8")
                == content, "aggregate_output_conflict")
        return destination
    # The output is explicitly aggregate-only and sits outside the frozen
    # evaluator, prediction, and source directories.
    old_umask = os.umask(0o077)
    try:
        with destination.open("x", encoding="utf-8") as stream:
            stream.write(content)
    finally:
        os.umask(old_umask)
    return destination


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, default=Path("/root/autodl-tmp"),
                        help="Original cloud data root (default: /root/autodl-tmp)")
    parser.add_argument("--near-zero-ml", type=float, default=DEFAULT_NEAR_ZERO_ML,
                        help="Post-hoc diagnostic EDV cutoff in mL; default 1")
    parser.add_argument("--near-zero-fraction", type=float,
                        default=DEFAULT_NEAR_ZERO_FRACTION,
                        help="Post-hoc EDV/GT EDV cutoff; default 0.05")
    parser.add_argument("--write", action="store_true",
                        help="Also save only aggregate JSON outside the frozen evaluation")
    parser.add_argument("--allow-unknown-spatial-units", action="store_true",
                        help="Allow unknown spatial-unit headers conditionally, retaining the frozen numerical volume convention; known non-mm units still fail")
    args = parser.parse_args()
    try:
        require(math.isfinite(args.near_zero_ml) and args.near_zero_ml > 0,
                "diagnostic_flag_config")
        require(math.isfinite(args.near_zero_fraction)
                and 0 < args.near_zero_fraction < 1,
                "diagnostic_flag_config")
        base = args.base.expanduser().resolve(strict=True)
        result = audit_all(base, args.near_zero_ml,
                           args.near_zero_fraction,
                           args.allow_unknown_spatial_units)
        if args.write:
            protected("aggregate_output", write_aggregate, base, result)
    except FullAuditError as exc:
        print(f"AUDIT FAIL: {exc}", file=sys.stderr)
        return 1
    except Exception:
        # Never emit an exception message or traceback: private input paths,
        # patient keys or row contents might otherwise be included.
        print("AUDIT FAIL: frozen input could not be validated", file=sys.stderr)
        return 1
    print(json.dumps(result, indent=2, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
