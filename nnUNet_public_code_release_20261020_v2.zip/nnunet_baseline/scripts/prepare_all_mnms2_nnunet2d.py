#!/usr/bin/env python3
"""Preflight and optionally prepare all ten paired M&Ms-2 2D nnU-Net units.

Run beside prepare_mnms2_nnunet2d.py and verify_mnms2_nnunet2d_pair.py.
The default is read-only. --write creates missing datasets, never overwrites an
existing one, and verifies every completed B/Cneg pair. No GPU is required.
"""

from __future__ import annotations

import argparse
import json
import shutil
from pathlib import Path

from prepare_mnms2_nnunet2d import UNITS, build_plan, write_dataset
from verify_mnms2_nnunet2d_pair import load_arm, verify_pair


def dataset_path(root: Path, unit: str, arm: str, dataset_id: int) -> Path:
    return root / f"Dataset{dataset_id:03d}_MnMS2_{unit}_{arm}"


def check_existing(directory: Path, unit: str, arm: str, records: list[dict], summary: dict) -> None:
    saved_summary, case_map = load_arm(directory, arm, unit)
    saved = json.loads((directory / "preflight_summary.json").read_text(encoding="utf-8"))
    for field in (
        "train_patients", "validation_patients", "train_gt_slices",
        "train_pseudo_slices", "validation_gt_slices", "manifest_sha256",
        "patient_partition_sha256", "label_scope_audit_sha256",
    ):
        if saved.get(field) != summary[field]:
            raise RuntimeError(f"Existing dataset audit differs from current source plan: {directory.name}, {field}")
    if saved_summary["all_png_pairs_checked"] != len(records):
        raise RuntimeError(f"Existing dataset has another number of cases: {directory.name}")
    expected = {record["case_id"]: record for record in records}
    if case_map.keys() != expected.keys():
        raise RuntimeError(f"Existing dataset cases differ from current source plan: {directory.name}")
    for case_id, row in case_map.items():
        source = expected[case_id]
        for field in ("role", "patient_key", "phase", "vendor", "label_source"):
            if row[field] != str(source[field]):
                raise RuntimeError(f"Existing case map differs from current source plan: {directory.name}, {field}")
        if int(row["z"]) != source["z"]:
            raise RuntimeError(f"Existing case map slice differs from current source plan: {directory.name}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mroot", type=Path, default=Path("/root/autodl-tmp/mnms/seg_lv"))
    parser.add_argument("--audit-dir", type=Path)
    parser.add_argument("--output-root", type=Path, default=Path("/root/autodl-tmp/nnUNet_raw"))
    parser.add_argument("--write", action="store_true", help="Create missing datasets after all preflights pass")
    args = parser.parse_args()
    mroot = args.mroot.expanduser().resolve()
    audit_dir = (args.audit_dir or mroot / "scope_control_v3_zero_gpu_audit").expanduser().resolve()
    output_root = args.output_root.expanduser().resolve()
    if output_root.is_relative_to(mroot) or mroot.is_relative_to(output_root):
        parser.error("Source export and output dataset roots must not contain each other")

    plans: list[tuple[str, int, int, dict, dict]] = []
    bytes_needed = 0
    for index, unit in enumerate(UNITS):
        b_id, c_id = 901 + 2 * index, 902 + 2 * index
        arm_plans = {}
        for arm, dataset_id in (("B", b_id), ("Cneg", c_id)):
            records, summary = build_plan(mroot, audit_dir, unit, arm)
            destination = dataset_path(output_root, unit, arm, dataset_id)
            collisions = [p for p in output_root.glob(f"Dataset{dataset_id:03d}_*") if p != destination]
            if collisions:
                raise RuntimeError(f"Dataset ID {dataset_id} is already used by another directory")
            if destination.exists():
                check_existing(destination, unit, arm, records, summary)
            else:
                bytes_needed += sum(r["image"].stat().st_size + r["label"].stat().st_size for r in records)
            arm_plans[arm] = {"records": records, "summary": summary, "destination": destination}
        b = arm_plans["B"]
        c = arm_plans["Cneg"]
        b_gt = {r["case_id"] for r in b["records"] if r["role"] == "train" and r["label_source"] == "gt"}
        c_gt = {r["case_id"] for r in c["records"] if r["role"] == "train"}
        b_val = {r["case_id"] for r in b["records"] if r["role"] == "val"}
        c_val = {r["case_id"] for r in c["records"] if r["role"] == "val"}
        if b_gt != c_gt or b_val != c_val or b["summary"]["train_pseudo_slices"] <= 0:
            raise RuntimeError(f"Paired label scope or validation split differs for {unit}")
        if b["destination"].exists() and c["destination"].exists():
            verify_pair(output_root, unit, b_id, c_id)
            state = "verified"
        elif b["destination"].exists() or c["destination"].exists():
            state = "one arm present"
        else:
            state = "not written"
        plans.append((unit, b_id, c_id, b, c))
        print(
            f"{unit}: B {b['summary']['train_gt_slices']} GT + "
            f"{b['summary']['train_pseudo_slices']} pseudo; "
            f"Cneg {c['summary']['train_gt_slices']} GT; "
            f"validation {b['summary']['validation_gt_slices']} GT; {state}",
            flush=True,
        )

    print(f"Preflight PASS: {len(plans)} paired units, {len(plans) * 2} arms.", flush=True)
    if not args.write:
        print("No files were written. Run again with --write to create missing arms.")
        return 0

    output_root.mkdir(parents=True, exist_ok=True)
    available = shutil.disk_usage(output_root).free
    safety_need = 3 * bytes_needed + 1024 ** 3
    if available < safety_need:
        raise RuntimeError(
            f"Insufficient free space: {available / 1024**3:.2f} GiB free; "
            f"require at least {safety_need / 1024**3:.2f} GiB with reserve"
        )
    print(
        f"Missing-arm source files total {bytes_needed / 1024**2:.1f} MiB; "
        f"free space {available / 1024**3:.2f} GiB.", flush=True
    )
    for unit, b_id, c_id, b, c in plans:
        for arm, plan in (("B", b), ("Cneg", c)):
            if not plan["destination"].exists():
                dataset_id = b_id if arm == "B" else c_id
                created = write_dataset(plan["records"], plan["summary"], output_root, dataset_id)
                print(f"Created {created.name}", flush=True)
        result = verify_pair(output_root, unit, b_id, c_id)
        print(
            f"Verified {unit}: {result['shared_cases_byte_identical']} shared cases byte-identical.",
            flush=True,
        )
    print("All ten B/Cneg pairs PASS. Keep case_map_PRIVATE.csv on the cloud; do not publish it.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
