#!/usr/bin/env bash
set -Eeuo pipefail

mnms2_base=/root/autodl-tmp
mnms2_python="$mnms2_base/nnunet-2.8.1-venv/bin/python"
mnms2_units=(u07 u08 u09)

trap 'mnms2_code=$?; printf "BATCH FAILED at line %s (exit %s)\n" "$LINENO" "$mnms2_code"; exit "$mnms2_code"' ERR

# Prevent two copies of this batch from preparing the same datasets at once.
exec 9>"$mnms2_base/.mnms2_u07_u09_batch.lock"
flock -n 9

printf 'BATCH START %s\n' "$(date -Is)"
df -h "$mnms2_base"

# Prepare and verify every unit before committing the GPU to a multi-day run.
for mnms2_unit in "${mnms2_units[@]}"; do
    printf '\nPREP START %s %s\n' "$mnms2_unit" "$(date -Is)"
    "$mnms2_python" -c 'import shutil, sys; free = shutil.disk_usage(sys.argv[1]).free / 2**30; print(f"Free disk: {free:.2f} GiB", flush=True); sys.exit(0 if free >= 15 else "Need at least 15 GiB before preprocessing")' "$mnms2_base"
    "$mnms2_python" "$mnms2_base/stage_mnms2_shared_nnunet2d_plan.py" --unit "$mnms2_unit" --write
    "$mnms2_python" "$mnms2_base/preprocess_mnms2_shared_nnunet2d.py" --unit "$mnms2_unit" --write
    "$mnms2_python" "$mnms2_base/train_mnms2_nnunet2d_formal.py" --unit "$mnms2_unit" --arm both --rep 0
    printf 'PREP PASS %s %s\n' "$mnms2_unit" "$(date -Is)"
    df -h "$mnms2_base"
done

# The formal launcher trains B then Cneg, with a global GPU lock and a 10 GiB
# free-space check before each arm. Any nonzero exit stops this batch.
for mnms2_unit in "${mnms2_units[@]}"; do
    printf '\nFORMAL START %s %s\n' "$mnms2_unit" "$(date -Is)"
    "$mnms2_python" -u "$mnms2_base/train_mnms2_nnunet2d_formal.py" --unit "$mnms2_unit" --arm both --rep 0 --write
    printf 'FORMAL PAIR PASS %s %s\n' "$mnms2_unit" "$(date -Is)"
    df -h "$mnms2_base"
done

printf 'BATCH PASS u07-u09 %s\n' "$(date -Is)"
