#!/usr/bin/env python3
"""Read-only cloud audit of the largest finite u03/B/GE EF error in rep00.

The private patient key and all individual measurements stay in memory. Stdout
contains only PASS/FAIL, audit categories, and aggregate counts. Run with the
same nnU-Net environment used for the frozen external evaluation.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import sys
from collections import defaultdict
from pathlib import Path

# Importing the frozen evaluator must not create files next to this script.
sys.dont_write_bytecode = True

import diagnose_mnms2_nnunet_external as diagnostic
import evaluate_mnms2_nnunet_external as evaluator


UNIT = "u03"
ARM = "B"
VENDOR = "GE"
MODEL = f"{UNIT}_{ARM}"
EXTREME_THRESHOLDS_PP = (100.0, 500.0)


class OutlierAuditError(Exception):
    """A fixed, privacy-safe failure category."""


def require(condition: bool, category: str) -> None:
    if not condition:
        raise OutlierAuditError(category)


def finite_number(row: dict[str, str], field: str) -> float:
    try:
        value = float(row[field])
    except (KeyError, TypeError, ValueError):
        raise OutlierAuditError("private metric format") from None
    require(math.isfinite(value), "private metric format")
    return value


def integer(row: dict[str, str], field: str) -> int:
    try:
        value = int(row[field])
    except (KeyError, TypeError, ValueError):
        raise OutlierAuditError("private slice metric format") from None
    return value


def same(observed: float, expected: float) -> bool:
    return math.isclose(observed, expected, rel_tol=1e-9, abs_tol=1e-7)


def choose_target(cases: dict) -> tuple[diagnostic.Case, dict[str, int]]:
    subset = [case for case in cases.values()
              if case.unit == UNIT and case.arm == ARM and case.vendor == VENDOR]
    require(len(subset) == 53, "u03/B/GE cohort")
    finite = [case for case in subset if case.ef_abs_error_pp is not None]
    require(bool(finite), "u03/B/GE finite EF cohort")
    largest = max(case.ef_abs_error_pp for case in finite)
    targets = [case for case in finite if case.ef_abs_error_pp == largest]
    require(len(targets) == 1, "largest EF error is not unique")
    counts = {
        f"ef_abs_error_gt_{int(threshold)}_pp": sum(
            case.ef_abs_error_pp > threshold for case in finite
        ) for threshold in EXTREME_THRESHOLDS_PP
    }
    return targets[0], counts


def selected_case_row(path: Path, patient_key: str) -> dict[str, str]:
    found: list[dict[str, str]] = []
    with path.open(newline="", encoding="utf-8-sig") as stream:
        for row in csv.DictReader(stream):
            if (row.get("unit"), row.get("arm"), row.get("patient_key")) == (UNIT, ARM, patient_key):
                found.append(row)
    require(len(found) == 1 and found[0].get("vendor") == VENDOR,
            "selected private case row")
    return found[0]


def selected_slice_rows(path: Path, patient_key: str) -> dict[tuple[str, int], dict[str, str]]:
    found: dict[tuple[str, int], dict[str, str]] = {}
    with path.open(newline="", encoding="utf-8-sig") as stream:
        for row in csv.DictReader(stream):
            if (row.get("unit"), row.get("arm"), row.get("patient_key")) != (UNIT, ARM, patient_key):
                continue
            require(row.get("vendor") == VENDOR, "selected private slice vendor")
            phase, z = row.get("phase"), integer(row, "z")
            require(phase in ("ed", "es") and (phase, z) not in found,
                    "selected private slice mapping")
            found[phase, z] = row
    return found


def verify_prediction_inventory(base: Path, audit: dict, stage_sha: str,
                                external_cases: list[evaluator.Case]) -> Path:
    pred_root = base / "nnUNet_external_predictions" / "rep00"
    audit_path = pred_root / "_audit" / f"{MODEL}.json"
    require(evaluator.sha256(audit_path) == audit["prediction_audit_sha256"][MODEL],
            "prediction audit checksum")
    prediction_audit = evaluator.load_json(audit_path)
    dataset_id, dataset = evaluator.model_identity(UNIT, ARM)
    expected = {
        "schema": "mnms2_nnunet_external_predict_v1", "status": "PASS",
        "unit": UNIT, "arm": ARM, "rep": "rep00",
        "dataset_id": dataset_id, "dataset": dataset,
        "checkpoint_final_sha256": audit["checkpoint_sha256"][MODEL],
        "stage_audit_sha256": stage_sha,
        "manifest_sha256": evaluator.MANIFEST_SHA256,
        "cases_expected": evaluator.EXPECTED_CASES,
    }
    require(all(prediction_audit.get(key) == value for key, value in expected.items()),
            "prediction audit identity")
    pred_dir = pred_root / MODEL
    inventory = evaluator.inventory(pred_dir, {f"{case.case_id}.png" for case in external_cases})
    require(inventory == prediction_audit.get("predictions_inventory_sha256")
            == audit["prediction_inventories"][MODEL], "prediction PNG inventory")
    return pred_dir


def measure_masks(base: Path, target_cases: list[evaluator.Case],
                  stage_map: dict[str, dict[str, str]], physical: dict[str, str],
                  pred_dir: Path, slice_rows: dict[tuple[str, int], dict[str, str]],
                  scales: dict[str, float]) -> dict[str, dict[str, float]]:
    """Recount every selected ED/ES mask and check the frozen slice metrics."""
    expected_pairs = {(case.phase, case.z) for case in target_cases}
    require(expected_pairs == set(slice_rows), "selected slice coverage")
    zs = {phase: {case.z for case in target_cases if case.phase == phase}
          for phase in ("ed", "es")}
    require(bool(zs["ed"]) and zs["ed"] == zs["es"]
            and zs["ed"] == set(range(len(zs["ed"]))), "ED/ES phase and layer mapping")
    sums: dict[str, dict[str, float]] = defaultdict(lambda: defaultdict(float))
    image_root = base / "mnms" / "seg_lv" / "all"
    for case in target_cases:
        mapped = stage_map.get(case.case_id)
        require(mapped is not None and mapped.get("patient_key") == case.key
                and mapped.get("phase") == case.phase
                and mapped.get("z") == str(case.z)
                and mapped.get("gt_rel") == case.gt_rel, "frozen stage/manifest mapping")
        gt_path = evaluator.inside(image_root, case.gt_rel)
        expected_sha = physical.get(str(gt_path))
        require(bool(expected_sha) and mapped.get("source_gt_sha256") == expected_sha,
                "source GT provenance")
        evaluator.checked_file(gt_path, expected_sha, "Source GT PNG")
        gt = evaluator.binary_mask(gt_path, {0, 255}, 127)
        pred = evaluator.binary_mask(pred_dir / f"{case.case_id}.png", {0, 1}, 0)
        require(gt.shape == pred.shape, "prediction/GT PNG dimensions")
        gt_px = int(gt.sum())
        pred_px = int(pred.sum())
        intersection = int((gt & pred).sum())
        require(gt_px == case.gt_px_manifest, "manifest GT pixel count")
        recorded = slice_rows[case.phase, case.z]
        require(recorded.get("case_id") == case.case_id
                and integer(recorded, "gt_px") == gt_px
                and integer(recorded, "pred_px") == pred_px
                and integer(recorded, "intersection_px") == intersection,
                "frozen slice metrics versus PNGs")
        sums[case.phase]["gt_px"] += gt_px
        sums[case.phase]["pred_px"] += pred_px
        sums[case.phase]["slices"] += 1
    for phase in ("ed", "es"):
        require(math.isfinite(scales[phase]) and scales[phase] > 0,
                "original NIfTI affine voxel scale")
        sums[phase]["gt_ml"] = sums[phase]["gt_px"] * scales[phase]
        sums[phase]["pred_ml"] = sums[phase]["pred_px"] * scales[phase]
    return sums


def compare_case_metrics(stored: dict[str, str], measured: dict[str, dict[str, float]]) -> list[str]:
    for phase, volume_prefix in (("ed", "edv"), ("es", "esv")):
        values = measured[phase]
        for recorded_field, actual in (
            (f"{volume_prefix}_gt_ml", values["gt_ml"]),
            (f"{volume_prefix}_pred_ml", values["pred_ml"]),
            (f"{phase}_gt_volume_ml", values["gt_ml"]),
            (f"{phase}_pred_volume_ml", values["pred_ml"]),
            (f"{phase}_slices", values["slices"]),
        ):
            require(same(finite_number(stored, recorded_field), actual),
                    "frozen case volumes versus PNG and affine")
    ed, es = measured["ed"], measured["es"]
    require(ed["gt_ml"] > diagnostic.EF_MIN_EDV_ML
            and ed["pred_ml"] > diagnostic.EF_MIN_EDV_ML,
            "selected finite EF denominator")
    ef_gt = 100.0 * (ed["gt_ml"] - es["gt_ml"]) / ed["gt_ml"]
    ef_pred = 100.0 * (ed["pred_ml"] - es["pred_ml"]) / ed["pred_ml"]
    require(all(math.isfinite(value) for value in (ef_gt, ef_pred)), "recomputed EF finite")
    require(same(finite_number(stored, "ef_gt_pct"), ef_gt)
            and same(finite_number(stored, "ef_pred_pct"), ef_pred)
            and same(finite_number(stored, "ef_abs_error_pp"), abs(ef_pred - ef_gt))
            and stored.get("ef_invalid") == "0"
            and stored.get("ef_out_of_range") == str(int(not 0.0 <= ef_pred <= 100.0)),
            "frozen case EF versus PNG and affine")
    categories: list[str] = []
    if ed["pred_ml"] < 0.05 * ed["gt_ml"]:
        categories.append("predicted_EDV_below_5_percent_of_GT")
    if ed["pred_ml"] < 1.0:
        categories.append("predicted_EDV_below_1_mL")
    if es["pred_ml"] > ed["pred_ml"]:
        categories.append("predicted_ESV_exceeds_EDV")
    if not categories:
        categories.append("none_of_the_predefined_volume_categories")
    return categories


def audit_outlier(base: Path) -> dict:
    root = base / "nnUNet_external_evaluation" / "rep00"
    verified = diagnostic.verify_audit(root)
    cases = diagnostic.read_cases(root)
    target, counts = choose_target(cases)
    audit = evaluator.load_json(root / "public" / "evaluation_audit.json")
    require(audit.get("manifest_sha256") == evaluator.MANIFEST_SHA256,
            "evaluation/manifest identity")
    external_cases = evaluator.load_cases(base / "mnms" / "seg_lv" / "manifest_mnms2.csv")
    physical, physical_sha = evaluator.load_physical_audit(base, external_cases)
    require(physical_sha == audit.get("physical_input_audit_sha256"),
            "evaluation/source audit identity")
    stage_map, stage_sha = evaluator.load_stage_map(base, external_cases, physical, physical_sha)
    require(stage_sha == audit.get("stage_audit_sha256"),
            "evaluation/stage audit identity")
    pred_dir = verify_prediction_inventory(base, audit, stage_sha, external_cases)
    target_cases = [case for case in external_cases if case.key == target.patient_key]
    require(bool(target_cases) and all(case.vendor == VENDOR for case in target_cases),
            "selected patient in external manifest")
    stored = selected_case_row(root / "private" / "case_metrics_PRIVATE.csv", target.patient_key)
    slices = selected_slice_rows(root / "private" / "slice_metrics_PRIVATE.csv", target.patient_key)
    scales = {phase: evaluator.nifti_scale(base, target.patient_key, phase, physical,
              sum(case.phase == phase for case in target_cases)) for phase in ("ed", "es")}
    measured = measure_masks(base, target_cases, stage_map, physical, pred_dir, slices, scales)
    categories = compare_case_metrics(stored, measured)
    return {
        "status": "PASS", "scope": "rep00 u03/B GE largest finite EF absolute error",
        "audited_csv_checksums_verified": verified,
        "prediction_PNG_inventory": "PASS",
        "manifest_stage_ED_ES_mapping": "PASS",
        "source_GT_PNG_and_NIfTI_affine": "PASS",
        "stored_slice_and_case_metrics_recomputed": "PASS",
        "extreme_B_u03_GE_case_counts": counts,
        "target_volume_categories": categories,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, default=Path("/root/autodl-tmp"),
                        help="Cloud data root containing frozen rep00 inputs and outputs")
    args = parser.parse_args()
    try:
        result = audit_outlier(args.base.expanduser())
    except OutlierAuditError as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        return 1
    except Exception:
        # Never echo exceptions: paths, filenames, or parser errors may contain
        # private identifiers in data controlled by the input files.
        print("FAIL: frozen source, prediction, or audit input could not be validated", file=sys.stderr)
        return 1
    print(json.dumps(result, indent=2, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
