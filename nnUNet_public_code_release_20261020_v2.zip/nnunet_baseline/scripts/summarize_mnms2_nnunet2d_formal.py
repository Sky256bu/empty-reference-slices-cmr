#!/usr/bin/env python3
"""Read-only paired Dice summary for audited M&Ms-2 nnU-Net formal runs.

Prints aggregate scores only; patient/case identifiers stay on the cloud.
These SIEMENS validation Dice scores are diagnostic, not the Philips/GE EF endpoint.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path


PLAN = "nnUNetPlansSharedU00GT"
TRAINER = "nnUNetTrainer"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def checked_dice(base: Path, result_root: Path, unit: str, arm: str) -> float:
    index = int(unit[1:])
    dataset_id = 901 + 2 * index + (arm == "Cneg")
    dataset = f"Dataset{dataset_id:03d}_MnMS2_{unit}_{arm}"
    audit_path = result_root / "_audit" / f"{unit}_{arm}.json"
    audit = json.loads(audit_path.read_text(encoding="utf-8"))
    expected_fields = {
        "status": "PASS",
        "unit": unit,
        "arm": arm,
        "rep": result_root.name,
        "dataset_id": dataset_id,
        "dataset": dataset,
        "trainer": TRAINER,
        "plan_name": PLAN,
        "configuration": "2d",
        "fold": "0",
        "planned_epochs": 1000,
        "validation_cases": 964,
        "final_model_rule": "checkpoint_final.pth_only",
    }
    wrong = [key for key, expected in expected_fields.items() if audit.get(key) != expected]
    if wrong:
        raise RuntimeError(f"Unexpected audit fields for {dataset}: {', '.join(wrong)}")
    if not any(attempt.get("status") == "PASS" for attempt in audit.get("attempts", [])):
        raise RuntimeError(f"No successful formal attempt recorded for {dataset}")

    folder = result_root / dataset / f"{TRAINER}__{PLAN}__2d" / "fold_0"
    recorded = audit.get("validated_artifacts", {})
    checkpoint = folder / "checkpoint_final.pth"
    summary_path = folder / "validation" / "summary.json"
    if sha256(checkpoint) != recorded.get("checkpoint_final_sha256"):
        raise RuntimeError(f"Final checkpoint differs from PASS audit: {dataset}")
    if sha256(summary_path) != recorded.get("validation_summary_sha256"):
        raise RuntimeError(f"Validation summary differs from PASS audit: {dataset}")

    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    cases = summary.get("metric_per_case")
    if not isinstance(cases, list) or len(cases) != 964:
        raise RuntimeError(f"Expected 964 validation summary entries: {dataset}")
    split_path = base / "nnUNet_preprocessed" / dataset / "splits_final.json"
    fixed_validation = set(json.loads(split_path.read_text(encoding="utf-8"))[0]["val"])
    summarized = {Path(case["prediction_file"]).stem for case in cases}
    if len(fixed_validation) != 964 or summarized != fixed_validation:
        raise RuntimeError(f"Validation cases differ from the fixed split: {dataset}")

    dice = float(summary["foreground_mean"]["Dice"])
    if not math.isfinite(dice) or not 0.0 <= dice <= 1.0:
        raise RuntimeError(f"Invalid validation Dice: {dataset}")
    return dice


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, default=Path("/root/autodl-tmp"))
    parser.add_argument("--rep", type=int, choices=range(3), default=0)
    parser.add_argument("--through", choices=[f"u{i:02d}" for i in range(10)], default="u06")
    args = parser.parse_args()
    base = args.base.expanduser().resolve()
    result_root = base / "nnUNet_results_formal" / f"rep{args.rep:02d}"

    print("unit       B       Cneg      B-Cneg")
    for index in range(int(args.through[1:]) + 1):
        unit = f"u{index:02d}"
        b = checked_dice(base, result_root, unit, "B")
        cneg = checked_dice(base, result_root, unit, "Cneg")
        print(f"{unit}   {b:.6f}   {cneg:.6f}   {b - cneg:+.6f}")
    print("Fixed SIEMENS validation Dice only; not the Philips/GE full-stack EF endpoint.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
