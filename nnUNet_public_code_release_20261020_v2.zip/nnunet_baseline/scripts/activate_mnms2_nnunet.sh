# Source this file at the start of each AutoDL shell session.
source /root/autodl-tmp/nnunet-2.8.1-venv/bin/activate
export nnUNet_raw=/root/autodl-tmp/nnUNet_raw
export nnUNet_preprocessed=/root/autodl-tmp/nnUNet_preprocessed
export nnUNet_results=/root/autodl-tmp/nnUNet_results
