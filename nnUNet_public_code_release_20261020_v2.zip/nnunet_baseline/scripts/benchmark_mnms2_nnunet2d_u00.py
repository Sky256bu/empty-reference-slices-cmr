#!/usr/bin/env python3
"""Run the official five-epoch nnU-Net resource benchmark on the u00 pair.

Default is read-only. This uses nnUNetTrainerBenchmark_5epochs in a separate
results root, with no checkpoints or paper results. Existing complete probes
are verified and skipped; incomplete outputs are never overwritten.
"""

from __future__ import annotations

import argparse
import importlib.metadata
import json
import math
import os
import shutil
import subprocess
import sys
import threading
import time
from datetime import datetime, timezone
from pathlib import Path

from preprocess_mnms2_shared_nnunet2d import (
    FINGERPRINT_SHA256,
    PLAN_NAME,
    PLAN_SHA256,
    REFERENCE,
    inspect_target,
    read_json,
    sha256,
)


TRAINER = "nnUNetTrainerBenchmark_5epochs"
CONFIGURATION = "2d"
FOLD = "0"
DA_WORKERS = "4"


def result_folder(root: Path, name: str) -> Path:
    return root / name / f"{TRAINER}__{PLAN_NAME}__{CONFIGURATION}" / f"fold_{FOLD}"


def verify_benchmark(folder: Path) -> float:
    result_file = folder / "benchmark_result.json"
    if not result_file.is_file():
        raise RuntimeError(f"Benchmark summary missing: {folder}")
    results = read_json(result_file)
    if not isinstance(results, dict) or not results:
        raise RuntimeError(f"Empty benchmark summary: {folder}")
    times = [
        value.get("fastest_epoch") for value in results.values()
        if isinstance(value, dict)
    ]
    valid_times = [
        float(value) for value in times
        if isinstance(value, (int, float)) and math.isfinite(value) and value > 0
    ]
    if not valid_times:
        raise RuntimeError(f"Benchmark reported an error instead of a numeric epoch time: {folder}")
    log_files = list(folder.glob("training_log_*.txt"))
    if not log_files:
        raise RuntimeError(f"Training log missing: {folder}")
    log = max(log_files, key=lambda path: path.stat().st_mtime).read_text(encoding="utf-8", errors="replace")
    if log.count("Epoch time:") != 5 or "An Exception occurred:" in log:
        raise RuntimeError(f"Benchmark did not finish five clean epochs: {folder}")
    if any(folder.glob("checkpoint*.pth")):
        raise RuntimeError(f"Resource probe unexpectedly wrote a model checkpoint: {folder}")
    return min(valid_times)


def read_device_memory_mib() -> int:
    result = subprocess.run(
        ["nvidia-smi", "--query-gpu=memory.used", "--format=csv,noheader,nounits", "-i", "0"],
        check=True, capture_output=True, text=True, timeout=10,
    )
    return int(result.stdout.strip().splitlines()[0])


def sample_device_memory(stop: threading.Event, observations: list[int]) -> None:
    """Record approximate whole-device memory use without modifying nnU-Net."""
    while not stop.is_set():
        try:
            observations.append(read_device_memory_mib())
        except (OSError, ValueError, IndexError, subprocess.SubprocessError):
            pass
        stop.wait(2.0)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, default=Path("/root/autodl-tmp"))
    parser.add_argument("--arm", choices=("B", "Cneg", "both"), default="B")
    parser.add_argument("--write", action="store_true", help="Run missing five-epoch benchmarks")
    args = parser.parse_args()
    base = args.base.expanduser().resolve()
    venv = base / "nnunet-2.8.1-venv"
    cli = venv / "bin" / "nnUNetv2_train"
    if Path(sys.prefix).resolve() != venv.resolve():
        raise RuntimeError("Activate /root/autodl-tmp/activate_mnms2_nnunet.sh first")
    if importlib.metadata.version("nnunetv2") != "2.8.1" or not cli.is_file():
        raise RuntimeError("Pinned nnunetv2 2.8.1 training environment is missing")
    source_pp = base / "nnUNet_preprocessed" / REFERENCE
    if (
        sha256(source_pp / "nnUNetPlans.json") != PLAN_SHA256
        or sha256(source_pp / "dataset_fingerprint.json") != FINGERPRINT_SHA256
    ):
        raise RuntimeError("Frozen shared plan or train-only fingerprint changed")
    source_plan = read_json(source_pp / "nnUNetPlans.json")

    import torch

    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is unavailable; resource benchmark requires the GPU instance")
    try:
        initial_device_memory_mib = read_device_memory_mib()
    except (OSError, ValueError, IndexError, subprocess.SubprocessError) as exc:
        raise RuntimeError("nvidia-smi memory sampling is unavailable on this instance") from exc
    result_root = base / "nnUNet_results_probe"
    arms = ("B", "Cneg") if args.arm == "both" else (args.arm,)
    targets = []
    for arm in arms:
        target = inspect_target(base, "u00", arm, source_plan)
        if not target["state"].startswith("complete"):
            raise RuntimeError(f"Preprocessing incomplete: {target['name']}")
        audit_file = target["staged"] / "preprocessing_audit.json"
        if not audit_file.is_file() or read_json(audit_file).get("status") != "PASS":
            raise RuntimeError(f"Preprocessing audit missing or not PASS: {target['name']}")
        folder = result_folder(result_root, target["name"])
        if folder.exists():
            fastest = verify_benchmark(folder)
            audit_file = folder / "resource_probe_audit.json"
            if not audit_file.is_file():
                raise RuntimeError(f"Benchmark exists but resource audit is missing: {folder}")
            audit = read_json(audit_file)
            if (
                audit.get("status") != "PASS"
                or audit.get("shared_plan_sha256") != PLAN_SHA256
                or audit.get("device_memory_samples", 0) < 3
                or not math.isclose(audit.get("fastest_epoch_seconds", -1), fastest)
            ):
                raise RuntimeError(f"Existing resource audit is incomplete: {folder}")
            state = f"complete; fastest epoch {fastest:.2f} s; will not rerun"
        else:
            state = "not benchmarked"
        print(f"{target['name']}: {state}", flush=True)
        targets.append((target, folder))
    if not args.write:
        print(f"Preflight PASS: {len(targets)} arm(s). No benchmark started.")
        return 0

    env = os.environ.copy()
    env.update({
        "nnUNet_raw": str(base / "nnUNet_raw"),
        "nnUNet_preprocessed": str(base / "nnUNet_preprocessed"),
        "nnUNet_results": str(result_root),
        "nnUNet_n_proc_DA": DA_WORKERS,
        "nnUNet_compile": "true",
        "OMP_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
        "OPENBLAS_NUM_THREADS": "1",
        "TORCHINDUCTOR_COMPILE_THREADS": "1",
    })
    for target, folder in targets:
        if folder.exists():
            print(f"Skipped existing complete resource probe: {target['name']}", flush=True)
            continue
        command = [
            str(cli), str(target["id"]), CONFIGURATION, FOLD,
            "-tr", TRAINER, "-p", PLAN_NAME, "-device", "cuda",
        ]
        result_root.mkdir(parents=True, exist_ok=True)
        print(
            f"Starting five-epoch RESOURCE PROBE for {target['name']}; "
            "no paper model or checkpoint will be produced.", flush=True
        )
        start = time.monotonic()
        memory_samples: list[int] = [initial_device_memory_mib]
        stop_sampling = threading.Event()
        memory_thread = threading.Thread(
            target=sample_device_memory, args=(stop_sampling, memory_samples), daemon=True
        )
        memory_thread.start()
        try:
            subprocess.run(command, check=True, env=env)
            fastest = verify_benchmark(folder)
            if len(memory_samples) < 3:
                raise RuntimeError("Benchmark finished but device memory was not sampled during training")
        except BaseException as exc:
            failure = {
                "status": "FAILED",
                "dataset": target["name"],
                "error_type": type(exc).__name__,
                "error": str(exc),
                "failed_utc": datetime.now(timezone.utc).isoformat(),
            }
            (result_root / f"resource_probe_u00_{target['name']}_failure.json").write_text(
                json.dumps(failure, indent=2) + "\n", encoding="utf-8"
            )
            raise
        finally:
            stop_sampling.set()
            memory_thread.join(timeout=12)
        audit = {
            "status": "PASS",
            "purpose": "resource_probe_only_not_paper_result",
            "dataset": target["name"],
            "unit": "u00",
            "arm": "B" if target["id"] == 901 else "Cneg",
            "trainer": TRAINER,
            "configuration": CONFIGURATION,
            "fold": FOLD,
            "planned_epochs": 5,
            "train_iterations_per_epoch": 250,
            "validation_iterations_per_epoch": 50,
            "augmentation_workers": int(DA_WORKERS),
            "torch_compile": True,
            "fastest_epoch_seconds": fastest,
            "wall_seconds": round(time.monotonic() - start, 2),
            "gpu": torch.cuda.get_device_name(0),
            "baseline_whole_device_memory_mib_observed": memory_samples[0],
            "peak_whole_device_memory_mib_observed": max(memory_samples) if memory_samples else None,
            "device_memory_samples": len(memory_samples),
            "free_disk_gib": round(shutil.disk_usage(base).free / 1024**3, 2),
            "shared_plan_sha256": PLAN_SHA256,
            "fixed_split_sha256": sha256(target["staged"] / "splits_final.json"),
            "script_sha256": sha256(Path(__file__)),
            "nnunetv2_version": importlib.metadata.version("nnunetv2"),
            "completed_utc": datetime.now(timezone.utc).isoformat(),
        }
        (folder / "resource_probe_audit.json").write_text(
            json.dumps(audit, indent=2) + "\n", encoding="utf-8"
        )
        print(
            f"PROBE PASS {target['name']}: fastest epoch {fastest:.2f} s, "
            f"wall time {audit['wall_seconds']:.2f} s, "
            f"observed device peak {audit['peak_whole_device_memory_mib_observed']} MiB; "
            "no paper checkpoint", flush=True
        )
    print(f"PASS: {len(targets)} resource probe arm(s) complete; formal training not started.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
