#!/usr/bin/env python3
"""Read-only, anonymous secondary analysis of the audited rep00 evaluation.

This is a post-hoc exploratory R1 analysis defined after inspecting the EF
results. Run on AutoDL, where the private case table stays. Only anonymous
aggregates are printed to stdout; this script creates or changes no files.
There is deliberately no EF-MAE effect estimate or confidence interval here.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path

import numpy as np


UNITS = tuple(f"u{i:02d}" for i in range(10))
ARMS = ("B", "Cneg")
VENDORS = {"Philips": 88, "GE": 53}
MODEL_NAMES = {f"{unit}_{arm}" for unit in UNITS for arm in ARMS}
EXPECTED_OUTPUTS = {
    "private/slice_metrics_PRIVATE.csv",
    "private/case_metrics_PRIVATE.csv",
    "private/paired_case_metrics_PRIVATE.csv",
    "public/unit_arm_vendor_summary.csv",
    "public/paired_unit_vendor_summary.csv",
    "public/paired_overall_summary.csv",
}
BOOTSTRAP_SEED = 20260928
BOOTSTRAP_DRAWS = 2000
METRICS = (
    "ed_dice_full_stack", "es_dice_full_stack",
    "edv_abs_error_ml", "esv_abs_error_ml",
    "ed_empty_gt_fp_slices", "es_empty_gt_fp_slices", "ef_invalid",
)
PUBLIC_METRICS = (
    "ed_dice_full_stack", "es_dice_full_stack",
    "edv_abs_error_ml", "esv_abs_error_ml",
    "ed_empty_gt_fp_slices_per_evaluation",
    "es_empty_gt_fp_slices_per_evaluation", "ef_invalid_rate_pct",
)
BETTER_IF_POSITIVE = (True, True, False, False, False, False, False)
REQUIRED_COLUMNS = {
    "unit", "arm", "vendor", "patient_key", "edv_gt_ml", "esv_gt_ml",
    "edv_pred_ml", "esv_pred_ml", "edv_abs_error_ml", "esv_abs_error_ml",
    "ed_dice_full_stack", "es_dice_full_stack", "ed_slices", "es_slices",
    "ed_present_slices", "es_present_slices", "ed_empty_gt_slices",
    "es_empty_gt_slices", "ed_empty_gt_fp_slices", "es_empty_gt_fp_slices",
    "ef_invalid",
}


class AnalysisError(Exception):
    """Safe diagnostic message that never includes private row contents."""


@dataclass(frozen=True)
class Case:
    unit: str
    arm: str
    vendor: str
    patient_key: str
    metrics: tuple[float, ...]
    empty_gt: tuple[int, int]
    reference: tuple[float, float, int, int]


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AnalysisError(message)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    try:
        with path.open("rb") as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(chunk)
    except OSError:
        raise AnalysisError("An audited CSV is missing or unreadable") from None
    return digest.hexdigest()


def verify_audit(root: Path) -> dict:
    try:
        with (root / "public" / "evaluation_audit.json").open(encoding="utf-8") as stream:
            audit = json.load(stream)
    except (OSError, ValueError):
        raise AnalysisError("The rep00 evaluation audit is missing or unreadable") from None
    require(isinstance(audit, dict), "The evaluation audit has the wrong structure")
    identity = {
        "schema": "mnms2_nnunet_external_evaluation_v1", "status": "PASS",
        "rep": "rep00", "models": 20, "cases_per_model": 3072,
        "patients_per_model": 141,
    }
    require(all(audit.get(key) == value for key, value in identity.items()),
            "The evaluation audit differs from the expected rep00 run")
    for field in ("checkpoint_sha256", "prediction_inventories", "prediction_audit_sha256"):
        value = audit.get(field)
        require(isinstance(value, dict) and set(value) == MODEL_NAMES,
                "The evaluation audit lacks the expected 20 models")
    bootstrap = audit.get("bootstrap")
    require(isinstance(bootstrap, dict)
            and bootstrap.get("seed") == BOOTSTRAP_SEED
            and bootstrap.get("draws") == BOOTSTRAP_DRAWS,
            "The evaluation audit has a different bootstrap specification")
    hashes = audit.get("output_sha256")
    require(isinstance(hashes, dict) and set(hashes) == EXPECTED_OUTPUTS,
            "The evaluation audit has an incomplete CSV inventory")
    for relative in sorted(EXPECTED_OUTPUTS):
        expected = hashes[relative]
        require(isinstance(expected, str) and len(expected) == 64
                and all(char in "0123456789abcdef" for char in expected),
                "The evaluation audit has an invalid CSV checksum")
        require(sha256(root / relative) == expected,
                "An evaluation CSV differs from its audited SHA256")
    return audit


def finite_float(row: dict[str, str], field: str) -> float:
    try:
        value = float(row[field])
    except (KeyError, ValueError, TypeError):
        raise AnalysisError("The private case table has a missing or invalid numeric field") from None
    require(math.isfinite(value), "The private case table has a nonfinite numeric field")
    return value


def nonnegative_int(row: dict[str, str], field: str) -> int:
    try:
        value = int(row[field])
    except (KeyError, ValueError, TypeError):
        raise AnalysisError("The private case table has a missing or invalid count") from None
    require(value >= 0, "The private case table has a negative count")
    return value


def checked_case(row: dict[str, str]) -> Case:
    unit, arm, vendor, key = (row.get(field, "") for field in
                              ("unit", "arm", "vendor", "patient_key"))
    require(unit in UNITS and arm in ARMS and vendor in VENDORS and bool(key),
            "The private case table has an unexpected model, vendor, or empty patient key")
    edv_gt, esv_gt = (finite_float(row, field) for field in ("edv_gt_ml", "esv_gt_ml"))
    edv_pred, esv_pred = (finite_float(row, field) for field in
                          ("edv_pred_ml", "esv_pred_ml"))
    edv_ae, esv_ae = (finite_float(row, field) for field in
                       ("edv_abs_error_ml", "esv_abs_error_ml"))
    ed_dice, es_dice = (finite_float(row, field) for field in
                         ("ed_dice_full_stack", "es_dice_full_stack"))
    require(all(value >= 0 for value in (edv_gt, esv_gt, edv_pred, esv_pred,
                                          edv_ae, esv_ae)) and edv_gt > 1e-6,
            "The private case table has an invalid volume or error")
    require(math.isclose(edv_ae, abs(edv_pred - edv_gt), rel_tol=1e-9, abs_tol=1e-7)
            and math.isclose(esv_ae, abs(esv_pred - esv_gt), rel_tol=1e-9, abs_tol=1e-7),
            "A volume absolute error disagrees with the recorded volumes")
    require(0 <= ed_dice <= 1 and 0 <= es_dice <= 1,
            "A full-stack Dice lies outside [0, 1]")
    empty = []
    for phase in ("ed", "es"):
        slices = nonnegative_int(row, f"{phase}_slices")
        present = nonnegative_int(row, f"{phase}_present_slices")
        empty_gt = nonnegative_int(row, f"{phase}_empty_gt_slices")
        false_positives = nonnegative_int(row, f"{phase}_empty_gt_fp_slices")
        require(slices > 0 and present + empty_gt == slices
                and false_positives <= empty_gt,
                "An empty-GT slice count is inconsistent")
        empty.append((empty_gt, false_positives))
    invalid_raw = row.get("ef_invalid")
    require(invalid_raw in ("0", "1"), "The private case table has an invalid EF flag")
    invalid = int(invalid_raw)
    require(invalid == int(edv_pred <= 1e-6),
            "An EF invalid flag contradicts the predicted EDV rule")
    return Case(unit, arm, vendor, key,
                (ed_dice, es_dice, edv_ae, esv_ae,
                 float(empty[0][1]), float(empty[1][1]), float(invalid)),
                (empty[0][0], empty[1][0]),
                (edv_gt, esv_gt, nonnegative_int(row, "ed_slices"),
                 nonnegative_int(row, "es_slices")))


def read_cases(root: Path) -> tuple[dict[tuple[str, str, str], Case], dict[str, str]]:
    cases: dict[tuple[str, str, str], Case] = {}
    patient_sets: dict[tuple[str, str], dict[str, str]] = defaultdict(dict)
    reference: dict[str, tuple[float, float, int, int, int, int]] = {}
    try:
        with (root / "private" / "case_metrics_PRIVATE.csv").open(
                newline="", encoding="utf-8-sig") as stream:
            reader = csv.DictReader(stream)
            require(reader.fieldnames is not None and REQUIRED_COLUMNS <= set(reader.fieldnames),
                    "The private case table lacks required columns")
            for row in reader:
                case = checked_case(row)
                index = (case.unit, case.arm, case.patient_key)
                require(index not in cases, "The private case table has a duplicate model-patient row")
                cases[index] = case
                patient_sets[case.unit, case.arm][case.patient_key] = case.vendor
                expected = (*case.reference, *case.empty_gt)
                old = reference.setdefault(case.patient_key, expected)
                require(old[2:] == expected[2:]
                        and math.isclose(old[0], expected[0], rel_tol=1e-9, abs_tol=1e-7)
                        and math.isclose(old[1], expected[1], rel_tol=1e-9, abs_tol=1e-7),
                        "A patient's GT measurements differ across models")
    except (OSError, UnicodeError, csv.Error):
        raise AnalysisError("The private case table is missing or unreadable") from None
    require(len(cases) == 20 * 141 and set(patient_sets) == {(u, a) for u in UNITS for a in ARMS},
            "The private case table does not contain exactly 20 x 141 rows")
    cohort = patient_sets[UNITS[0], ARMS[0]]
    require(Counter(cohort.values()) == Counter(VENDORS),
            "The private case table differs from the 88 Philips / 53 GE cohort")
    require(all(group == cohort for group in patient_sets.values()),
            "The patient-vendor cohort differs across models")
    return cases, cohort


def matrices(cases: dict[tuple[str, str, str], Case],
             cohort: dict[str, str]) -> dict[str, tuple[np.ndarray, np.ndarray, np.ndarray]]:
    result = {}
    for vendor in VENDORS:
        keys = sorted(key for key, name in cohort.items() if name == vendor)
        values = [np.empty((len(METRICS), len(UNITS), len(keys)), dtype=float)
                  for _ in ARMS]
        denominators = np.empty((2, len(UNITS), len(keys)), dtype=int)
        for ui, unit in enumerate(UNITS):
            for pi, key in enumerate(keys):
                b, c = cases[unit, "B", key], cases[unit, "Cneg", key]
                require(b.empty_gt == c.empty_gt,
                        "Paired arms disagree about the GT-empty slice denominator")
                values[0][:, ui, pi] = b.metrics
                values[1][:, ui, pi] = c.metrics
                denominators[:, ui, pi] = b.empty_gt
        result[vendor] = (values[0], values[1], denominators)
    return result


def ci95(draws: list[float]) -> list[float]:
    return [float(value) for value in np.quantile(draws, (0.025, 0.975))]


def resample(matrix: dict[str, tuple[np.ndarray, np.ndarray, np.ndarray]]) -> dict:
    """Same unit and vendor-stratified patient draws for every paired metric."""
    rng = np.random.default_rng(BOOTSTRAP_SEED)
    draws = {vendor: [[] for _ in METRICS] for vendor in (*VENDORS, "All")}
    rate_draws = {vendor: [[], []] for vendor in (*VENDORS, "All")}
    for _ in range(BOOTSTRAP_DRAWS):
        sampled_units = rng.integers(len(UNITS), size=len(UNITS))
        means = {}
        fp_sums = {}
        empty_sums = {}
        for vendor, (b, c, denominator) in matrix.items():
            n = b.shape[2]
            sampled_patients = rng.integers(n, size=n)
            selector = np.ix_(sampled_units, sampled_patients)
            paired = (b - c)[:, selector[0], selector[1]]
            means[vendor] = paired.mean(axis=(1, 2))
            fp_sums[vendor] = (
                b[4:6, selector[0], selector[1]].sum(axis=(1, 2)),
                c[4:6, selector[0], selector[1]].sum(axis=(1, 2)),
            )
            empty_sums[vendor] = denominator[:, selector[0], selector[1]].sum(axis=(1, 2))
            for mi, value in enumerate(means[vendor]):
                draws[vendor][mi].append(float(value * (100 if mi == 6 else 1)))
            for phase in range(2):
                exposure = empty_sums[vendor][phase]
                if exposure:
                    rate_draws[vendor][phase].append(
                        float(100 * (fp_sums[vendor][0][phase] - fp_sums[vendor][1][phase]) / exposure))
        total_n = sum(VENDORS.values())
        all_means = sum(means[vendor] * VENDORS[vendor] for vendor in VENDORS) / total_n
        for mi, value in enumerate(all_means):
            draws["All"][mi].append(float(value * (100 if mi == 6 else 1)))
        for phase in range(2):
            exposure = sum(empty_sums[vendor][phase] for vendor in VENDORS)
            if exposure:
                difference = sum(fp_sums[vendor][0][phase] - fp_sums[vendor][1][phase]
                                 for vendor in VENDORS)
                rate_draws["All"][phase].append(float(100 * difference / exposure))
    return {vendor: {
        "metric_ci95": [ci95(values) for values in draws[vendor]],
        "fp_rate_ci95": [ci95(values) if len(values) == BOOTSTRAP_DRAWS else None
                         for values in rate_draws[vendor]],
    } for vendor in draws}


def direction_counts(unit_deltas: np.ndarray, positive_is_better: bool) -> dict[str, int]:
    adjusted = unit_deltas if positive_is_better else -unit_deltas
    return {
        "b": int(np.count_nonzero(adjusted > 0)),
        "cneg": int(np.count_nonzero(adjusted < 0)),
        "tie": int(np.count_nonzero(adjusted == 0)),
    }


def analyze(root: Path, *, include_units: bool = True) -> dict:
    audit = verify_audit(root)
    cases, cohort = read_cases(root)
    matrix = matrices(cases, cohort)
    intervals = resample(matrix)
    by_vendor = []
    for vendor in (*VENDORS, "All"):
        vendors = list(VENDORS) if vendor == "All" else [vendor]
        n_patients = sum(VENDORS[name] for name in vendors)
        b = np.concatenate([matrix[name][0] for name in vendors], axis=2)
        c = np.concatenate([matrix[name][1] for name in vendors], axis=2)
        denominator = np.concatenate([matrix[name][2] for name in vendors], axis=2)
        delta = b - c
        unit_deltas = delta.mean(axis=2)
        metrics = {}
        for mi, public_name in enumerate(PUBLIC_METRICS):
            scale = 100 if mi == 6 else 1
            metrics[public_name] = {
                "b_mean": float(b[mi].mean() * scale),
                "cneg_mean": float(c[mi].mean() * scale),
                "b_minus_cneg_mean": float(delta[mi].mean() * scale),
                "ci95": intervals[vendor]["metric_ci95"][mi],
                "unit_direction": direction_counts(unit_deltas[mi], BETTER_IF_POSITIVE[mi]),
            }
        fp = {}
        for phase, name in enumerate(("ed", "es")):
            exposure = int(denominator[phase].sum())
            b_count, c_count = (int(value[4 + phase].sum()) for value in (b, c))
            fp[name] = {
                "empty_gt_slices": exposure,
                "b_fp_slices": b_count, "cneg_fp_slices": c_count,
                "b_minus_cneg_fp_slices": b_count - c_count,
                "b_rate_pct": 100 * b_count / exposure if exposure else None,
                "cneg_rate_pct": 100 * c_count / exposure if exposure else None,
                "b_minus_cneg_rate_pp": 100 * (b_count - c_count) / exposure if exposure else None,
                "rate_diff_ci95_pp": intervals[vendor]["fp_rate_ci95"][phase],
            }
        unit_rows = []
        for ui, unit in enumerate(UNITS):
            row = {
                "unit": unit,
                "b_minus_cneg_mean": {
                    public_name: float(unit_deltas[mi, ui] * (100 if mi == 6 else 1))
                    for mi, public_name in enumerate(PUBLIC_METRICS)
                },
                "empty_gt_fp": {
                    name: {
                        "empty_gt_slices": int(denominator[phase, ui].sum()),
                        "b_fp_slices": int(b[4 + phase, ui].sum()),
                        "cneg_fp_slices": int(c[4 + phase, ui].sum()),
                    } for phase, name in enumerate(("ed", "es"))
                },
            }
            unit_rows.append(row)
        vendor_result = {
            "vendor": vendor, "unique_patients": n_patients,
            "paired_unit_patient_evaluations": n_patients * len(UNITS),
            "metrics": metrics, "empty_gt_fp": fp,
        }
        if include_units:
            vendor_result["by_unit"] = unit_rows
        by_vendor.append(vendor_result)
    return {
        "status": "PASS", "rep": "rep00",
        "analysis": "post_hoc_exploratory_R1_after_inspecting_EF",
        "audited_csv_sha256_verified": len(EXPECTED_OUTPUTS),
        "audit_evaluator_sha256": audit["evaluator_script_sha256"],
        "models": 20, "private_case_rows_read": len(cases),
        "bootstrap": {
            "draws": BOOTSTRAP_DRAWS, "seed": BOOTSTRAP_SEED,
            "method": "paired training-unit resampling plus vendor-stratified patient resampling; patient draws shared across units and arms",
            "ci": "percentile 95%; exploratory; no multiplicity adjustment",
        },
        "interpretation": (
            "B minus Cneg: positive Dice difference favors B; negative volume-error, "
            "empty-GT false-positive or EF-invalid difference favors B. "
            "Each vendor reuses the same patients across 10 training units. "
            "No EF-MAE inference is made here."
        ),
        "by_vendor": by_vendor,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--evaluation-dir", type=Path,
                        default=Path("/root/autodl-tmp/nnUNet_external_evaluation/rep00"),
                        help="Existing audited rep00 evaluation directory (read only)")
    parser.add_argument("--summary", action="store_true",
                        help="Print vendor aggregates and unit-direction counts without 30 unit rows")
    args = parser.parse_args()
    try:
        result = analyze(args.evaluation_dir.expanduser(), include_units=not args.summary)
    except AnalysisError as exc:
        print(f"Secondary analysis FAIL: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(result, indent=2, allow_nan=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
