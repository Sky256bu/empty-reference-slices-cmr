#!/usr/bin/env bash
# Install the pinned nnU-Net environment on the verified AutoDL GPU clone.
# This script does not plan, preprocess, or train any model.
set -euo pipefail

base=/root/autodl-tmp
raw_root="$base/nnUNet_raw"
venv="$base/nnunet-2.8.1-venv"

for unit_number in {0..9}; do
    printf -v unit 'u%02d' "$unit_number"
    b_id=$((901 + 2 * unit_number))
    c_id=$((902 + 2 * unit_number))
    printf -v b_name 'Dataset%03d_MnMS2_%s_B' "$b_id" "$unit"
    printf -v c_name 'Dataset%03d_MnMS2_%s_Cneg' "$c_id" "$unit"
    for name in "$b_name" "$c_name"; do
        if [[ ! -f "$raw_root/$name/dataset.json" || ! -f "$raw_root/$name/splits_final.json" ]]; then
            printf 'Missing dataset or fixed split: %s\n' "$name" >&2
            exit 1
        fi
    done
done

if [[ ! -x "$venv/bin/python" ]]; then
    python3 -m venv --system-site-packages "$venv"
fi
"$venv/bin/python" -m pip install --no-cache-dir 'nnunetv2==2.8.1'

export nnUNet_raw="$raw_root"
export nnUNet_preprocessed="$base/nnUNet_preprocessed"
export nnUNet_results="$base/nnUNet_results"
mkdir -p "$nnUNet_preprocessed" "$nnUNet_results"

"$venv/bin/python" - <<'PY'
import importlib.metadata
import os
import torch

print('nnunetv2:', importlib.metadata.version('nnunetv2'))
print('torch:', importlib.metadata.version('torch'))
print('CUDA available:', torch.cuda.is_available())
if not torch.cuda.is_available():
    raise SystemExit('Installed environment cannot use the GPU')
print('GPU:', torch.cuda.get_device_name(0))
print('VRAM GiB:', round(torch.cuda.get_device_properties(0).total_memory / 1024**3, 2))
for name in ('nnUNet_raw', 'nnUNet_preprocessed', 'nnUNet_results'):
    print(f'{name}: {os.environ[name]}')
PY

"$venv/bin/nnUNetv2_plan_and_preprocess" -h >/dev/null
"$venv/bin/python" -m pip freeze > "$base/nnunet-2.8.1-package-freeze.txt"

cat > "$base/activate_mnms2_nnunet.sh" <<'SH'
# Source this file at the start of each AutoDL shell session.
source /root/autodl-tmp/nnunet-2.8.1-venv/bin/activate
export nnUNet_raw=/root/autodl-tmp/nnUNet_raw
export nnUNet_preprocessed=/root/autodl-tmp/nnUNet_preprocessed
export nnUNet_results=/root/autodl-tmp/nnUNet_results
SH

printf 'SETUP PASS. No planning, preprocessing, or training was started.\n'
