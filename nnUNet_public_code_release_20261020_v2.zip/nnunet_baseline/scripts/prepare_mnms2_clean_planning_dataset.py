#!/usr/bin/env python3
"""Create a train-only GT reference for one shared nnU-Net 2D plan.

Source: Dataset902_MnMS2_u00_Cneg, whose fixed split includes 101 training
GT slices and 964 SIEMENS validation GT slices. This script copies only the
101 training cases into Dataset900_MnMS2_CommonPlan_u00_GT. The latter is for
fingerprinting/planning only, never for model training or performance claims.

Default mode is read-only. --write creates the dataset without overwriting.
No patient identifiers or case IDs are printed.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import shutil
from pathlib import Path


SOURCE_NAME = "Dataset902_MnMS2_u00_Cneg"
TARGET_NAME = "Dataset900_MnMS2_CommonPlan_u00_GT"
MANIFEST_SHA256 = "fd9f2eba74f0adba7eff7a11c80e856d49e9aebcdcda17920f4e491d2e7f7a24"


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def case_set_digest(cases: set[str]) -> str:
    return hashlib.sha256("\n".join(sorted(cases)).encode("ascii")).hexdigest()


def inspect_source(source: Path) -> tuple[set[str], dict]:
    meta = json.loads((source / "dataset.json").read_text(encoding="utf-8"))
    summary = json.loads((source / "preflight_summary.json").read_text(encoding="utf-8"))
    splits = json.loads((source / "splits_final.json").read_text(encoding="utf-8"))
    if (
        meta.get("labels") != {"background": 0, "LV": 1}
        or meta.get("channel_names") != {"0": "MRI"}
        or meta.get("file_ending") != ".png"
    ):
        raise RuntimeError("Source does not have the expected binary LV PNG labels")
    if summary.get("unit") != "u00" or summary.get("arm") != "Cneg":
        raise RuntimeError("Source is not the frozen u00 Cneg dataset")
    if summary.get("train_gt_slices") != 101 or summary.get("train_pseudo_slices") != 0:
        raise RuntimeError("Source training supervision differs from the frozen audit")
    if summary.get("manifest_sha256") != MANIFEST_SHA256:
        raise RuntimeError("Source manifest differs from the frozen experiment")
    if summary.get("validation_gt_slices") != 964 or len(splits) != 1:
        raise RuntimeError("Source validation split differs from the frozen audit")
    train = set(splits[0]["train"])
    val = set(splits[0]["val"])
    if len(train) != 101 or len(val) != 964 or train & val or len(train | val) != meta["numTraining"]:
        raise RuntimeError("Source train/validation cases do not close")
    with (source / "case_map_PRIVATE.csv").open("r", encoding="utf-8", newline="") as stream:
        rows = list(csv.DictReader(stream))
    by_id = {row["case_id"]: row for row in rows}
    if len(by_id) != len(rows) or set(by_id) != train | val:
        raise RuntimeError("Source private case map differs from fixed split")
    if {by_id[cid]["role"] for cid in train} != {"train"} or any(
        by_id[cid]["label_source"] != "gt" for cid in train
    ):
        raise RuntimeError("The planning source contains non-GT training labels")
    train_patients = {by_id[cid]["patient_key"] for cid in train}
    val_patients = {by_id[cid]["patient_key"] for cid in val}
    if len(train_patients) != 10 or len(val_patients) != 43 or train_patients & val_patients:
        raise RuntimeError("The planning source has an incorrect patient partition")
    if {by_id[cid]["role"] for cid in val} != {"val"}:
        raise RuntimeError("The excluded validation cases have another split role")
    for cid in train:
        if not (source / "imagesTr" / f"{cid}_0000.png").is_file():
            raise FileNotFoundError("A selected training image is missing")
        if not (source / "labelsTr" / f"{cid}.png").is_file():
            raise FileNotFoundError("A selected training GT label is missing")
    audit = {
        "purpose": "fingerprinting_and_planning_only",
        "source_dataset": SOURCE_NAME,
        "source_split_sha256": digest(source / "splits_final.json"),
        "source_manifest_sha256": summary["manifest_sha256"],
        "training_cases": len(train),
        "training_patients": 10,
        "validation_cases_excluded": len(val),
        "case_set_sha256": case_set_digest(train),
    }
    return train, audit


def verify_target(source: Path, target: Path, train: set[str], audit: dict) -> None:
    meta = json.loads((target / "dataset.json").read_text(encoding="utf-8"))
    saved_audit = json.loads((target / "planning_scope.json").read_text(encoding="utf-8"))
    if meta.get("numTraining") != len(train) or meta.get("labels") != {"background": 0, "LV": 1}:
        raise RuntimeError("Planning dataset metadata differs from expected GT-only source")
    if saved_audit != audit:
        raise RuntimeError("Planning scope audit differs from current source split")
    images = {p.name for p in (target / "imagesTr").glob("*.png")}
    labels = {p.name for p in (target / "labelsTr").glob("*.png")}
    if images != {f"{cid}_0000.png" for cid in train} or labels != {f"{cid}.png" for cid in train}:
        raise RuntimeError("Planning dataset files differ from training-only case set")
    for cid in train:
        if digest(source / "imagesTr" / f"{cid}_0000.png") != digest(target / "imagesTr" / f"{cid}_0000.png"):
            raise RuntimeError("A planning image differs from the source training image")
        if digest(source / "labelsTr" / f"{cid}.png") != digest(target / "labelsTr" / f"{cid}.png"):
            raise RuntimeError("A planning GT differs from the source training GT")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--raw-root", type=Path, default=Path("/root/autodl-tmp/nnUNet_raw"))
    parser.add_argument("--write", action="store_true", help="Create the training-only planning dataset")
    args = parser.parse_args()
    root = args.raw_root.expanduser().resolve()
    source = root / SOURCE_NAME
    target = root / TARGET_NAME
    train, audit = inspect_source(source)
    if target.exists():
        verify_target(source, target, train, audit)
        print("PASS: existing train-only planning dataset verified; 101 GT cases; 964 validation cases excluded.")
        return 0
    if not args.write:
        print("Preflight PASS: 101 GT training cases; 964 validation cases excluded. No files were written.")
        return 0
    if list(root.glob("Dataset900_*")):
        raise RuntimeError("Dataset ID 900 is already assigned to another dataset")
    (target / "imagesTr").mkdir(parents=True)
    (target / "labelsTr").mkdir()
    for cid in sorted(train):
        shutil.copy2(source / "imagesTr" / f"{cid}_0000.png", target / "imagesTr" / f"{cid}_0000.png")
        shutil.copy2(source / "labelsTr" / f"{cid}.png", target / "labelsTr" / f"{cid}.png")
    meta = json.loads((source / "dataset.json").read_text(encoding="utf-8"))
    meta["numTraining"] = len(train)
    (target / "dataset.json").write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")
    (target / "planning_scope.json").write_text(json.dumps(audit, indent=2) + "\n", encoding="utf-8")
    verify_target(source, target, train, audit)
    print("PASS: created train-only planning dataset; 101 GT cases; 964 validation cases excluded.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
