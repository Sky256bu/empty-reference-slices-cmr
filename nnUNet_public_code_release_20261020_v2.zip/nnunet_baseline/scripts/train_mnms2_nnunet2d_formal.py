#!/usr/bin/env python3
"""Run one paired, full-length M&Ms-2 nnU-Net 2D experiment safely.

Read-only by default. --write trains missing arms for 1,000 epochs with the
official nnUNetTrainer. --resume continues an interrupted run only if an
official checkpoint exists. --validate-only reruns incomplete final-checkpoint
validation. B and Cneg run sequentially, with isolated results per repeat.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import os
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

from preprocess_mnms2_shared_nnunet2d import (
    FINGERPRINT_SHA256,
    PLAN_NAME,
    PLAN_SHA256,
    REFERENCE,
    inspect_target,
    read_json,
    sha256,
)


TRAINER = "nnUNetTrainer"
CONFIGURATION = "2d"
FOLD = "0"
EPOCHS = 1000
DA_WORKERS = "4"
EXPORT_WORKERS = "4"
MIN_FREE_GIB = 10


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def write_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def result_folder(root: Path, name: str) -> Path:
    return root / name / f"{TRAINER}__{PLAN_NAME}__{CONFIGURATION}" / f"fold_{FOLD}"


def checkpoint_epoch(path: Path) -> int:
    if not path.is_file() or path.stat().st_size == 0:
        raise RuntimeError(f"Missing or zero-byte checkpoint: {path}")
    import torch

    # These checkpoints originate from this launcher and the pinned nnU-Net CLI.
    checkpoint = torch.load(path, map_location="cpu", weights_only=False)
    if checkpoint.get("trainer_name") != TRAINER or not isinstance(checkpoint.get("current_epoch"), int):
        raise RuntimeError(f"Checkpoint has unexpected trainer or epoch: {path}")
    return checkpoint["current_epoch"]


def validation_status(folder: Path, expected: set[str]) -> tuple[bool, str]:
    validation = folder / "validation"
    if not validation.is_dir():
        return False, "validation folder absent"
    predicted = {path.stem for path in validation.glob("*.png")}
    extra = predicted - expected
    if extra:
        raise RuntimeError(f"Unexpected validation predictions in {folder}: {len(extra)} extra")
    missing = expected - predicted
    if missing:
        return False, f"{len(missing)} of {len(expected)} validation predictions missing"
    if any((validation / f"{case}.png").stat().st_size == 0 for case in expected):
        return False, "zero-byte validation prediction"
    summary_path = validation / "summary.json"
    if not summary_path.is_file() or summary_path.stat().st_size == 0:
        return False, "validation summary absent"
    summary = read_json(summary_path)
    cases = summary.get("metric_per_case") if isinstance(summary, dict) else None
    if not isinstance(cases, list) or len(cases) != len(expected):
        return False, "validation summary has incomplete case count"
    summarized = {Path(case.get("prediction_file", "")).stem for case in cases if isinstance(case, dict)}
    if summarized != expected:
        return False, "validation summary case IDs differ from fixed split"
    return True, f"{len(expected)} complete validation predictions and summary entries"


def artifact_hashes(folder: Path, expected: set[str]) -> dict:
    inventory = hashlib.sha256()
    for case in sorted(expected):
        name = f"{case}.png"
        inventory.update(name.encode("utf-8"))
        inventory.update(bytes.fromhex(sha256(folder / "validation" / name)))
    return {
        "checkpoint_final_sha256": sha256(folder / "checkpoint_final.pth"),
        "validation_summary_sha256": sha256(folder / "validation" / "summary.json"),
        "validation_predictions_inventory_sha256": inventory.hexdigest(),
    }


def audited_state(state: str, detail: str, folder: Path, expected: set[str],
                  manifest: dict | None) -> tuple[str, str]:
    if manifest is not None and manifest.get("status") == "PASS":
        recorded = manifest.get("validated_artifacts")
        if state not in ("complete", "needs_validation"):
            raise RuntimeError(f"Previously completed run lost its final checkpoint: {folder}")
        if isinstance(recorded, dict) and recorded.get("checkpoint_final_sha256") != sha256(folder / "checkpoint_final.pth"):
            raise RuntimeError(f"Audited final checkpoint changed: {folder}")
    if state != "complete":
        return state, detail
    if manifest is None or manifest.get("status") != "PASS":
        return "needs_validation", "complete files lack a PASS audit; rerun final-checkpoint validation"
    recorded = manifest.get("validated_artifacts")
    if not isinstance(recorded, dict):
        return "needs_validation", "complete files lack recorded final-validation hashes"
    observed = artifact_hashes(folder, expected)
    if recorded.get("checkpoint_final_sha256") != observed["checkpoint_final_sha256"]:
        raise RuntimeError(f"Audited final checkpoint changed: {folder}")
    if recorded != observed:
        return "needs_validation", "validation files changed since final-checkpoint audit"
    return state, detail


def classify_run(folder: Path, expected: set[str]) -> tuple[str, str]:
    if not folder.exists():
        return "missing", "no run folder"
    if not folder.is_dir():
        raise RuntimeError(f"Run path is not a directory: {folder}")
    final = folder / "checkpoint_final.pth"
    if final.exists():
        epoch = checkpoint_epoch(final)
        if epoch != EPOCHS:
            raise RuntimeError(f"Final checkpoint has epoch {epoch}, expected {EPOCHS}: {folder}")
        complete, detail = validation_status(folder, expected)
        return ("complete" if complete else "needs_validation"), detail
    for filename in ("checkpoint_latest.pth", "checkpoint_best.pth"):
        checkpoint = folder / filename
        if checkpoint.exists():
            epoch = checkpoint_epoch(checkpoint)
            if not 0 < epoch <= EPOCHS:
                raise RuntimeError(f"Interrupted checkpoint has invalid epoch {epoch}: {checkpoint}")
            return "resumable", f"{filename} at epoch {epoch}"
    return "no_checkpoint", "run folder exists, but no checkpoint is available"


def verify_input(base: Path, unit: str, arm: str, source_plan: dict) -> dict:
    target = inspect_target(base, unit, arm, source_plan)
    if not target["state"].startswith("complete"):
        raise RuntimeError(f"Preprocessing is incomplete: {target['name']}")
    audit_path = target["staged"] / "preprocessing_audit.json"
    if not audit_path.is_file():
        raise RuntimeError(f"Preprocessing audit missing: {target['name']}")
    audit = read_json(audit_path)
    if (
        audit.get("status") != "PASS"
        or audit.get("dataset") != target["name"]
        or audit.get("shared_plan_sha256") != PLAN_SHA256
        or audit.get("shared_fingerprint_sha256") != FINGERPRINT_SHA256
        or audit.get("target_plan_sha256") != sha256(target["staged"] / f"{PLAN_NAME}.json")
        or audit.get("fixed_split_sha256") != sha256(target["staged"] / "splits_final.json")
        or audit.get("training_cases") != target["train"]
        or audit.get("validation_cases") != 964
        or audit.get("cases_verified") != len(target["expected"])
        or audit.get("nnunetv2_version") != "2.8.1"
    ):
        raise RuntimeError(f"Preprocessing audit differs from frozen inputs: {target['name']}")
    target["validation_ids"] = set(read_json(target["staged"] / "splits_final.json")[0]["val"])
    target["split_sha256"] = sha256(target["staged"] / "splits_final.json")
    target["target_plan_sha256"] = audit["target_plan_sha256"]
    return target


def make_manifest(target: dict, unit: str, arm: str, rep: int, script_path: Path) -> dict:
    return {
        "schema": "mnms2_nnunet2d_formal_v1",
        "status": "NEW",
        "purpose": "exploratory_strong_baseline",
        "unit": unit,
        "arm": arm,
        "rep": f"rep{rep:02d}",
        "dataset": target["name"],
        "dataset_id": target["id"],
        "training_cases": target["train"],
        "validation_cases": target["val"],
        "plan_name": PLAN_NAME,
        "shared_plan_sha256": PLAN_SHA256,
        "shared_fingerprint_sha256": FINGERPRINT_SHA256,
        "target_plan_sha256": target["target_plan_sha256"],
        "fixed_split_sha256": target["split_sha256"],
        "trainer": TRAINER,
        "configuration": CONFIGURATION,
        "fold": FOLD,
        "planned_epochs": EPOCHS,
        "final_model_rule": "checkpoint_final.pth_only",
        "nnunetv2_version": "2.8.1",
        "augmentation_workers": int(DA_WORKERS),
        "validation_export_workers": int(EXPORT_WORKERS),
        "torch_compile": True,
        "randomness_policy": "official_default_independent_stochastic_runs; no paired-seed claim",
        "initial_script_sha256": sha256(script_path),
        "created_utc": utc_now(),
        "attempts": [],
    }


def check_manifest(manifest: dict, expected: dict) -> None:
    immutable = (
        "schema", "unit", "arm", "rep", "dataset", "dataset_id", "training_cases",
        "validation_cases", "plan_name", "shared_plan_sha256", "shared_fingerprint_sha256",
        "target_plan_sha256", "fixed_split_sha256", "trainer", "configuration", "fold",
        "planned_epochs", "final_model_rule", "nnunetv2_version", "augmentation_workers",
        "validation_export_workers", "torch_compile", "randomness_policy",
    )
    wrong = [key for key in immutable if manifest.get(key) != expected[key]]
    if wrong:
        raise RuntimeError(f"Existing run manifest differs in frozen fields: {', '.join(wrong)}")


def run_one(base: Path, result_root: Path, target: dict, unit: str, arm: str,
            rep: int, action: str, cli: Path, script_path: Path) -> None:
    folder = result_folder(result_root, target["name"])
    manifest_path = result_root / "_audit" / f"{unit}_{arm}.json"
    expected_manifest = make_manifest(target, unit, arm, rep, script_path)
    state, detail = classify_run(folder, target["validation_ids"])
    if manifest_path.exists():
        manifest = read_json(manifest_path)
        check_manifest(manifest, expected_manifest)
        if state == "missing" and (manifest.get("status") == "PASS" or manifest.get("validated_artifacts")):
            raise RuntimeError(f"Previously completed model folder is missing: {folder}")
    elif state == "missing" and action == "write":
        manifest = expected_manifest
        write_json(manifest_path, manifest)
    else:
        raise RuntimeError(f"Existing run has no matching audit manifest: {folder}")
    state, detail = audited_state(state, detail, folder, target["validation_ids"], manifest)
    if state == "complete":
        print(f"SKIP {target['name']}: already complete ({detail})", flush=True)
        return
    if action == "write" and state != "missing":
        raise RuntimeError(f"Refusing fresh training over {state} run: {folder}; use --resume or --validate-only")
    if action == "resume" and state != "resumable":
        raise RuntimeError(f"Resume requires an interrupted checkpoint, found {state}: {folder}")
    if action == "validate_only" and state != "needs_validation":
        raise RuntimeError(f"Validation-only requires a 1,000-epoch final checkpoint, found {state}: {folder}")

    free_gib = shutil.disk_usage(base).free / 1024**3
    if free_gib < MIN_FREE_GIB:
        raise RuntimeError(f"Only {free_gib:.2f} GiB disk free; require {MIN_FREE_GIB} GiB before a formal run")
    command = [str(cli), str(target["id"]), CONFIGURATION, FOLD,
               "-tr", TRAINER, "-p", PLAN_NAME, "-device", "cuda"]
    if action == "resume":
        command.append("--c")
    elif action == "validate_only":
        command.append("--val")
    env = os.environ.copy()
    env.update({
        "nnUNet_raw": str(base / "nnUNet_raw"),
        "nnUNet_preprocessed": str(base / "nnUNet_preprocessed"),
        "nnUNet_results": str(result_root),
        "nnUNet_n_proc_DA": DA_WORKERS,
        "nnUNet_def_n_proc": EXPORT_WORKERS,
        "nnUNet_compile": "true",
        "OMP_NUM_THREADS": "1",
        "MKL_NUM_THREADS": "1",
        "OPENBLAS_NUM_THREADS": "1",
        "TORCHINDUCTOR_COMPILE_THREADS": "1",
    })
    attempt = {
        "action": action,
        "started_utc": utc_now(),
        "source_checkpoint": detail if action == "resume" else None,
        "command": command,
        "free_gib_before": round(free_gib, 2),
    }
    manifest["attempts"].append(attempt)
    manifest["status"] = "RUNNING"
    write_json(manifest_path, manifest)
    print(f"START {target['name']} {manifest['rep']} {action}: 1,000 epochs, fold 0, final checkpoint", flush=True)
    started = time.monotonic()
    try:
        subprocess.run(command, check=True, env=env)
        final_epoch = checkpoint_epoch(folder / "checkpoint_final.pth")
        if final_epoch != EPOCHS:
            raise RuntimeError(f"Final checkpoint epoch {final_epoch}, expected {EPOCHS}: {folder}")
        complete, detail = validation_status(folder, target["validation_ids"])
        if not complete:
            raise RuntimeError(f"Training finished but final validation is incomplete: {detail}")
        artifacts = artifact_hashes(folder, target["validation_ids"])
        attempt.update(artifacts)
        attempt["validation_predictions_verified"] = len(target["validation_ids"])
        attempt["status"] = "PASS"
        manifest["status"] = "PASS"
        manifest["validated_artifacts"] = artifacts
        print(f"FORMAL PASS {target['name']} {manifest['rep']}: epoch {EPOCHS}; {detail}", flush=True)
    except BaseException as exc:
        attempt["status"] = "FAILED"
        attempt["error_type"] = type(exc).__name__
        attempt["error"] = str(exc)
        manifest["status"] = "FAILED"
        raise
    finally:
        attempt["finished_utc"] = utc_now()
        attempt["wall_seconds"] = round(time.monotonic() - started, 2)
        attempt["free_gib_after"] = round(shutil.disk_usage(base).free / 1024**3, 2)
        write_json(manifest_path, manifest)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, default=Path("/root/autodl-tmp"))
    parser.add_argument("--unit", choices=[f"u{i:02d}" for i in range(10)], default="u00")
    parser.add_argument("--arm", choices=("both", "B", "Cneg"), default="both")
    parser.add_argument("--rep", type=int, choices=range(3), default=0)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--write", action="store_true", help="Start only missing fresh runs")
    mode.add_argument("--resume", action="store_true", help="Resume only checkpointed interrupted runs")
    mode.add_argument("--validate-only", action="store_true", help="Validate an existing final checkpoint")
    args = parser.parse_args()
    base = args.base.expanduser().resolve()
    venv = base / "nnunet-2.8.1-venv"
    cli = venv / "bin" / "nnUNetv2_train"
    if Path(sys.prefix).resolve() != venv.resolve() or not cli.is_file():
        raise RuntimeError("Activate the pinned /root/autodl-tmp/nnunet-2.8.1-venv first")
    if importlib.metadata.version("nnunetv2") != "2.8.1":
        raise RuntimeError("Formal runs require nnunetv2==2.8.1")
    source = base / "nnUNet_preprocessed" / REFERENCE
    if (sha256(source / "nnUNetPlans.json") != PLAN_SHA256
            or sha256(source / "dataset_fingerprint.json") != FINGERPRINT_SHA256):
        raise RuntimeError("Train-only reference plan or fingerprint differs from frozen SHA256")
    source_plan = read_json(source / "nnUNetPlans.json")
    import torch

    if not torch.cuda.is_available():
        raise RuntimeError("Formal training requires the GPU instance")
    arms = ("B", "Cneg") if args.arm == "both" else (args.arm,)
    result_root = base / "nnUNet_results_formal" / f"rep{args.rep:02d}"
    targets = [verify_input(base, args.unit, arm, source_plan) for arm in arms]
    script_path = Path(__file__).resolve()
    action = "write" if args.write else "resume" if args.resume else "validate_only" if args.validate_only else None
    for arm, target in zip(arms, targets):
        folder = result_folder(result_root, target["name"])
        state, detail = classify_run(folder, target["validation_ids"])
        audit_path = result_root / "_audit" / f"{args.unit}_{arm}.json"
        if audit_path.exists():
            manifest = read_json(audit_path)
            check_manifest(manifest, make_manifest(target, args.unit, arm, args.rep, script_path))
            if state == "missing" and (manifest.get("status") == "PASS" or manifest.get("validated_artifacts")):
                raise RuntimeError(f"Previously completed model folder is missing: {folder}")
        elif state != "missing":
            raise RuntimeError(f"Run exists without matching audit manifest: {folder}")
        else:
            manifest = None
        state, detail = audited_state(state, detail, folder, target["validation_ids"], manifest)
        print(f"{target['name']} rep{args.rep:02d}: {state}; {detail}; "
              f"{target['train']} train, {target['val']} fixed validation", flush=True)
        if action == "write" and state not in ("missing", "complete"):
            raise RuntimeError(f"Fresh run cannot overwrite {state}: {folder}")
        if action == "resume" and state not in ("resumable", "complete"):
            raise RuntimeError(f"No resumable checkpoint for {target['name']}: {state}")
        if action == "validate_only" and state not in ("needs_validation", "complete"):
            raise RuntimeError(f"No final checkpoint awaiting validation for {target['name']}: {state}")
    if action is None:
        print(f"Preflight PASS: {len(targets)} arm(s); no training or validation started.")
        return 0

    result_root.parent.mkdir(parents=True, exist_ok=True)
    lock_path = result_root.parent / ".formal_training.lock"
    import fcntl

    with lock_path.open("a+") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as exc:
            raise RuntimeError("Another formal nnU-Net run already holds the GPU lock") from exc
        for arm, target in zip(arms, targets):
            run_one(base, result_root, target, args.unit, arm, args.rep, action, cli, script_path)
    print(f"PASS: {len(targets)} formal arm(s) complete or previously verified for {args.unit} rep{args.rep:02d}.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
