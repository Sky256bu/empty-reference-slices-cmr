#!/usr/bin/env python3
"""Stage one or all paired datasets with a shared, train-only nnU-Net plan.

Requires a finished Dataset900_MnMS2_CommonPlan_u00_GT fingerprint and plan.
Default is read-only. --write copies target dataset metadata/splits, records
that the fingerprint came from Dataset900, and invokes nnU-Net's official
move_plans_between_datasets command. Existing targets are only verified;
nothing is overwritten. This script does not preprocess or train.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import shutil
import subprocess
from copy import deepcopy
from pathlib import Path


REFERENCE = "Dataset900_MnMS2_CommonPlan_u00_GT"
PLAN_NAME = "nnUNetPlansSharedU00GT"


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def normalized_2d(plan: dict) -> dict:
    config = deepcopy(plan["configurations"]["2d"])
    config.pop("data_identifier", None)
    return config


def target_name(index: int, arm: str) -> tuple[int, str]:
    dataset_id = 901 + 2 * index + (0 if arm == "B" else 1)
    return dataset_id, f"Dataset{dataset_id:03d}_MnMS2_u{index:02d}_{arm}"


def verify_staged(raw: Path, destination: Path, fingerprint: Path, source_plan: dict, provenance: dict) -> None:
    if sha256(destination / "dataset.json") != sha256(raw / "dataset.json"):
        raise RuntimeError(f"Staged dataset.json differs: {destination.name}")
    if sha256(destination / "splits_final.json") != sha256(raw / "splits_final.json"):
        raise RuntimeError(f"Staged fixed split differs: {destination.name}")
    if sha256(destination / "dataset_fingerprint.json") != sha256(fingerprint):
        raise RuntimeError(f"Staged shared fingerprint differs: {destination.name}")
    if json.loads((destination / "planning_provenance.json").read_text(encoding="utf-8")) != provenance:
        raise RuntimeError(f"Planning provenance differs: {destination.name}")
    plan_path = destination / f"{PLAN_NAME}.json"
    target_plan = json.loads(plan_path.read_text(encoding="utf-8"))
    if target_plan.get("dataset_name") != destination.name:
        raise RuntimeError(f"Moved plan has another dataset identity: {destination.name}")
    if normalized_2d(target_plan) != normalized_2d(source_plan):
        raise RuntimeError(f"Moved 2D plan differs from the shared reference: {destination.name}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, default=Path("/root/autodl-tmp"))
    parser.add_argument("--unit", choices=tuple(f"u{i:02d}" for i in range(10)), default="u00")
    parser.add_argument("--all", action="store_true", help="Stage all ten paired units")
    parser.add_argument("--write", action="store_true", help="Create missing staged plans")
    args = parser.parse_args()
    base = args.base.expanduser().resolve()
    raw_root = base / "nnUNet_raw"
    pp_root = base / "nnUNet_preprocessed"
    reference_raw = raw_root / REFERENCE
    reference_pp = pp_root / REFERENCE
    scope = json.loads((reference_raw / "planning_scope.json").read_text(encoding="utf-8"))
    if scope.get("training_cases") != 101 or scope.get("validation_cases_excluded") != 964:
        raise RuntimeError("Reference planning scope is not the train-only GT set")
    fingerprint = reference_pp / "dataset_fingerprint.json"
    source_plans_path = reference_pp / "nnUNetPlans.json"
    source_plan = json.loads(source_plans_path.read_text(encoding="utf-8"))
    if source_plan.get("dataset_name") != REFERENCE or "2d" not in source_plan.get("configurations", {}):
        raise RuntimeError("Reference plan is not the expected 2D planning dataset")
    reference_config = source_plan["configurations"]["2d"]
    architecture = reference_config.get("architecture", reference_config.get("network_arch_class_name"))
    if isinstance(architecture, dict):
        architecture = architecture.get("network_class_name", architecture.get("class_name"))
    print(json.dumps({
        "shared_plan_sha256": sha256(source_plans_path),
        "train_only_fingerprint_sha256": sha256(fingerprint),
        "2d_patch_size": reference_config.get("patch_size"),
        "2d_batch_size": reference_config.get("batch_size"),
        "2d_spacing": reference_config.get("spacing"),
        "2d_normalization": reference_config.get("normalization_schemes"),
        "2d_use_mask_for_norm": reference_config.get("use_mask_for_norm"),
        "2d_architecture": architecture,
    }, indent=2), flush=True)
    if args.write:
        venv_python = base / "nnunet-2.8.1-venv" / "bin" / "python"
        if not venv_python.is_file():
            raise FileNotFoundError("Pinned nnU-Net Python environment is missing")
        version = subprocess.check_output(
            [str(venv_python), "-c", "import importlib.metadata as m; print(m.version('nnunetv2'))"],
            text=True,
        ).strip()
        if version != "2.8.1":
            raise RuntimeError(f"Expected pinned nnunetv2 2.8.1, found {version}")
        helper = base / "nnunet-2.8.1-venv" / "bin" / "nnUNetv2_move_plans_between_datasets"
        if not helper.is_file():
            raise FileNotFoundError("Pinned nnU-Net move-plans command is missing")
    else:
        helper = None
    indices = range(10) if args.all else (int(args.unit[1:]),)
    targets: list[tuple[int, str, Path, Path, dict]] = []
    for index in indices:
        for arm in ("B", "Cneg"):
            dataset_id, name = target_name(index, arm)
            raw = raw_root / name
            destination = pp_root / name
            if not (raw / "dataset.json").is_file() or not (raw / "splits_final.json").is_file():
                raise FileNotFoundError(f"Target raw dataset or fixed split missing: {name}")
            target_json = json.loads((raw / "dataset.json").read_text(encoding="utf-8"))
            if target_json.get("labels") != {"background": 0, "LV": 1} or target_json.get("file_ending") != ".png":
                raise RuntimeError(f"Target dataset has unexpected label or file definition: {name}")
            provenance = {
                "plans_source_dataset": REFERENCE,
                "plans_source_sha256": sha256(source_plans_path),
                "fingerprint_source_dataset": REFERENCE,
                "fingerprint_source_sha256": sha256(fingerprint),
                "fingerprint_is_reference_not_target_statistic": True,
                "planning_scope_sha256": sha256(reference_raw / "planning_scope.json"),
                "target_raw_dataset": name,
                "target_split_sha256": sha256(raw / "splits_final.json"),
                "nnunetv2_version": "2.8.1",
                "plans_name": PLAN_NAME,
            }
            if destination.exists():
                verify_staged(raw, destination, fingerprint, source_plan, provenance)
                state = "verified"
            else:
                state = "not staged"
            print(f"{name}: {state}", flush=True)
            targets.append((dataset_id, name, raw, destination, provenance))
    if not args.write:
        print(f"Preflight PASS: {len(targets)} targets. No files were written.")
        return 0
    for dataset_id, name, raw, destination, provenance in targets:
        if destination.exists():
            continue
        destination.mkdir(parents=True)
        shutil.copy2(raw / "dataset.json", destination / "dataset.json")
        shutil.copy2(raw / "splits_final.json", destination / "splits_final.json")
        shutil.copy2(fingerprint, destination / "dataset_fingerprint.json")
        (destination / "planning_provenance.json").write_text(
            json.dumps(provenance, indent=2) + "\n", encoding="utf-8"
        )
        child_env = os.environ.copy()
        child_env.update({
            "nnUNet_raw": str(raw_root),
            "nnUNet_preprocessed": str(pp_root),
            "nnUNet_results": str(base / "nnUNet_results"),
        })
        subprocess.run(
            [str(helper), "-s", "900", "-t", str(dataset_id), "-sp", "nnUNetPlans", "-tp", PLAN_NAME],
            check=True,
            env=child_env,
        )
        verify_staged(raw, destination, fingerprint, source_plan, provenance)
        print(f"Staged shared 2D plan: {name}", flush=True)
    print(f"PASS: {len(targets)} target plans staged/verified; no preprocessing or training started.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
