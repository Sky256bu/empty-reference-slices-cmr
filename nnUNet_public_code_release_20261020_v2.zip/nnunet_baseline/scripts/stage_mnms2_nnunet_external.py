#!/usr/bin/env python3
"""Stage frozen Philips/GE ED/ES PNG slices for nnU-Net inference.

The default is a read-only preflight. ``--write`` copies only source images
into imagesTs, leaving GT at the source. The patient map remains in a private
file on the cloud and is never printed. Repeated runs verify each existing
file and refuse mismatches instead of replacing it.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import os
import shutil
from collections import Counter, defaultdict
from pathlib import Path

from prepare_mnms2_nnunet2d import (
    MANIFEST_SHA256,
    case_id,
    inside,
    norm_key,
    read_csv,
    sha256,
)
from verify_mnms2_nnunet2d_pair import load_png


EXPECTED_MANIFEST_ROWS = 8128
EXPECTED_VENDOR_PATIENTS = {"Philips": 88, "GE": 53}
EXPECTED_VENDOR_SLICES = {"Philips": 1796, "GE": 1276}
EXPECTED_PHASE_SLICES = {"ed": 1536, "es": 1536}
MAP_FIELDS = (
    "case_id", "patient_key", "phase", "z", "vendor", "image_rel", "gt_rel",
    "source_image_sha256", "source_gt_sha256",
)


def vendor_group(value: str) -> str:
    name = value.strip().lower()
    if "philips" in name:
        return "Philips"
    if "ge medical" in name or name == "ge":
        return "GE"
    if "siemens" in name:
        return "SIEMENS"
    raise RuntimeError("Manifest contains an unrecognized vendor")


def source_preflight(mroot: Path, audit_dir: Path) -> tuple[list[dict[str, str]], dict]:
    manifest = mroot / "manifest_mnms2.csv"
    audit_path = audit_dir / "input_audit_summary_v3.json"
    partition_path = audit_dir / "patient_partitions_v3.csv"
    scope_path = audit_dir / "label_scope_audit_v3.csv"
    physical_path = audit_dir / "input_file_manifest_v3.csv"
    for path in (manifest, audit_path, partition_path, scope_path, physical_path):
        if not path.is_file():
            raise RuntimeError("A required frozen manifest or input audit file is missing")
    if sha256(manifest) != MANIFEST_SHA256:
        raise RuntimeError("The source manifest differs from the frozen formal input")
    audit = json.loads(audit_path.read_text(encoding="utf-8"))
    if audit.get("status") != "PASS" or audit.get("manifest_sha256") != MANIFEST_SHA256:
        raise RuntimeError("Frozen input audit is not PASS or cites another manifest")
    if audit.get("external_patient_counts") != EXPECTED_VENDOR_PATIENTS:
        raise RuntimeError("Frozen input audit has unexpected external patient counts")
    for path in (partition_path, scope_path, physical_path):
        if audit.get("outputs", {}).get(path.name, {}).get("sha256") != sha256(path):
            raise RuntimeError("A frozen input audit file has changed")
    physical: dict[tuple[str, str], str] = {}
    for row in read_csv(physical_path):
        roles = row["roles"]
        for vendor in EXPECTED_VENDOR_PATIENTS:
            for kind in ("image", "gt"):
                role = f"external_{vendor}:{kind}"
                if role in roles:
                    item = (row["absolute_path"], role)
                    if item in physical and physical[item] != row["sha256"]:
                        raise RuntimeError("Frozen physical audit has conflicting external file hashes")
                    physical[item] = row["sha256"]

    partition = read_csv(partition_path)
    if len(partition) != 219:
        raise RuntimeError("The frozen SIEMENS partition has unexpected size")
    siemens_keys = {norm_key(row["key"]) for row in partition}
    if len(siemens_keys) != 219:
        raise RuntimeError("The frozen SIEMENS partition has duplicate patients")

    rows = read_csv(manifest)
    if len(rows) != EXPECTED_MANIFEST_ROWS:
        raise RuntimeError("The frozen manifest has an unexpected row count")
    image_root = mroot / "all"
    if not image_root.is_dir():
        raise RuntimeError("Source PNG export directory is missing")
    records: list[dict[str, str]] = []
    patients: dict[str, str] = {}
    stacks: dict[str, dict[str, set[int]]] = defaultdict(lambda: defaultdict(set))
    case_ids: set[str] = set()
    vendor_slices: Counter[str] = Counter()
    phase_slices: Counter[str] = Counter()

    for row in rows:
        key = norm_key(row["key"])
        vendor = vendor_group(row["vendor"])
        if key in patients and patients[key] != vendor:
            raise RuntimeError("A patient has inconsistent vendor metadata")
        patients[key] = vendor
        if vendor == "SIEMENS":
            continue
        if key in siemens_keys:
            raise RuntimeError("External evaluation patients overlap the SIEMENS partition")
        phase = row["phase"].strip().lower()
        if phase not in {"ed", "es"}:
            raise RuntimeError("An external slice has an unexpected phase")
        try:
            z = int(row["z"])
        except ValueError:
            raise RuntimeError("An external slice has a noninteger layer index") from None
        if z < 0 or z in stacks[key][phase]:
            raise RuntimeError("An external patient has duplicate or invalid layer indices")
        stacks[key][phase].add(z)
        cid = case_id(key, phase, z)
        if cid in case_ids:
            raise RuntimeError("An external case identifier collides")
        case_ids.add(cid)
        image = inside(image_root, row["img"])
        gt = inside(image_root, row["gt"])
        if not image.is_file() or not gt.is_file():
            raise RuntimeError("An external source image or GT is missing")
        try:
            image_shape, _, _ = load_png(image)
            gt_shape, gt_values, _ = load_png(gt)
        except Exception:
            raise RuntimeError("An external source image or GT is not a readable grayscale PNG") from None
        if image_shape != gt_shape or not gt_values.issubset({0, 255}):
            raise RuntimeError("An external source image/GT shape or label encoding is invalid")
        try:
            image_sha = sha256(image)
            gt_sha = sha256(gt)
        except OSError:
            raise RuntimeError("An external source image or GT could not be hashed") from None
        if (physical.get((str(image), f"external_{vendor}:image")) != image_sha
                or physical.get((str(gt), f"external_{vendor}:gt")) != gt_sha):
            raise RuntimeError("An external source image or GT differs from the frozen physical audit")
        records.append({
            "case_id": cid,
            "patient_key": key,
            "phase": phase,
            "z": str(z),
            "vendor": vendor,
            "image_rel": row["img"],
            "gt_rel": row["gt"],
            "source_image_sha256": image_sha,
            "source_gt_sha256": gt_sha,
        })
        vendor_slices[vendor] += 1
        phase_slices[phase] += 1

    if Counter(patients.values()) != Counter({"SIEMENS": 219, **EXPECTED_VENDOR_PATIENTS}):
        raise RuntimeError("Manifest vendor patient counts differ from the frozen cohort")
    if not siemens_keys.issubset(patients):
        raise RuntimeError("The SIEMENS partition is not contained in the manifest")
    if vendor_slices != Counter(EXPECTED_VENDOR_SLICES) or phase_slices != Counter(EXPECTED_PHASE_SLICES):
        raise RuntimeError("External vendor or phase slice counts differ from the frozen cohort")
    if len(records) != 3072 or len(stacks) != 141:
        raise RuntimeError("The external case set does not close")
    for phases in stacks.values():
        if set(phases) != {"ed", "es"} or phases["ed"] != phases["es"]:
            raise RuntimeError("An external patient lacks a matched ED/ES full stack")
        zs = phases["ed"]
        if not zs or zs != set(range(max(zs) + 1)):
            raise RuntimeError("An external ED/ES stack has missing layers")

    records.sort(key=lambda row: row["case_id"])
    inventory_text = "".join(
        f"{row['case_id']}_0000.png\t{row['source_image_sha256']}\n" for row in records
    )
    inventory_sha = hashlib.sha256(inventory_text.encode("ascii")).hexdigest()
    audit_data = {
        "status": "PASS",
        "purpose": "M&Ms-2 frozen Philips/GE full-stack nnU-Net inference images",
        "manifest_sha256": MANIFEST_SHA256,
        "source_audit_sha256": sha256(audit_path),
        "cases": len(records),
        "patients": 141,
        "vendor_patients": EXPECTED_VENDOR_PATIENTS,
        "vendor_slices": EXPECTED_VENDOR_SLICES,
        "phase_slices": EXPECTED_PHASE_SLICES,
        "input_inventory_sha256": inventory_sha,
    }
    return records, audit_data


def private_map_text(records: list[dict[str, str]]) -> str:
    stream = io.StringIO(newline="")
    writer = csv.DictWriter(stream, fieldnames=MAP_FIELDS, lineterminator="\n")
    writer.writeheader()
    writer.writerows(records)
    return stream.getvalue()


def inspect_output(
    output_root: Path, mroot: Path, records: list[dict[str, str]], audit: dict,
    *, require_complete: bool,
) -> tuple[int, int]:
    images = output_root / "imagesTs"
    expected_names = {f"{row['case_id']}_0000.png" for row in records}
    pending_names = {f".{name}.staging" for name in expected_names}
    if not output_root.exists():
        if require_complete:
            raise RuntimeError("External input directory is absent")
        return 0, len(records)
    if not output_root.is_dir() or output_root.is_symlink():
        raise RuntimeError("External input root is not a plain directory")
    permitted_root = {"imagesTs", "private_map.csv", "stage_audit.json"}
    if {entry.name for entry in output_root.iterdir()} - permitted_root:
        raise RuntimeError("External input root contains unexpected files")
    if not images.is_dir() or images.is_symlink():
        raise RuntimeError("External imagesTs directory is absent or is a link")
    existing = {entry.name: entry for entry in images.iterdir()}
    if set(existing) - expected_names - pending_names or any(
        not p.is_file() or p.is_symlink() for p in existing.values()
    ):
        raise RuntimeError("imagesTs contains unexpected files or links")
    expected_map = private_map_text(records).encode("utf-8")
    map_path = output_root / "private_map.csv"
    if map_path.exists() and (map_path.is_symlink() or map_path.read_bytes() != expected_map):
        raise RuntimeError("Existing private map differs from the frozen source plan")
    if require_complete and not map_path.is_file():
        raise RuntimeError("External private map is missing")
    expected_audit = {**audit, "input_dir": str(images)}
    audit_path = output_root / "stage_audit.json"
    if audit_path.exists() and (audit_path.is_symlink() or json.loads(audit_path.read_text(encoding="utf-8")) != expected_audit):
        raise RuntimeError("Existing stage audit differs from the frozen source plan")
    if require_complete and not audit_path.is_file():
        raise RuntimeError("External stage audit is missing")
    copied = 0
    for row in records:
        name = f"{row['case_id']}_0000.png"
        pending = existing.get(f".{name}.staging")
        if pending is not None and sha256(pending) != row["source_image_sha256"]:
            raise RuntimeError(
                "An interrupted staging file differs from its frozen source; inspect it before retrying"
            )
        target = existing.get(name)
        if target is None:
            continue
        if sha256(target) != row["source_image_sha256"]:
            raise RuntimeError("A staged image differs from its source PNG")
        copied += 1
    if require_complete and copied != len(records):
        raise RuntimeError("External imagesTs is incomplete")
    if require_complete and set(existing) & pending_names:
        raise RuntimeError("Verified temporary staging files remain after copying")
    return copied, len(records) - copied


def write_stage(output_root: Path, mroot: Path, records: list[dict[str, str]], audit: dict) -> None:
    output_root.mkdir(parents=True, exist_ok=True)
    images = output_root / "imagesTs"
    images.mkdir(exist_ok=True)
    inspect_output(output_root, mroot, records, audit, require_complete=False)
    source_root = mroot / "all"
    for row in records:
        destination = images / f"{row['case_id']}_0000.png"
        pending = images / f".{destination.name}.staging"
        if destination.exists():
            if pending.exists():
                # inspect_output already verified both files byte-for-byte
                # against the frozen source, so this is a safe duplicate.
                pending.unlink()
            continue
        if not pending.exists():
            source = inside(source_root, row["image_rel"])
            try:
                with source.open("rb") as src, pending.open("xb") as dst:
                    shutil.copyfileobj(src, dst, 1024 * 1024)
            except FileExistsError:
                raise RuntimeError("A temporary staged image appeared concurrently; refusing to overwrite") from None
            except OSError:
                raise RuntimeError("An external image could not be copied; inspect the temporary staging file") from None
        if sha256(pending) != row["source_image_sha256"]:
            raise RuntimeError("A temporary copied image differs from its frozen source; inspect it before retrying")
        try:
            # Hard-link publication is atomic and refuses to replace an
            # existing destination. Both names live in the same directory.
            os.link(pending, destination)
        except FileExistsError:
            raise RuntimeError("A staged image appeared concurrently; refusing to overwrite") from None
        except OSError:
            raise RuntimeError("A verified temporary image could not be published") from None
        pending.unlink()

    map_path = output_root / "private_map.csv"
    if not map_path.exists():
        with map_path.open("xb") as stream:
            stream.write(private_map_text(records).encode("utf-8"))
    audit_path = output_root / "stage_audit.json"
    if not audit_path.exists():
        payload = {**audit, "input_dir": str(images)}
        with audit_path.open("x", encoding="utf-8") as stream:
            json.dump(payload, stream, indent=2)
            stream.write("\n")
    inspect_output(output_root, mroot, records, audit, require_complete=True)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mroot", type=Path, default=Path("/root/autodl-tmp/mnms/seg_lv"))
    parser.add_argument("--audit-dir", type=Path)
    parser.add_argument("--output-root", type=Path, default=Path("/root/autodl-tmp/nnUNet_external_input"))
    parser.add_argument("--write", action="store_true", help="Stage only the external inference images")
    args = parser.parse_args()
    mroot = args.mroot.expanduser().resolve()
    audit_dir = (args.audit_dir or mroot / "scope_control_v3_zero_gpu_audit").expanduser().resolve()
    output_root = args.output_root.expanduser().resolve()
    if output_root.is_relative_to(mroot) or mroot.is_relative_to(output_root):
        parser.error("Source export and external input roots must not contain each other")
    records, audit = source_preflight(mroot, audit_dir)
    present, missing = inspect_output(output_root, mroot, records, audit, require_complete=False)
    print(
        f"Source preflight PASS: 141 Philips/GE patients; {audit['cases']} ED/ES slices; "
        f"{present} staged, {missing} missing.", flush=True,
    )
    if args.write:
        write_stage(output_root, mroot, records, audit)
        print("Stage PASS: all external images verified; private map and GT remain on the cloud.")
    else:
        print("Read-only preflight complete; no files were written.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
