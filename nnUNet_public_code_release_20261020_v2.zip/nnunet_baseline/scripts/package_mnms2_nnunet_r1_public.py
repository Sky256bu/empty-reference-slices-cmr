#!/usr/bin/env python3
"""Package only anonymous, audited nnU-Net rep00 aggregate results.

The default invocation is a read-only preflight. Use --write after saving the
secondary-analysis and targeted-outlier JSON stdout on the cloud. The bundle
contains no case rows, mappings, images, checkpoints, split contents, or logs.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import re
import sys
from pathlib import Path


UNITS = tuple(f"u{i:02d}" for i in range(10))
ARMS = ("B", "Cneg")
VENDORS = {"Philips": 88, "GE": 53, "All": 141}
MODELS = tuple(f"{unit}_{arm}" for unit in UNITS for arm in ARMS)
HEX64 = re.compile(r"[0-9a-f]{64}\Z")
AUDITED_CSVS = (
    "private/slice_metrics_PRIVATE.csv",
    "private/case_metrics_PRIVATE.csv",
    "private/paired_case_metrics_PRIVATE.csv",
    "public/unit_arm_vendor_summary.csv",
    "public/paired_unit_vendor_summary.csv",
    "public/paired_overall_summary.csv",
)
PUBLIC_CSVS = AUDITED_CSVS[3:]
PHASE_METRICS = (
    "dice_full_stack", "dice_volume_present", "dice_slice_present",
    "slices", "present_slices", "empty_gt_slices", "empty_gt_fp_slices",
    "empty_gt_fp_px",
)
ARM_FIELDS = {
    "unit", "arm", "vendor", "patients", "ef_valid_patients",
    "ef_invalid_patients", "ef_out_of_range_patients", "ef_mae_pp",
    "ef_ae_median_pp", "ef_ae_p90_pp", "ef_ae_gt20_patients",
    "ef_ae_gt40_patients", "edv_mae_ml", "esv_mae_ml",
} | {
    f"{phase}_{metric}_{'total' if metric in PHASE_METRICS[3:] else 'mean'}"
    for phase in ("ed", "es") for metric in PHASE_METRICS
}
UNIT_FIELDS = {
    "unit", "vendor", "patients", "paired_valid_patients",
    "b_invalid_patients", "cneg_invalid_patients",
    "b_minus_cneg_ef_ae_mean_pp", "b_minus_cneg_ef_ae_median_pp",
}
OVERALL_FIELDS = {
    "vendor", "units", "patients_per_unit", "complete_ef_endpoint",
    "b_invalid_evaluations", "cneg_invalid_evaluations", "b_ef_mae_pp",
    "cneg_ef_mae_pp", "paired_b_minus_cneg_mean_pp", "paired_unit_sd_pp",
    "units_favoring_b", "partial_paired_valid_unit_mean_pp",
    "bootstrap_seed", "bootstrap_draws", "bootstrap_ci_low_pp",
    "bootstrap_ci_high_pp",
}
METRICS = (
    "ed_dice_full_stack", "es_dice_full_stack", "edv_abs_error_ml",
    "esv_abs_error_ml", "ed_empty_gt_fp_slices_per_evaluation",
    "es_empty_gt_fp_slices_per_evaluation", "ef_invalid_rate_pct",
)
OUTLIER_CATEGORIES = {
    "predicted_EDV_below_5_percent_of_GT", "predicted_EDV_below_1_mL",
    "predicted_ESV_exceeds_EDV", "none_of_the_predefined_volume_categories",
}
AUDIT_KEYS = {
    "schema", "status", "created_utc", "purpose", "rep", "models",
    "cases_per_model", "evaluator_script_sha256", "patients_per_model",
    "manifest_sha256", "stage_audit_sha256", "physical_input_audit_sha256",
    "checkpoint_sha256", "prediction_inventories", "prediction_audit_sha256",
    "thresholds", "voxel_ml", "ef_formula", "dice_definition",
    "invalid_ef_policy", "bootstrap", "output_sha256",
}


class PackageError(Exception):
    """A privacy-safe error category; never includes private file contents."""


def require(condition: bool, message: str) -> None:
    if not condition:
        raise PackageError(message)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def no_symlink_components(path: Path) -> None:
    require(".." not in path.parts, "A path contains a parent traversal")
    current = Path(path.anchor)
    for part in path.parts[1:]:
        current /= part
        require(not current.is_symlink(), "A source or destination contains a symlink")


def source_file(base: Path, path: Path) -> Path:
    path = path.expanduser().absolute()
    no_symlink_components(path)
    try:
        path.relative_to(base)
    except ValueError:
        raise PackageError("An input is outside the cloud data root") from None
    require(path.is_file() and path.stat().st_size > 0,
            "A required input is missing or empty")
    return path


def load_json(base: Path, path: Path) -> dict:
    try:
        data = json.loads(source_file(base, path).read_text(encoding="utf-8"))
    except (OSError, UnicodeError, ValueError):
        raise PackageError("A required JSON input is unreadable") from None
    require(isinstance(data, dict), "A JSON input has the wrong structure")
    return data


def digest(value: object) -> str:
    require(isinstance(value, str) and HEX64.fullmatch(value) is not None,
            "An audit contains an invalid SHA256")
    return value


def verify_public_csv(path: Path, kind: str) -> None:
    expected_fields = {
        "unit_arm_vendor_summary.csv": ARM_FIELDS,
        "paired_unit_vendor_summary.csv": UNIT_FIELDS,
        "paired_overall_summary.csv": OVERALL_FIELDS,
    }[kind]
    expected_keys = (
        {(unit, arm, vendor) for unit in UNITS for arm in ARMS for vendor in VENDORS}
        if kind == "unit_arm_vendor_summary.csv" else
        {(unit, vendor) for unit in UNITS for vendor in VENDORS}
        if kind == "paired_unit_vendor_summary.csv" else
        {(vendor,) for vendor in VENDORS}
    )
    observed = set()
    try:
        with path.open(newline="", encoding="utf-8-sig") as stream:
            reader = csv.DictReader(stream)
            require(reader.fieldnames is not None and len(reader.fieldnames) == len(expected_fields)
                    and set(reader.fieldnames) == expected_fields,
                    "A public CSV has unexpected columns")
            key_fields = ("unit", "arm", "vendor") if len(next(iter(expected_keys))) == 3 else (
                ("unit", "vendor") if len(next(iter(expected_keys))) == 2 else ("vendor",))
            for row in reader:
                require(None not in row and all(value is not None for value in row.values()),
                        "A public CSV has an extra field")
                key = tuple(row[field] for field in key_fields)
                require(key in expected_keys and key not in observed,
                        "A public CSV has an unexpected or duplicate aggregate row")
                observed.add(key)
                for field, value in row.items():
                    if field in key_fields or value == "":
                        continue
                    number = float(value)
                    require(math.isfinite(number), "A public CSV has a nonfinite value")
    except (OSError, UnicodeError, ValueError, csv.Error):
        raise PackageError("A public CSV is unreadable or nonnumeric") from None
    require(observed == expected_keys, "A public CSV has incomplete aggregate rows")


def verify_evaluation(base: Path, evaluation: Path) -> tuple[dict, dict[str, str]]:
    audit_path = source_file(base, evaluation / "public" / "evaluation_audit.json")
    audit = load_json(base, audit_path)
    require(set(audit) == AUDIT_KEYS and audit.get("schema") == "mnms2_nnunet_external_evaluation_v1"
            and audit.get("status") == "PASS" and audit.get("rep") == "rep00"
            and audit.get("purpose") == "exploratory_additional_analysis_on_previously_used_held_out_vendors"
            and audit.get("models") == 20 and audit.get("cases_per_model") == 3072
            and audit.get("patients_per_model") == 141,
            "The evaluation audit is not the expected PASS rep00 run")
    require(isinstance(audit.get("created_utc"), str)
            and re.fullmatch(r"\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?\+00:00", audit["created_utc"]),
            "The evaluation audit timestamp is invalid")
    for field in ("evaluator_script_sha256", "manifest_sha256", "stage_audit_sha256",
                  "physical_input_audit_sha256"):
        digest(audit.get(field))
    for field in ("checkpoint_sha256", "prediction_inventories", "prediction_audit_sha256"):
        mapping = audit.get(field)
        require(isinstance(mapping, dict) and set(mapping) == set(MODELS),
                "The evaluation audit has an incomplete model inventory")
        for value in mapping.values():
            digest(value)
    require(audit.get("thresholds") == {
        "source_gt_png": ">127 of 0/255", "nnunet_prediction_png": ">0 of 0/1"},
        "The evaluation audit has unexpected mask thresholds")
    require(audit.get("voxel_ml") == "abs(det(original_GT_NIfTI_affine_3x3))/1000"
            and audit.get("ef_formula") == "100*(EDV-ESV)/EDV; EDV<=1e-6 mL is invalid"
            and audit.get("dice_definition") == "full_stack counts all slices; volume_present pools GT-positive slices; slice_present averages GT-positive slice Dice; empty-empty slice Dice=1"
            and audit.get("invalid_ef_policy") == "Retained in private case rows and public denominators; no full-endpoint bootstrap if any invalid EF",
            "The evaluation audit metric policy differs")
    bootstrap = audit.get("bootstrap")
    require(isinstance(bootstrap, dict) and bootstrap == {
        "seed": 20260928, "draws": 2000,
        "resampling": "training unit and vendor-stratified patient, preserving repeated patient measurements across units"},
        "The evaluation audit bootstrap differs")
    hashes = audit.get("output_sha256")
    require(isinstance(hashes, dict) and set(hashes) == set(AUDITED_CSVS),
            "The evaluation audit has an incomplete CSV inventory")
    for relative in AUDITED_CSVS:
        expected = digest(hashes[relative])
        path = source_file(base, evaluation / relative)
        require(sha256(path) == expected, "An audited CSV SHA256 differs")
        if relative.startswith("public/"):
            verify_public_csv(path, Path(relative).name)
    return audit, {"evaluation_audit": sha256(audit_path), **{
        Path(relative).name: hashes[relative] for relative in AUDITED_CSVS}}


def finite(value: object) -> float:
    require(type(value) in (int, float) and math.isfinite(value),
            "An aggregate JSON contains a nonfinite or nonnumeric value")
    return float(value)


def number_or_none(value: object) -> float | None:
    return None if value is None else finite(value)


def checked_pair(value: object) -> list[float]:
    require(isinstance(value, list) and len(value) == 2,
            "An aggregate confidence interval has the wrong structure")
    low, high = map(finite, value)
    require(low <= high, "An aggregate confidence interval is reversed")
    return [low, high]


def sanitize_secondary(raw: dict, audit: dict) -> dict:
    require(raw.get("status") == "PASS" and raw.get("rep") == "rep00"
            and raw.get("analysis") == "post_hoc_exploratory_R1_after_inspecting_EF"
            and raw.get("models") == 20 and raw.get("private_case_rows_read") == 2820
            and raw.get("audited_csv_sha256_verified") == 6
            and raw.get("audit_evaluator_sha256") == audit["evaluator_script_sha256"]
            and "by_unit" not in json.dumps(raw.get("by_vendor", [])),
            "The secondary summary is not the expected aggregate PASS analysis")
    bootstrap = raw.get("bootstrap")
    require(isinstance(bootstrap, dict) and bootstrap.get("seed") == 20260928
            and bootstrap.get("draws") == 2000,
            "The secondary summary bootstrap differs")
    by_vendor = raw.get("by_vendor")
    require(isinstance(by_vendor, list) and len(by_vendor) == 3,
            "The secondary summary has an incomplete vendor inventory")
    sanitized = []
    observed = set()
    for item in by_vendor:
        require(isinstance(item, dict), "A vendor aggregate has the wrong structure")
        vendor = item.get("vendor")
        require(vendor in VENDORS and vendor not in observed
                and item.get("unique_patients") == VENDORS[vendor]
                and item.get("paired_unit_patient_evaluations") == 10 * VENDORS[vendor],
                "A vendor aggregate has an unexpected denominator")
        observed.add(vendor)
        metrics = item.get("metrics")
        require(isinstance(metrics, dict) and set(metrics) == set(METRICS),
                "The secondary metric inventory differs")
        clean_metrics = {}
        for name in METRICS:
            record = metrics[name]
            require(isinstance(record, dict), "A secondary metric has the wrong structure")
            direction = record.get("unit_direction")
            require(isinstance(direction, dict) and set(direction) == {"b", "cneg", "tie"}
                    and all(type(direction[key]) is int and direction[key] >= 0 for key in direction)
                    and sum(direction.values()) == 10,
                    "A secondary unit direction is invalid")
            clean_metrics[name] = {
                "b_mean": finite(record.get("b_mean")),
                "cneg_mean": finite(record.get("cneg_mean")),
                "b_minus_cneg_mean": finite(record.get("b_minus_cneg_mean")),
                "ci95": checked_pair(record.get("ci95")),
                "unit_direction": dict(direction),
            }
        fp = item.get("empty_gt_fp")
        require(isinstance(fp, dict) and set(fp) == {"ed", "es"},
                "The empty-GT aggregate has the wrong structure")
        clean_fp = {}
        for phase in ("ed", "es"):
            entry = fp[phase]
            require(isinstance(entry, dict), "An empty-GT phase has the wrong structure")
            counts = {}
            for key in ("empty_gt_slices", "b_fp_slices", "cneg_fp_slices",
                        "b_minus_cneg_fp_slices"):
                value = entry.get(key)
                require(type(value) is int, "An empty-GT count is invalid")
                counts[key] = value
            require(counts["empty_gt_slices"] > 0
                    and 0 <= counts["b_fp_slices"] <= counts["empty_gt_slices"]
                    and 0 <= counts["cneg_fp_slices"] <= counts["empty_gt_slices"]
                    and counts["b_minus_cneg_fp_slices"] == counts["b_fp_slices"] - counts["cneg_fp_slices"],
                    "An empty-GT count is inconsistent")
            clean_fp[phase] = {**counts,
                "b_rate_pct": number_or_none(entry.get("b_rate_pct")),
                "cneg_rate_pct": number_or_none(entry.get("cneg_rate_pct")),
                "b_minus_cneg_rate_pp": number_or_none(entry.get("b_minus_cneg_rate_pp")),
                "rate_diff_ci95_pp": checked_pair(entry.get("rate_diff_ci95_pp")),
            }
        sanitized.append({
            "vendor": vendor, "unique_patients": VENDORS[vendor],
            "paired_unit_patient_evaluations": 10 * VENDORS[vendor],
            "metrics": clean_metrics, "empty_gt_fp": clean_fp,
        })
    require(observed == set(VENDORS), "The secondary summary lacks a vendor")
    return {
        "status": "PASS", "rep": "rep00",
        "analysis": "post_hoc_exploratory_R1_after_inspecting_EF",
        "audited_csv_sha256_verified": 6,
        "audit_evaluator_sha256": audit["evaluator_script_sha256"],
        "models": 20, "private_case_rows_read": 2820,
        "bootstrap": {"seed": 20260928, "draws": 2000,
                      "ci": "percentile 95%; exploratory; no multiplicity adjustment"},
        "by_vendor": sanitized,
    }


def sanitize_outlier(raw: dict) -> dict:
    fixed = {
        "status": "PASS", "scope": "rep00 u03/B GE largest finite EF absolute error",
        "audited_csv_checksums_verified": 6, "prediction_PNG_inventory": "PASS",
        "manifest_stage_ED_ES_mapping": "PASS",
        "source_GT_PNG_and_NIfTI_affine": "PASS",
        "stored_slice_and_case_metrics_recomputed": "PASS",
    }
    require(all(raw.get(key) == value for key, value in fixed.items()),
            "The targeted outlier audit is not PASS")
    counts = raw.get("extreme_B_u03_GE_case_counts")
    require(isinstance(counts, dict)
            and set(counts) == {"ef_abs_error_gt_100_pp", "ef_abs_error_gt_500_pp"}
            and all(type(value) is int and 0 <= value <= 53 for value in counts.values())
            and counts["ef_abs_error_gt_500_pp"] <= counts["ef_abs_error_gt_100_pp"],
            "The targeted outlier counts are invalid")
    categories = raw.get("target_volume_categories")
    require(isinstance(categories, list) and bool(categories)
            and len(categories) == len(set(categories))
            and all(value in OUTLIER_CATEGORIES for value in categories),
            "The targeted outlier categories are invalid")
    return {**fixed, "extreme_B_u03_GE_case_counts": dict(counts),
            "target_volume_categories": list(categories)}


def verify_formal(base: Path, audit: dict) -> dict:
    provenance = {}
    for unit in UNITS:
        for arm in ARMS:
            model = f"{unit}_{arm}"
            dataset_id = 901 + 2 * int(unit[1:]) + int(arm == "Cneg")
            dataset = f"Dataset{dataset_id:03d}_MnMS2_{unit}_{arm}"
            formal_path = source_file(base, base / "nnUNet_results_formal" / "rep00"
                                      / "_audit" / f"{model}.json")
            formal = load_json(base, formal_path)
            artifacts = formal.get("validated_artifacts")
            require(formal.get("status") == "PASS"
                    and formal.get("schema") == "mnms2_nnunet2d_formal_v1"
                    and formal.get("unit") == unit and formal.get("arm") == arm
                    and formal.get("rep") == "rep00" and formal.get("dataset") == dataset
                    and formal.get("planned_epochs") == 1000
                    and formal.get("final_model_rule") == "checkpoint_final.pth_only"
                    and isinstance(artifacts, dict)
                    and artifacts.get("checkpoint_final_sha256") == audit["checkpoint_sha256"][model],
                    "A formal training audit differs from the external evaluation")
            split = source_file(base, base / "nnUNet_preprocessed" / dataset
                                / "splits_final.json")
            split_sha = digest(formal.get("fixed_split_sha256"))
            require(sha256(split) == split_sha,
                    "A fixed training split differs from its formal audit")
            checkpoint = source_file(base, base / "nnUNet_results_formal" / "rep00"
                                     / dataset / "nnUNetTrainer__nnUNetPlansSharedU00GT__2d"
                                     / "fold_0" / "checkpoint_final.pth")
            require(sha256(checkpoint) == artifacts["checkpoint_final_sha256"],
                    "A final checkpoint differs from its formal audit")
            provenance[model] = {
                "formal_audit_sha256": sha256(formal_path),
                "fixed_split_sha256": split_sha,
                "checkpoint_final_sha256": artifacts["checkpoint_final_sha256"],
                "validation_summary_sha256": digest(artifacts.get("validation_summary_sha256")),
                "validation_predictions_inventory_sha256": digest(
                    artifacts.get("validation_predictions_inventory_sha256")),
                "external_prediction_inventory_sha256": audit["prediction_inventories"][model],
                "external_prediction_audit_sha256": audit["prediction_audit_sha256"][model],
            }
    return provenance


def preflight(base: Path, secondary_path: Path, outlier_path: Path,
              bundle: Path) -> tuple[dict[str, bytes], dict]:
    evaluation = base / "nnUNet_external_evaluation" / "rep00"
    audit, hashes = verify_evaluation(base, evaluation)
    secondary_source = source_file(base, secondary_path)
    outlier_source = source_file(base, outlier_path)
    secondary = sanitize_secondary(load_json(base, secondary_source), audit)
    outlier = sanitize_outlier(load_json(base, outlier_source))
    models = verify_formal(base, audit)
    require(bundle.parent == base and not bundle.exists()
            and not bundle.with_name(bundle.name + ".STAGING").exists(),
            "The public bundle destination already exists or is outside the cloud root")
    no_symlink_components(bundle)
    copied = {
        "evaluation_audit.json": source_file(base, evaluation / "public" / "evaluation_audit.json").read_bytes(),
        **{Path(relative).name: source_file(base, evaluation / relative).read_bytes()
           for relative in PUBLIC_CSVS},
    }
    generated = {
        "secondary_summary_public.json": (json.dumps(secondary, indent=2, allow_nan=False) + "\n").encode(),
        "outlier_audit_public.json": (json.dumps(outlier, indent=2, allow_nan=False) + "\n").encode(),
    }
    files = {**copied, **generated}
    provenance = {
        "schema": "mnms2_nnunet_r1_public_bundle_v1", "status": "PASS",
        "scope": "rep00; 10 paired units; 20 models; exploratory external analysis",
        "copied_or_generated_files_sha256": {
            name: hashlib.sha256(content).hexdigest() for name, content in files.items()},
        "evaluation_audit_sha256": hashes["evaluation_audit"],
        "private_evaluation_csv_sha256": {
            Path(relative).name: hashes[Path(relative).name]
            for relative in AUDITED_CSVS if relative.startswith("private/")},
        "secondary_source_json_sha256": sha256(secondary_source),
        "outlier_source_json_sha256": sha256(outlier_source),
        "evaluator_script_sha256": audit["evaluator_script_sha256"],
        "manifest_sha256": audit["manifest_sha256"],
        "stage_audit_sha256": audit["stage_audit_sha256"],
        "physical_input_audit_sha256": audit["physical_input_audit_sha256"],
        "model_artifact_sha256": models,
        "excluded_artifact_classes": [
            "private case and slice tables", "patient mappings", "source and prediction PNGs",
            "checkpoint bytes", "fixed split contents", "training and prediction logs",
        ],
    }
    files["provenance.json"] = (json.dumps(provenance, indent=2, allow_nan=False) + "\n").encode()
    return files, provenance


def write_bundle(bundle: Path, files: dict[str, bytes]) -> None:
    staging = bundle.with_name(bundle.name + ".STAGING")
    require(not bundle.exists() and not staging.exists(),
            "The public bundle destination already exists")
    if os.name == "posix":
        os.umask(0o077)
        staging.mkdir(mode=0o700)
    else:
        staging.mkdir()
    for name, content in files.items():
        require(name == Path(name).name and "/" not in name and "\\" not in name,
                "An output filename is unsafe")
        with (staging / name).open("xb") as stream:
            stream.write(content)
    staging.rename(bundle)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, default=Path("/root/autodl-tmp"))
    parser.add_argument("--secondary-json", type=Path)
    parser.add_argument("--outlier-json", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--write", action="store_true",
                        help="Create the new, fixed-whitelist public bundle")
    args = parser.parse_args()
    try:
        no_symlink_components(args.base.expanduser().absolute())
        base = args.base.expanduser().resolve(strict=True)
        require(base.is_dir(), "The cloud data root is missing")
        secondary = args.secondary_json or base / "nnUNet_r1_secondary_summary_rep00.json"
        outlier = args.outlier_json or base / "nnUNet_r1_outlier_audit_rep00.json"
        bundle = args.output or base / "nnUNet_r1_public_bundle_rep00"
        if not secondary.is_absolute():
            secondary = base / secondary
        if not outlier.is_absolute():
            outlier = base / outlier
        if not bundle.is_absolute():
            bundle = base / bundle
        bundle = bundle.absolute()
        files, provenance = preflight(base, secondary, outlier, bundle)
        print(f"PREFLIGHT PASS: {len(MODELS)} models, {len(AUDITED_CSVS)} audited CSVs, "
              f"{len(files)} public files; no case rows or images in bundle.")
        if args.write:
            write_bundle(bundle, files)
            print("BUNDLE PASS: public aggregate bundle created and SHA256 provenance saved.")
        else:
            print("Read-only preflight complete; no files were written. Use --write to package.")
    except (PackageError, OSError, UnicodeError, ValueError, TypeError, KeyError) as exc:
        # No paths or parsed private values are included in error output.
        message = str(exc) if isinstance(exc, PackageError) else "input or filesystem validation failed"
        print(f"PACKAGE FAIL: {message}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
