#!/usr/bin/env python3
"""Audited nnU-Net v2.8.1 inference on complete Philips/GE M&Ms-2 stacks.

Read-only preflight by default. --write predicts only missing model cells;
--resume continues previously interrupted cells after checking existing
predictions; --continue safely resumes partial cells and starts missing cells.
No source labels enter the nnU-Net input directory.
The private case mapping and all prediction PNGs remain on the cloud.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import importlib.metadata
import json
import os
import shutil
import subprocess
import sys
import time
from contextlib import ExitStack
from datetime import datetime, timezone
from pathlib import Path

from prepare_mnms2_nnunet2d import MANIFEST_SHA256, case_id, norm_key
from summarize_mnms2_nnunet2d_formal import checked_dice, sha256


SCHEMA = "mnms2_nnunet_external_predict_v1"
PLAN = "nnUNetPlansSharedU00GT"
TRAINER = "nnUNetTrainer"
EXPECTED_CASES = 3072
MIN_FREE_GIB = 10.0


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def write_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def inventory(paths: list[Path]) -> str:
    digest = hashlib.sha256()
    for path in sorted(paths, key=lambda item: item.name):
        digest.update(f"{path.name}\t{sha256(path)}\n".encode("utf-8"))
    return digest.hexdigest()


def external_case_ids(manifest_path: Path) -> set[str]:
    if sha256(manifest_path) != MANIFEST_SHA256:
        raise RuntimeError("Frozen M&Ms-2 manifest SHA256 differs")
    cases: set[str] = set()
    patients: dict[str, set[str]] = {"Philips": set(), "GE": set()}
    counts = {"Philips": 0, "GE": 0}
    phases: dict[tuple[str, str], set[str]] = {}
    with manifest_path.open("r", encoding="utf-8-sig", newline="") as stream:
        for row in csv.DictReader(stream):
            vendor = row["vendor"].casefold()
            if "philips" in vendor:
                domain = "Philips"
            elif "ge" in vendor:
                domain = "GE"
            else:
                continue
            key = norm_key(row["key"])
            phase = row["phase"].lower()
            if phase not in ("ed", "es"):
                raise RuntimeError("Unexpected external cardiac phase")
            z = int(row["z"])
            cid = case_id(key, phase, z)
            if cid in cases:
                raise RuntimeError("External manifest contains duplicate/colliding slice identifiers")
            cases.add(cid)
            patients[domain].add(key)
            counts[domain] += 1
            phases.setdefault((domain, key), set()).add(phase)
    if (len(cases) != EXPECTED_CASES or counts != {"Philips": 1796, "GE": 1276}
            or len(patients["Philips"]) != 88 or len(patients["GE"]) != 53
            or any(value != {"ed", "es"} for value in phases.values())):
        raise RuntimeError("External manifest patient, phase or slice counts differ from frozen design")
    if patients["Philips"] & patients["GE"]:
        raise RuntimeError("A patient appears under both external vendors")
    return cases


def verify_stage(base: Path) -> tuple[Path, str, set[str]]:
    stage_root = base / "nnUNet_external_input"
    image_dir = stage_root / "imagesTs"
    audit_path = stage_root / "stage_audit.json"
    audit = json.loads(audit_path.read_text(encoding="utf-8"))
    if (audit.get("status") != "PASS" or audit.get("manifest_sha256") != MANIFEST_SHA256
            or audit.get("cases") != EXPECTED_CASES):
        raise RuntimeError("External input stage audit is missing or differs from frozen design")
    if Path(str(audit.get("input_dir", ""))).resolve() != image_dir.resolve():
        raise RuntimeError("External input stage audit points to another image directory")
    if not (stage_root / "private_map.csv").is_file():
        raise RuntimeError("External input private mapping is missing")
    source_audit_path = base / "mnms" / "seg_lv" / "scope_control_v3_zero_gpu_audit" / "input_audit_summary_v3.json"
    if sha256(source_audit_path) != audit.get("source_audit_sha256"):
        raise RuntimeError("Frozen source input audit differs from stage audit")
    expected = external_case_ids(base / "mnms" / "seg_lv" / "manifest_mnms2.csv")
    image_paths = sorted(image_dir.glob("*.png"))
    observed = {path.stem.removesuffix("_0000") for path in image_paths
                if path.stem.endswith("_0000")}
    if (len(image_paths) != EXPECTED_CASES or observed != expected
            or len(observed) != len(image_paths)):
        raise RuntimeError("Staged external input image set is incomplete or contains extras")
    if any(path.name != f"{path.stem.removesuffix('_0000')}_0000.png" for path in image_paths):
        raise RuntimeError("Staged external input names are not single-channel nnU-Net names")
    if any(path.is_symlink() or path.stat().st_size == 0 for path in image_paths):
        raise RuntimeError("Staged external inputs contain a symlink or empty file")
    if inventory(image_paths) != audit.get("input_inventory_sha256"):
        raise RuntimeError("Staged external image bytes differ from PASS audit")
    unexpected = [path for path in image_dir.iterdir() if path.suffix.lower() != ".png"]
    if unexpected:
        raise RuntimeError("Non-image file found in the prediction input directory")
    return image_dir, sha256(audit_path), expected


def cell(base: Path, rep: int, unit: str, arm: str) -> dict:
    number = int(unit[1:])
    dataset_id = 901 + 2 * number + int(arm == "Cneg")
    dataset = f"Dataset{dataset_id:03d}_MnMS2_{unit}_{arm}"
    result_root = base / "nnUNet_results_formal" / f"rep{rep:02d}"
    # This verifies the formal PASS audit, final checkpoint and fixed validation
    # summary against their recorded hashes before any external prediction.
    checked_dice(base, result_root, unit, arm)
    model_folder = result_root / dataset / f"{TRAINER}__{PLAN}__2d"
    checkpoint = model_folder / "fold_0" / "checkpoint_final.pth"
    return {
        "unit": unit, "arm": arm, "rep": f"rep{rep:02d}",
        "dataset_id": dataset_id, "dataset": dataset,
        "model_folder": model_folder,
        "checkpoint_final_sha256": sha256(checkpoint),
    }


def verify_pngs(folder: Path, expected: set[str], image_dir: Path,
                *, require_complete: bool) -> tuple[int, str | None]:
    if not folder.exists():
        return 0, None
    if not folder.is_dir():
        raise RuntimeError("A prediction output path is not a directory")
    paths = sorted(folder.glob("*.png"))
    observed = {path.stem for path in paths}
    if len(observed) != len(paths) or not observed <= expected:
        raise RuntimeError("Prediction output contains duplicate or unexpected PNGs")
    if require_complete and observed != expected:
        raise RuntimeError(f"Prediction output incomplete: {len(observed)}/{len(expected)} PNGs")
    if list(folder.glob("*.npz")) or list(folder.glob("*.pkl")):
        raise RuntimeError("Unexpected probability or pickle output found")
    permitted = {"predict_from_raw_data_args.json", "dataset.json", "plans.json"}
    if any(path.name not in permitted and path.suffix.lower() != ".png"
           for path in folder.iterdir()):
        raise RuntimeError("Prediction folder contains an unexpected non-PNG artifact")
    from PIL import Image
    for path in paths:
        image_path = image_dir / f"{path.stem}_0000.png"
        with Image.open(image_path) as image, Image.open(path) as pred:
            if pred.mode != "L" or pred.size != image.size:
                raise RuntimeError("Prediction PNG mode or spatial dimensions differ from input")
            minimum, maximum = pred.getextrema()
            if minimum < 0 or maximum > 1:
                raise RuntimeError("Prediction PNG has labels outside {0,1}")
    return len(paths), inventory(paths) if require_complete else None


def expected_audit(target: dict, stage_sha: str, script_sha: str) -> dict:
    return {
        "schema": SCHEMA,
        "unit": target["unit"],
        "arm": target["arm"],
        "rep": target["rep"],
        "dataset_id": target["dataset_id"],
        "dataset": target["dataset"],
        "manifest_sha256": MANIFEST_SHA256,
        "stage_audit_sha256": stage_sha,
        "checkpoint_final_sha256": target["checkpoint_final_sha256"],
        "cases_expected": EXPECTED_CASES,
        "script_sha256": script_sha,
    }


def verify_existing_audit(audit: dict, expected: dict) -> None:
    wrong = [key for key, value in expected.items() if audit.get(key) != value]
    if wrong:
        raise RuntimeError("Existing prediction audit differs in frozen fields: " + ", ".join(wrong))


def run_cell(base: Path, image_dir: Path, stage_sha: str, expected: set[str],
             target: dict, mode: str | None, cli: Path, script_sha: str) -> None:
    output_root = base / "nnUNet_external_predictions" / target["rep"]
    name = f"{target['unit']}_{target['arm']}"
    output_folder = output_root / name
    audit_path = output_root / "_audit" / f"{name}.json"
    initial = expected_audit(target, stage_sha, script_sha)
    audit = json.loads(audit_path.read_text(encoding="utf-8")) if audit_path.exists() else None
    if audit is not None:
        verify_existing_audit(audit, initial)
    count, inventory_sha = verify_pngs(output_folder, expected, image_dir,
                                       require_complete=bool(audit and audit.get("status") == "PASS"))
    if audit and audit.get("status") == "PASS":
        if (count != EXPECTED_CASES
                or audit.get("predictions_inventory_sha256") != inventory_sha):
            raise RuntimeError("PASS predictions differ from their recorded inventory")
        print(f"PASS {name}: {count} audited external predictions", flush=True)
        return

    state = "missing" if audit is None and not output_folder.exists() else f"partial_{count}"
    if audit is None and output_folder.exists():
        raise RuntimeError("Prediction output exists without an audit; refusing to use or overwrite it")
    print(f"{name}: {state}; checkpoint and external inputs verified", flush=True)
    if mode is None:
        return
    if mode == "write" and state != "missing":
        raise RuntimeError("--write refuses an interrupted prediction; use --resume")
    if mode == "resume" and (state == "missing" or audit.get("status") == "PASS"):
        raise RuntimeError("--resume requires an audited interrupted prediction")
    action = ("write" if state == "missing" else "resume") if mode == "continue" else mode
    if shutil.disk_usage(base).free / 1024**3 < MIN_FREE_GIB:
        raise RuntimeError("Need at least 10 GiB free before external inference")

    command = [str(cli), "-i", str(image_dir), "-o", str(output_folder),
               "-m", str(target["model_folder"]), "-f", "0",
               "-chk", "checkpoint_final.pth", "-device", "cuda",
               "-step_size", "0.5", "-npp", "2", "-nps", "2",
               "--disable_progress_bar"]
    if action == "resume":
        command.append("--continue_prediction")
    env = os.environ.copy()
    env.update({"nnUNet_raw": str(base / "nnUNet_raw"),
                "nnUNet_preprocessed": str(base / "nnUNet_preprocessed"),
                "nnUNet_results": str(base / "nnUNet_results_formal" / target["rep"]),
                "OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1"})
    if audit is None:
        audit = {**initial, "status": "NEW", "created_utc": utc_now(), "attempts": []}
    audit["status"] = "RUNNING"
    attempt = {"mode": action, "started_utc": utc_now(), "command": command,
               "preexisting_predictions": count}
    audit["attempts"].append(attempt)
    write_json(audit_path, audit)
    print(f"PREDICT START {name}: {EXPECTED_CASES} Philips/GE slices", flush=True)
    start = time.monotonic()
    try:
        subprocess.run(command, check=True, env=env)
        final_count, final_inventory = verify_pngs(output_folder, expected, image_dir,
                                                   require_complete=True)
        audit["predictions_inventory_sha256"] = final_inventory
        audit["status"] = "PASS"
        attempt["status"] = "PASS"
        print(f"PREDICT PASS {name}: {final_count} checked PNGs", flush=True)
    except BaseException as exc:
        audit["status"] = "FAILED"
        attempt["status"] = "FAILED"
        attempt["error_type"] = type(exc).__name__
        raise
    finally:
        attempt["finished_utc"] = utc_now()
        attempt["wall_seconds"] = round(time.monotonic() - start, 2)
        write_json(audit_path, audit)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, default=Path("/root/autodl-tmp"))
    parser.add_argument("--rep", type=int, choices=range(3), default=0)
    parser.add_argument("--unit", choices=["all", *[f"u{i:02d}" for i in range(10)]], default="all")
    parser.add_argument("--arm", choices=("both", "B", "Cneg"), default="both")
    modes = parser.add_mutually_exclusive_group()
    modes.add_argument("--write", action="store_true")
    modes.add_argument("--resume", action="store_true")
    modes.add_argument("--continue", dest="continue_run", action="store_true")
    args = parser.parse_args()
    base = args.base.expanduser().resolve()
    venv = base / "nnunet-2.8.1-venv"
    cli = venv / "bin" / "nnUNetv2_predict_from_modelfolder"
    if args.write or args.resume or args.continue_run:
        if Path(sys.prefix).resolve() != venv.resolve() or not cli.is_file():
            raise RuntimeError("Run with the pinned /root/autodl-tmp/nnunet-2.8.1-venv Python")
        if importlib.metadata.version("nnunetv2") != "2.8.1":
            raise RuntimeError("External inference requires nnunetv2==2.8.1")
        import torch
        if not torch.cuda.is_available():
            raise RuntimeError("External inference needs a GPU instance")

    image_dir, stage_sha, expected = verify_stage(base)
    script_sha = sha256(Path(__file__).resolve())
    units = [f"u{i:02d}" for i in range(10)] if args.unit == "all" else [args.unit]
    arms = ("B", "Cneg") if args.arm == "both" else (args.arm,)
    targets = [cell(base, args.rep, unit, arm) for unit in units for arm in arms]
    mode = "write" if args.write else "resume" if args.resume else "continue" if args.continue_run else None

    if mode is None:
        for target in targets:
            run_cell(base, image_dir, stage_sha, expected, target, None, cli, script_sha)
        print(f"PREFLIGHT PASS: {len(targets)} model cell(s); no inference started.")
        return 0

    import fcntl
    lock_root = base / "nnUNet_results_formal"
    lock_root.mkdir(parents=True, exist_ok=True)
    with ExitStack() as stack:
        # Share the formal GPU lock so training and external inference cannot
        # silently run on the same card. The second lock prevents two evaluators.
        for path in (lock_root / ".formal_training.lock",
                     base / ".mnms2_external_prediction.lock"):
            lock = stack.enter_context(path.open("a+"))
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError as exc:
                raise RuntimeError("A formal training or external inference process holds the GPU lock") from exc
        for target in targets:
            run_cell(base, image_dir, stage_sha, expected, target, mode, cli, script_sha)
    print(f"PREDICT BATCH PASS: {len(targets)} audited model cell(s).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
