# Dependencies and environment provenance

## Offline checks

The release verifier uses the Python standard library for inventory/hash checks and in-memory source compilation. The preserved scripts use modern type and path features; Python 3.12 is the documented runtime family. Running synthetic numerical tests additionally requires NumPy. The tests exercise packaged code with synthetic inputs, not patient data or CUDA training.

```bash
cd /absolute/path/to/nnunet_baseline
python tools/verify_release.py
python tools/verify_release.py --self-test
```

Install any missing test dependency before working offline, or use an already provisioned environment. Verification does not install software or contact package registries.

## Workflow dependencies read from the source

| Function | Direct and runtime requirements |
|---|---|
| Original v3 input-audit generation / read-only reconstruction | Python standard library, NumPy, pandas and the included `input_audit_source/mnms2_scope_control_v3_common.py`; no GPU. Current verified reconstruction used Python 3.12.3, NumPy 2.3.5 and pandas 3.0.3. This is not a historical lock. Use the original filenames and `-B --verify-existing` for an existing audit; default mode writes. |
| Manifest preparation and PNG checks | Python standard library; NumPy; Pillow or OpenCV for PNG decoding/writing. The source selects OpenCV when installed and falls back to Pillow; OpenCV is not necessary when Pillow is available. |
| Planning, preprocessing and training | `nnunetv2==2.8.1`, its dependencies, and the nnU-Net CLI entry points. Training requires PyTorch with working CUDA support. The preprocessor explicitly checks `distutils.file_util` and nnU-Net's `DefaultPreprocessor`; on Python 3.12, provide a compatible setuptools-backed distutils implementation. No historical setuptools version was recorded in the selected package snapshot. |
| External inference | The pinned nnU-Net environment, CUDA-capable PyTorch, `nnUNetv2_predict_from_modelfolder`, and Linux `fcntl` locking for writing/resuming runs. |
| Volume scoring and full audit | NumPy, Pillow, NiBabel, and the included local helper modules. These score existing outputs; they do not require retraining. The formal model verification path and checkpoint loading can still require a compatible PyTorch installation. |
| Secondary statistics | NumPy and the Python standard library. Diagnostic summaries also use the included local modules. |

Keep each group of local Python scripts together so sibling imports resolve. The formal launcher imports `preprocess_mnms2_shared_nnunet2d`; prediction imports preparation and formal-summary helpers; full/outlier auditors import the evaluator and diagnostic helper. All of these local dependencies are included.

The original scripts expect their environment at `BASE/nnunet-2.8.1-venv/`, with Unix `bin/python` and CLI paths. The environment name is a path contract, not an environment lock. Writing formal runs checks that the interpreter prefix equals that location and that nnU-Net reports version 2.8.1. Use Linux for actual replay. The shell setup/activation/batch conveniences and probe retain the original AutoDL root; see README for configurable Python entry points.

## Recorded current environment, not a historical lockfile

The following selected package versions were read from the collector interpreter on 20 October 2026. They document that **current** environment only. They do not establish versions used for every historical initial or resumed training attempt and are not a complete `pip freeze` or reproducible dependency lock.

| Component | Collected version |
|---|---|
| Python | 3.12.3 |
| nnunetv2 | 2.8.1 |
| torch | 2.12.1+cu130 |
| dynamic-network-architectures | 0.4.4 |
| numpy | 2.3.5 |
| scipy | 1.18.0 |
| nibabel | 5.4.2 |
| Pillow | 12.2.0 |
| SimpleITK | 2.5.5 |
| scikit-image | 0.26.0 |
| pandas | 3.0.3 |
| matplotlib | 3.11.0 |
| acvl-utils | 0.2.6 |
| batchgenerators | 0.25.3 |
| batchgeneratorsv2 | 0.3.5 |
| tifffile | 2026.9.15 |
| scikit-learn | 1.9.0 |

The retained setup script created its virtual environment using `--system-site-packages` and explicitly installed only `nnunetv2==2.8.1`. Therefore its execution alone would not pin PyTorch, CUDA, every inherited package, or all transitive dependencies. The `+cu130` string identifies the collected PyTorch build; it does not guarantee compatibility with another host's driver or GPU. Provision and record a compatible environment separately before attempting replay. Do not turn this selected list into a claim that a historical lockfile was recovered.

## Reproducibility boundaries

The package verifies preserved source and reviewed public aggregate bytes. Actual training also requires the controlled inputs, private reference fingerprint, fixed splits, appropriate GPU resources, and a compatible dependency stack. A fresh stochastic training run is not expected to regenerate checkpoint bytes identically. `rep00` is not an enforced seed, and the B/Cneg arms are not paired by a controlled random seed. No deterministic GPU replay claim is made.

The unknown spatial-unit declarations are a source-metadata limitation, independent of whether software dependencies install successfully. An environment upgrade, added training repetitions, or a successful test suite does not establish physical mL units. Preserve this distinction when reporting results.
