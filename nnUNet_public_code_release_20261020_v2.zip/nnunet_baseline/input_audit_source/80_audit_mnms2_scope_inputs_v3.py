#!/usr/bin/env python3
"""Zero-GPU partition, label-scope, and physical-input audit for v3.

The script never imports a model, generates a prediction, or reads an outcome
from an external cohort. It deterministically creates the single allowed
disease-stratified partition and content-hashes every later input file.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import defaultdict
from pathlib import Path
from typing import Any

import pandas as pd

from mnms2_scope_control_v3_common import (
    ARMS,
    PROTOCOL_ID,
    atomic_csv,
    atomic_json,
    build_label_scope,
    deterministic_partition,
    load_config,
    norm_key,
    partition_block_hash,
    sha256_file,
    sha256_keys,
    vendor_mask,
)


OUTPUT_NAMES = (
    "patient_partitions_v3.csv",
    "partition_disease_summary_v3.csv",
    "label_scope_audit_v3.csv",
    "input_uses_v3.csv",
    "input_file_manifest_v3.csv",
    "input_audit_summary_v3.json",
)


def dataframe_sha256(frame: pd.DataFrame) -> str:
    payload = frame.to_csv(index=False, lineterminator="\n").encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def normalize_manifest(frame: pd.DataFrame) -> pd.DataFrame:
    required = {
        "key",
        "phase",
        "z",
        "vendor",
        "disease",
        "is_anchor",
        "in_lvspan",
        "img",
        "gt",
        "gt_px",
        "pf",
    }
    missing = sorted(required - set(frame.columns))
    if missing:
        raise RuntimeError(f"manifest_mnms2.csv is missing columns: {missing}")
    frame = frame.copy()
    frame["key"] = frame["key"].map(norm_key)
    frame["pf"] = frame["pf"].fillna("")
    frame["gt"] = frame["gt"].astype(str)
    frame["img"] = frame["img"].astype(str)
    frame["phase"] = frame["phase"].astype(str).str.lower()
    return frame


def partition_summary(partition: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for (role, block_id, disease), group in partition.groupby(
        ["role", "block_id", "disease"], dropna=False, sort=True
    ):
        rows.append(
            {
                "role": str(role),
                "block_id": "" if pd.isna(block_id) else str(block_id),
                "disease": str(disease),
                "patients": int(len(group)),
                "key_sha256": sha256_keys(group["key"].astype(str)),
            }
        )
    return pd.DataFrame(rows).sort_values(
        ["role", "block_id", "disease"], kind="stable"
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--config",
        type=Path,
        default=Path(__file__).with_name("mnms2_scope_control_config_v3.json"),
    )
    parser.add_argument(
        "--mroot", type=Path, default=Path("/root/autodl-tmp/mnms/seg_lv")
    )
    parser.add_argument(
        "--root", type=Path, default=Path("/root/autodl-tmp/mnms/MnM2")
    )
    parser.add_argument(
        "--out-dir",
        type=Path,
        default=Path(
            "/root/autodl-tmp/mnms/seg_lv/scope_control_v3_zero_gpu_audit"
        ),
    )
    parser.add_argument(
        "--verify-existing",
        action="store_true",
        help="Recompute and compare; never overwrite the one-time audit.",
    )
    args = parser.parse_args()
    config = load_config(args.config)
    data_config = config["data"]
    manifest_path = args.mroot / "manifest_mnms2.csv"
    split_root = args.mroot / "all"
    if not manifest_path.is_file():
        raise FileNotFoundError(manifest_path)
    manifest_sha = sha256_file(manifest_path)
    if manifest_sha != data_config["manifest_sha256"]:
        raise RuntimeError(
            f"manifest_mnms2.csv SHA256 mismatch: {manifest_sha}"
        )
    frame = normalize_manifest(pd.read_csv(manifest_path))
    partition = deterministic_partition(frame, config)
    validation_keys = sorted(
        partition.loc[partition["role"] == "validation", "key"].astype(str)
    )
    if sha256_keys(validation_keys) != data_config["validation_key_sha256"]:
        raise RuntimeError("Historical 43-patient validation cohort changed")

    failures: list[str] = []
    if frame.duplicated(["vendor", "key", "phase", "z"]).any():
        failures.append("manifest contains duplicate vendor/key/phase/z rows")
    gt_pixels = pd.to_numeric(frame["gt_px"], errors="coerce")
    if gt_pixels.isna().any() or (gt_pixels < 0).any():
        failures.append("manifest gt_px contains missing, nonnumeric, or negative values")

    def audit_phase_coverage(cohort: pd.DataFrame, cohort_name: str) -> None:
        bad = [
            str(key)
            for key, group in cohort.groupby("key", sort=True)
            if set(group["phase"].astype(str)) != {"ed", "es"}
        ]
        if bad:
            failures.append(
                f"{cohort_name} has {len(bad)} patients without exactly ED/ES phases: "
                f"{bad[:10]}"
            )

    blocks = [
        str(data_config["development_block"]),
        *map(str, data_config["formal_units"]),
    ]
    physical_roles: dict[Path, set[str]] = defaultdict(set)
    uses: list[dict[str, Any]] = []
    scope_rows: list[dict[str, Any]] = []

    def add_file(path: Path, role: str) -> None:
        physical_roles[path].add(role)

    add_file(manifest_path, "manifest")

    siemens = frame[vendor_mask(frame, "SIEMENS")].copy()
    audit_phase_coverage(siemens, "SIEMENS full cohort")
    validation = siemens[siemens["key"].isin(validation_keys)].copy()
    audit_phase_coverage(validation, "SIEMENS validation")
    for _, row in validation.iterrows():
        add_file(split_root / str(row["img"]), "validation:image")
        add_file(split_root / str(row["gt"]), "validation:gt")
        uses.append(
            {
                "role": "validation",
                "block_id": "",
                "arm": "both",
                "domain": "SIEMENS",
                "key": str(row["key"]),
                "phase": str(row["phase"]),
                "z": int(row["z"]),
                "img": str(row["img"]),
                "label_kind": "gt",
                "label": str(row["gt"]),
            }
        )
    for key in validation_keys:
        for phase in ("ED", "ES"):
            add_file(
                args.root
                / "dataset"
                / str(key)
                / f"{key}_SA_{phase}_gt.nii.gz",
                f"validation:volume_gt:{phase.lower()}",
            )

    for block in blocks:
        keys = sorted(
            partition.loc[partition["block_id"] == block, "key"].astype(str)
        )
        if len(keys) != 10:
            failures.append(f"{block} has {len(keys)} patients instead of 10")
            continue
        train = siemens[siemens["key"].isin(keys)].copy()
        for arm in ARMS:
            pairs, scope = build_label_scope(train, arm)
            internal = sum(
                int(record["is_anchor"]) == 0
                and int(record["in_lvspan"]) == 1
                for record in scope
            )
            pf_rows = sum(record["label_kind"] == "pf" for record in scope)
            gt_rows = sum(record["label_kind"] == "gt" for record in scope)
            if arm == "Cneg" and internal:
                failures.append(
                    f"{block} Cneg includes {internal} internal non-anchor rows"
                )
            if arm == "B" and pf_rows != internal:
                failures.append(
                    f"{block} B internal/PF row mismatch: {internal}/{pf_rows}"
                )
            scope_rows.append(
                {
                    "block_id": block,
                    "role": (
                        "development"
                        if block == data_config["development_block"]
                        else "formal"
                    ),
                    "arm": arm,
                    "train_patients": len(keys),
                    "label_rows": len(pairs),
                    "gt_rows": gt_rows,
                    "pf_rows": pf_rows,
                    "internal_nonanchor_rows": internal,
                    "block_key_sha256": partition_block_hash(partition, block),
                }
            )
            for record in scope:
                image_path = split_root / record["img"]
                label_path = split_root / record["label"]
                add_file(image_path, f"{block}:{arm}:image")
                add_file(
                    label_path,
                    f"{block}:{arm}:label:{record['label_kind']}",
                )
                uses.append(
                    {
                        "role": "training",
                        "block_id": block,
                        "arm": arm,
                        "domain": "SIEMENS",
                        "key": record["key"],
                        "phase": record["phase"],
                        "z": record["z"],
                        "img": record["img"],
                        "label_kind": record["label_kind"],
                        "label": record["label"],
                    }
                )

    external_specs = (("Philips", "Philips"), ("GE MEDICAL", "GE"))
    external_counts: dict[str, int] = {}
    for vendor_query, domain_name in external_specs:
        domain = frame[vendor_mask(frame, vendor_query)].copy()
        count = int(domain["key"].nunique())
        audit_phase_coverage(domain, domain_name)
        external_counts[domain_name] = count
        expected = int(data_config["expected_external_patients"][domain_name])
        if count != expected:
            failures.append(
                f"{domain_name} patient count {count} differs from {expected}"
            )
        for _, row in domain.iterrows():
            add_file(split_root / str(row["img"]), f"external_{domain_name}:image")
            add_file(split_root / str(row["gt"]), f"external_{domain_name}:gt")
            uses.append(
                {
                    "role": "external_locked",
                    "block_id": "",
                    "arm": "both",
                    "domain": domain_name,
                    "key": str(row["key"]),
                    "phase": str(row["phase"]),
                    "z": int(row["z"]),
                    "img": str(row["img"]),
                    "label_kind": "gt",
                    "label": str(row["gt"]),
                }
            )
        for key in sorted(domain["key"].unique()):
            for phase in ("ED", "ES"):
                add_file(
                    args.root
                    / "dataset"
                    / str(key)
                    / f"{key}_SA_{phase}_gt.nii.gz",
                    f"external_{domain_name}:volume_gt:{phase.lower()}",
                )

    physical_rows: list[dict[str, Any]] = []
    for path in sorted(physical_roles, key=lambda item: str(item)):
        exists = path.is_file()
        if not exists:
            failures.append(f"missing input: {path}")
        physical_rows.append(
            {
                "absolute_path": str(path),
                "roles": "|".join(sorted(physical_roles[path])),
                "exists": exists,
                "size_bytes": path.stat().st_size if exists else None,
                "sha256": sha256_file(path) if exists else None,
            }
        )

    partition = partition[["key", "disease", "role", "block_id"]].copy()
    disease_summary = partition_summary(partition)
    label_scope = pd.DataFrame(scope_rows).sort_values(
        ["role", "block_id", "arm"], kind="stable"
    )
    input_uses = pd.DataFrame(uses).sort_values(
        ["role", "block_id", "arm", "domain", "key", "phase", "z"],
        kind="stable",
    )
    input_files = pd.DataFrame(physical_rows).sort_values(
        "absolute_path", kind="stable"
    )
    frames = {
        "patient_partitions_v3.csv": partition,
        "partition_disease_summary_v3.csv": disease_summary,
        "label_scope_audit_v3.csv": label_scope,
        "input_uses_v3.csv": input_uses,
        "input_file_manifest_v3.csv": input_files,
    }
    output_hashes = {
        name: {
            "sha256": dataframe_sha256(output),
            "rows": int(len(output)),
        }
        for name, output in frames.items()
    }
    summary = {
        "protocol_id": PROTOCOL_ID,
        "status": "PASS" if not failures else "FAIL",
        "failures": failures,
        "config": str(args.config.resolve()),
        "config_sha256": sha256_file(args.config),
        "manifest": str(manifest_path.resolve()),
        "manifest_sha256": manifest_sha,
        "partition_seed": int(data_config["partition_seed"]),
        "siemens_total_patients": int(partition["key"].nunique()),
        "validation_patients": int((partition["role"] == "validation").sum()),
        "development_patients": int((partition["role"] == "development").sum()),
        "formal_patients": int((partition["role"] == "formal").sum()),
        "unused_patients": int((partition["role"] == "unused").sum()),
        "validation_key_sha256": sha256_keys(validation_keys),
        "block_key_sha256": {
            block: partition_block_hash(partition, block) for block in blocks
        },
        "external_patient_counts": external_counts,
        "unique_physical_files": int(len(input_files)),
        "outputs": output_hashes,
    }

    existing = [args.out_dir / name for name in OUTPUT_NAMES if (args.out_dir / name).exists()]
    if args.verify_existing:
        missing = [args.out_dir / name for name in OUTPUT_NAMES if not (args.out_dir / name).is_file()]
        if missing:
            raise RuntimeError(f"Cannot verify incomplete existing audit: {missing}")
        mismatches: list[str] = []
        for name, output in frames.items():
            if sha256_file(args.out_dir / name) != dataframe_sha256(output):
                mismatches.append(name)
        old_summary_path = args.out_dir / "input_audit_summary_v3.json"
        old_summary = json.loads(old_summary_path.read_text(encoding="utf-8"))
        comparable_fields = (
            "protocol_id",
            "status",
            "manifest_sha256",
            "partition_seed",
            "siemens_total_patients",
            "validation_patients",
            "development_patients",
            "formal_patients",
            "unused_patients",
            "validation_key_sha256",
            "block_key_sha256",
            "external_patient_counts",
            "unique_physical_files",
            "outputs",
            "failures",
        )
        if any(old_summary.get(field) != summary.get(field) for field in comparable_fields):
            mismatches.append("input_audit_summary_v3.json")
        if mismatches:
            raise RuntimeError(f"Existing one-time audit changed: {mismatches}")
        print(
            json.dumps(
                {
                    "status": "PASS_VERIFIED_EXISTING",
                    "audit_summary": str(old_summary_path.resolve()),
                    "audit_summary_sha256": sha256_file(old_summary_path),
                },
                indent=2,
                sort_keys=True,
            )
        )
        return

    if existing:
        raise RuntimeError(
            "One-time audit outputs already exist; use --verify-existing, never redraw"
        )
    args.out_dir.mkdir(parents=True, exist_ok=True)
    for name, output in frames.items():
        atomic_csv(output, args.out_dir / name)
    summary_path = args.out_dir / "input_audit_summary_v3.json"
    atomic_json(summary, summary_path)
    print(
        json.dumps(
            {
                **summary,
                "audit_summary": str(summary_path.resolve()),
                "audit_summary_sha256": sha256_file(summary_path),
            },
            indent=2,
            sort_keys=True,
        )
    )
    if failures:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
