#!/usr/bin/env python3
"""Shared, outcome-blind utilities for M&Ms-2 scope-control v3.

This module contains deterministic partitioning, label-scope, hashing, receipt,
and recipe-selection logic. It does not train a model or evaluate an external
endpoint.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
import random
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd


PROTOCOL_ID = "MNMS2_SCOPE_CONTROL_V3_UNIT_PAIRED_N10"
ARMS = ("B", "Cneg")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def sha256_keys(keys: Iterable[str]) -> str:
    return sha256_text(",".join(sorted(str(key) for key in keys)))


def sha256_records(records: list[dict[str, Any]]) -> str:
    payload = json.dumps(
        records, sort_keys=True, separators=(",", ":"), ensure_ascii=False
    )
    return sha256_text(payload)


def norm_key(value: object) -> str:
    text = str(value).strip()
    try:
        return str(int(float(text))).zfill(3)
    except ValueError:
        return text


def atomic_json(data: dict[str, Any], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    os.replace(temporary, path)


def atomic_csv(frame: pd.DataFrame, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    frame.to_csv(temporary, index=False, lineterminator="\n")
    os.replace(temporary, path)


def load_config(path: Path) -> dict[str, Any]:
    config = json.loads(path.read_text(encoding="utf-8"))
    if config.get("protocol_id") != PROTOCOL_ID:
        raise RuntimeError(f"Configuration protocol mismatch: {path}")
    return config


def vendor_mask(frame: pd.DataFrame, name: str) -> pd.Series:
    return (
        frame["vendor"].astype(str).str.lower().str.contains(name.lower().strip())
    )


def _patient_disease(frame: pd.DataFrame, keys: Iterable[str]) -> dict[str, str]:
    requested = set(keys)
    result: dict[str, str] = {}
    subset = frame[frame["key"].isin(requested)]
    for key, group in subset.groupby("key", sort=True):
        values = {
            str(value).strip()
            for value in group["disease"]
            if str(value).strip() and str(value).strip().lower() != "nan"
        }
        if len(values) != 1:
            raise RuntimeError(
                f"Patient {key} must have exactly one nonmissing disease; got {sorted(values)}"
            )
        result[str(key)] = next(iter(values))
    missing = sorted(requested - set(result))
    if missing:
        raise RuntimeError(f"Disease metadata missing for patient keys: {missing[:10]}")
    return result


def legacy_validation_and_pool(
    frame: pd.DataFrame, config: dict[str, Any]
) -> tuple[list[str], list[str], pd.DataFrame]:
    data = config["data"]
    siemens = frame[vendor_mask(frame, "SIEMENS")].copy()
    keys = sorted(siemens["key"].unique())
    expected_total = int(data["expected_siemens_total"])
    if len(keys) != expected_total:
        raise RuntimeError(
            f"SIEMENS patient count {len(keys)} differs from {expected_total}"
        )
    rng = random.Random(int(data["partition_seed"]))
    rng.shuffle(keys)
    n_val = int(data["validation_patients"])
    validation = sorted(keys[:n_val])
    pool = list(keys[n_val:])
    if len(pool) != int(data["expected_train_pool"]):
        raise RuntimeError("Training-pool count differs from the frozen configuration")
    return validation, pool, siemens


def largest_remainder_apportionment(
    counts: dict[str, int], target: int
) -> dict[str, int]:
    total = sum(counts.values())
    if target < 0 or target > total:
        raise ValueError("Target must be between zero and the available total")
    quotas = {name: target * count / total for name, count in counts.items()}
    allocated = {name: int(math.floor(value)) for name, value in quotas.items()}
    remaining = target - sum(allocated.values())
    order = sorted(
        counts,
        key=lambda name: (-(quotas[name] - allocated[name]), str(name)),
    )
    for name in order[:remaining]:
        allocated[name] += 1
    if sum(allocated.values()) != target:
        raise AssertionError("Largest-remainder allocation did not close")
    if any(allocated[name] > counts[name] for name in counts):
        raise AssertionError("Allocation exceeds an available disease stratum")
    return allocated


def deterministic_partition(
    frame: pd.DataFrame, config: dict[str, Any]
) -> pd.DataFrame:
    """Return one immutable validation/development/formal/unused assignment."""
    data = config["data"]
    validation, pool, _ = legacy_validation_and_pool(frame, config)
    all_siemens = validation + pool
    disease_by_key = _patient_disease(frame, all_siemens)
    counts = Counter(disease_by_key[key] for key in pool)
    target = int(data["selected_training_patients"])
    selected_by_disease = largest_remainder_apportionment(dict(counts), target)
    blocks = [str(data["development_block"]), *map(str, data["formal_units"])]
    if len(blocks) != 11 or len(set(blocks)) != 11:
        raise RuntimeError("Frozen design requires one development and ten formal blocks")
    block_keys: dict[str, list[str]] = {block: [] for block in blocks}
    seed = int(data["partition_seed"])

    ordered_by_disease: dict[str, list[str]] = {}
    for disease in sorted(counts):
        keys = [key for key in pool if disease_by_key[key] == disease]
        ordered_by_disease[disease] = sorted(
            keys,
            key=lambda key: (
                sha256_text(f"{seed}|{disease}|{key}"),
                key,
            ),
        )

    current_load = [0] * len(blocks)
    selected_keys: set[str] = set()
    for disease in sorted(selected_by_disease):
        count = selected_by_disease[disease]
        quotient, remainder = divmod(count, len(blocks))
        ordered = ordered_by_disease[disease]
        cursor = 0
        for index, block in enumerate(blocks):
            assigned = ordered[cursor : cursor + quotient]
            block_keys[block].extend(assigned)
            selected_keys.update(assigned)
            current_load[index] += len(assigned)
            cursor += quotient

        offset = int(sha256_text(f"{seed}|{disease}")[:16], 16) % len(blocks)
        priority = sorted(
            range(len(blocks)),
            key=lambda index: (
                current_load[index],
                (index - offset) % len(blocks),
                index,
            ),
        )
        for index in priority[:remainder]:
            key = ordered[cursor]
            cursor += 1
            block_keys[blocks[index]].append(key)
            selected_keys.add(key)
            current_load[index] += 1
        if cursor != count:
            raise AssertionError(f"Disease allocation did not close for {disease}")

    expected_block_size = target // len(blocks)
    if target % len(blocks) != 0:
        raise RuntimeError("Selected total is not divisible by the number of blocks")
    observed_sizes = {block: len(keys) for block, keys in block_keys.items()}
    if set(observed_sizes.values()) != {expected_block_size}:
        raise RuntimeError(f"Deterministic stratification did not yield equal blocks: {observed_sizes}")

    pool_set = set(pool)
    if len(selected_keys) != target:
        raise AssertionError("Selected-key count mismatch")
    unused = sorted(pool_set - selected_keys)
    if len(unused) != int(data["expected_unused"]):
        raise RuntimeError("Explicit unused-key count differs from the frozen value")

    rows: list[dict[str, Any]] = []
    for key in sorted(validation):
        rows.append(
            {
                "key": key,
                "disease": disease_by_key[key],
                "role": "validation",
                "block_id": "",
            }
        )
    for block in blocks:
        role = "development" if block == data["development_block"] else "formal"
        for key in sorted(block_keys[block]):
            rows.append(
                {
                    "key": key,
                    "disease": disease_by_key[key],
                    "role": role,
                    "block_id": block,
                }
            )
    for key in unused:
        rows.append(
            {
                "key": key,
                "disease": disease_by_key[key],
                "role": "unused",
                "block_id": "",
            }
        )
    result = pd.DataFrame(rows)
    if result["key"].nunique() != int(data["expected_siemens_total"]):
        raise AssertionError("Partition does not cover each SIEMENS patient exactly once")
    if result.duplicated("key").any():
        raise AssertionError("Partition contains duplicate patient keys")
    role_order = pd.Categorical(
        result["role"],
        categories=["validation", "development", "formal", "unused"],
        ordered=True,
    )
    result = (
        result.assign(_role_order=role_order)
        .sort_values(["_role_order", "block_id", "disease", "key"], kind="stable")
        .drop(columns="_role_order")
        .reset_index(drop=True)
    )
    return result


def partition_block_hash(partition: pd.DataFrame, block_id: str) -> str:
    keys = partition.loc[partition["block_id"] == block_id, "key"].astype(str)
    return sha256_keys(keys)


def label_for_arm(row: pd.Series, arm: str) -> tuple[str, str] | None:
    anchor_or_outside = int(row["is_anchor"]) == 1 or int(row["in_lvspan"]) == 0
    if arm == "B":
        if anchor_or_outside:
            return "gt", str(row["gt"])
        pseudo = str(row.get("pf", "") or "").strip()
        if not pseudo or pseudo.lower() == "nan":
            raise RuntimeError("B forbids PF-to-GT fallback on span-internal rows")
        return "pf", pseudo
    if arm == "Cneg":
        return ("gt", str(row["gt"])) if anchor_or_outside else None
    raise ValueError(f"Unsupported arm: {arm}")


def build_label_scope(frame: pd.DataFrame, arm: str) -> tuple[list[tuple[str, str]], list[dict[str, Any]]]:
    pairs: list[tuple[str, str]] = []
    records: list[dict[str, Any]] = []
    for _, row in frame.iterrows():
        decision = label_for_arm(row, arm)
        if decision is None:
            continue
        kind, label = decision
        pairs.append((str(row["img"]), label))
        records.append(
            {
                "key": str(row["key"]),
                "phase": str(row["phase"]),
                "z": int(row["z"]),
                "img": str(row["img"]),
                "label_kind": kind,
                "label": label,
                "is_anchor": int(row["is_anchor"]),
                "in_lvspan": int(row["in_lvspan"]),
            }
        )
    return pairs, records


def sample_sd(values: Iterable[float], ddof: int = 1) -> float:
    array = np.asarray(list(values), dtype=float)
    if len(array) <= ddof or not np.isfinite(array).all():
        return float("nan")
    return float(np.std(array, ddof=ddof))


def _run_normal_technical_pass(run: dict[str, Any], dice_floor: float) -> tuple[bool, list[str]]:
    reasons: list[str] = []
    if run.get("status") != "COMPLETED":
        reasons.append(f"status={run.get('status')}")
    if not bool(run.get("all_training_losses_finite", False)):
        reasons.append("nonfinite_training_loss")
    if not bool(run.get("all_validation_outputs_finite", False)):
        reasons.append("nonfinite_validation_output")
    if not bool(run.get("checkpoint_reload_match", False)):
        reasons.append("checkpoint_reload_mismatch")
    best_dice = float(run.get("best_val_dice", float("nan")))
    if not math.isfinite(best_dice) or best_dice < dice_floor:
        reasons.append("dice_below_technical_floor")
    if bool(run.get("degenerate_patient_phase", True)):
        reasons.append("degenerate_patient_phase")
    if bool(run.get("hit_step_cap", True)):
        reasons.append("hit_step_cap")
    return not reasons, reasons


def _run_fallback_eligible(run: dict[str, Any], dice_floor: float) -> tuple[bool, list[str]]:
    passed, reasons = _run_normal_technical_pass(run, dice_floor)
    reasons = [reason for reason in reasons if reason != "hit_step_cap"]
    bias = float(run.get("validation_ef_bias", float("nan")))
    if not math.isfinite(bias):
        reasons.append("nonfinite_validation_ef_bias")
    return not reasons, reasons


def select_recipe(
    run_records: list[dict[str, Any]], config: dict[str, Any]
) -> dict[str, Any]:
    """Apply the frozen first-passing/fallback rule to dev run summaries."""
    development = config["development"]
    seeds = tuple(int(seed) for seed in development["seeds"])
    candidates = sorted(development["candidates"], key=lambda item: int(item["order"]))
    dice_floor = float(development["dice_floor"])
    threshold = float(development["ef_bias_sample_sd_threshold"])
    ddof = int(development["ef_bias_sample_sd_ddof"])
    expected_per_candidate = {(arm, seed) for arm in ARMS for seed in seeds}

    grouped: dict[str, dict[tuple[str, int], dict[str, Any]]] = defaultdict(dict)
    for run in run_records:
        candidate = str(run["recipe_id"])
        identity = (str(run["arm"]), int(run["seed"]))
        if identity in grouped[candidate]:
            raise RuntimeError(f"Duplicate development run: {candidate} {identity}")
        grouped[candidate][identity] = run

    candidate_reports: list[dict[str, Any]] = []
    first_incomplete: str | None = None
    selected: dict[str, Any] | None = None
    for candidate in candidates:
        recipe_id = str(candidate["recipe_id"])
        runs = grouped.get(recipe_id, {})
        identities = set(runs)
        unexpected = identities - expected_per_candidate
        if unexpected:
            raise RuntimeError(f"Unexpected dev cells for {recipe_id}: {sorted(unexpected)}")
        complete = identities == expected_per_candidate
        if not complete:
            first_incomplete = recipe_id
            candidate_reports.append(
                {
                    "recipe_id": recipe_id,
                    "learning_rate": float(candidate["learning_rate"]),
                    "complete": False,
                    "missing_cells": sorted(
                        f"{arm}:s{seed}" for arm, seed in expected_per_candidate - identities
                    ),
                }
            )
            break
        nonterminal = {
            f"{arm}:s{seed}": str(runs[(arm, seed)].get("status"))
            for arm, seed in sorted(expected_per_candidate)
            if str(runs[(arm, seed)].get("status"))
            not in {"COMPLETED", "COMPLETED_TECHNICAL_FAILURE"}
        }
        if nonterminal:
            first_incomplete = recipe_id
            candidate_reports.append(
                {
                    "recipe_id": recipe_id,
                    "learning_rate": float(candidate["learning_rate"]),
                    "complete": False,
                    "nonterminal_cells": nonterminal,
                }
            )
            break

        report: dict[str, Any] = {
            "recipe_id": recipe_id,
            "learning_rate": float(candidate["learning_rate"]),
            "complete": True,
            "arms": {},
        }
        candidate_pass = True
        candidate_fallback_eligible = True
        for arm in ARMS:
            arm_runs = [runs[(arm, seed)] for seed in seeds]
            biases = [float(run.get("validation_ef_bias", float("nan"))) for run in arm_runs]
            sd = sample_sd(biases, ddof)
            failures: dict[str, list[str]] = {}
            fallback_failures: dict[str, list[str]] = {}
            for seed, run in zip(seeds, arm_runs):
                normal_ok, normal_reasons = _run_normal_technical_pass(run, dice_floor)
                fallback_ok, fallback_reasons = _run_fallback_eligible(run, dice_floor)
                if not normal_ok:
                    failures[str(seed)] = normal_reasons
                if not fallback_ok:
                    fallback_failures[str(seed)] = fallback_reasons
            arm_pass = (
                math.isfinite(sd)
                and sd < threshold
                and not failures
            )
            arm_fallback = math.isfinite(sd) and not fallback_failures
            candidate_pass = candidate_pass and arm_pass
            candidate_fallback_eligible = candidate_fallback_eligible and arm_fallback
            report["arms"][arm] = {
                "biases_by_seed": {
                    str(seed): bias for seed, bias in zip(seeds, biases)
                },
                "sample_sd_ddof1": sd,
                "sd_below_threshold": bool(math.isfinite(sd) and sd < threshold),
                "normal_gate_failures_by_seed": failures,
                "fallback_failures_by_seed": fallback_failures,
                "normal_pass": arm_pass,
                "fallback_eligible": arm_fallback,
            }
        report["normal_pass"] = candidate_pass
        report["fallback_eligible"] = candidate_fallback_eligible
        report["worst_arm_sample_sd"] = max(
            float(report["arms"][arm]["sample_sd_ddof1"]) for arm in ARMS
        )
        candidate_reports.append(report)
        if candidate_pass:
            selected = {
                "selection_status": "PASS",
                "selected_recipe_id": recipe_id,
                "selected_learning_rate": float(candidate["learning_rate"]),
                "selected_candidate_order": int(candidate["order"]),
                "failed_gate": False,
            }
            break

    if selected is not None:
        selected_index = int(selected["selected_candidate_order"])
        later_ids = {
            str(candidate["recipe_id"])
            for candidate in candidates
            if int(candidate["order"]) > selected_index
        }
        if any(grouped.get(recipe_id) for recipe_id in later_ids):
            raise RuntimeError("A later candidate was run after the first passing candidate")
        return {**selected, "candidate_reports": candidate_reports}

    if first_incomplete is not None:
        first_order = next(
            int(item["order"])
            for item in candidates
            if str(item["recipe_id"]) == first_incomplete
        )
        later_ids = {
            str(item["recipe_id"])
            for item in candidates
            if int(item["order"]) > first_order
        }
        if any(grouped.get(recipe_id) for recipe_id in later_ids):
            raise RuntimeError("Candidate order violation: a later recipe has outcomes")
        return {
            "selection_status": "CONTINUE",
            "next_recipe_id": first_incomplete,
            "candidate_reports": candidate_reports,
        }

    eligible = [
        report
        for report in candidate_reports
        if bool(report.get("fallback_eligible", False))
    ]
    if not eligible:
        return {
            "selection_status": "STOP_NO_TECHNICALLY_ELIGIBLE_CANDIDATE",
            "candidate_reports": candidate_reports,
        }
    order_by_id = {
        str(item["recipe_id"]): int(item["order"]) for item in candidates
    }
    fallback = min(
        eligible,
        key=lambda report: (
            float(report["worst_arm_sample_sd"]),
            order_by_id[str(report["recipe_id"])],
        ),
    )
    return {
        "selection_status": "FALLBACK_FAILED_GATE",
        "selected_recipe_id": str(fallback["recipe_id"]),
        "selected_learning_rate": float(fallback["learning_rate"]),
        "selected_candidate_order": order_by_id[str(fallback["recipe_id"])],
        "failed_gate": True,
        "candidate_reports": candidate_reports,
    }


def verify_receipt(
    receipt_path: Path,
    config_path: Path,
    required_files: Iterable[Path],
    audit_dir: Path | None = None,
) -> dict[str, Any]:
    if not receipt_path.is_file():
        raise FileNotFoundError(receipt_path)
    receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
    if receipt.get("protocol_id") != PROTOCOL_ID or receipt.get("status") != "FROZEN":
        raise RuntimeError("Freeze receipt is absent or not FROZEN")
    declared = receipt.get("files", {})
    paths = [config_path, *required_files]
    for path in paths:
        actual = sha256_file(path)
        if declared.get(path.name) != actual:
            raise RuntimeError(f"Freeze receipt hash mismatch for {path.name}")
    if audit_dir is not None:
        summary_path = audit_dir / "input_audit_summary_v3.json"
        if not summary_path.is_file():
            raise FileNotFoundError(summary_path)
        summary = json.loads(summary_path.read_text(encoding="utf-8"))
        if summary.get("status") != "PASS":
            raise RuntimeError("v3 input audit is not PASS")
        if receipt.get("audit_summary_sha256") != sha256_file(summary_path):
            raise RuntimeError("Freeze receipt audit-summary hash mismatch")
        for name, expected in receipt.get("audit_files", {}).items():
            path = audit_dir / name
            if not path.is_file() or sha256_file(path) != expected:
                raise RuntimeError(f"Frozen audit artifact changed: {path}")
    return receipt


def load_partition(audit_dir: Path) -> pd.DataFrame:
    path = audit_dir / "patient_partitions_v3.csv"
    summary_path = audit_dir / "input_audit_summary_v3.json"
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    declared = summary.get("outputs", {}).get(path.name, {}).get("sha256")
    if declared != sha256_file(path):
        raise RuntimeError("Patient-partition hash differs from the audit summary")
    frame = pd.read_csv(path, dtype={"key": str, "block_id": str})
    frame["key"] = frame["key"].map(norm_key)
    frame["block_id"] = frame["block_id"].fillna("")
    return frame


def candidate_by_id(config: dict[str, Any], recipe_id: str) -> dict[str, Any]:
    matches = [
        item
        for item in config["development"]["candidates"]
        if str(item["recipe_id"]) == recipe_id
    ]
    if len(matches) != 1:
        raise KeyError(f"Unknown recipe: {recipe_id}")
    return matches[0]


def development_manifest_path(
    development_root: Path, recipe_id: str, seed: int, arm: str
) -> Path:
    return (
        development_root
        / "run_manifests"
        / f"{recipe_id}_s{seed}_{arm}.json"
    )


def collect_development_records(
    development_root: Path,
    matrix_path: Path,
    config: dict[str, Any],
    freeze_receipt_sha256: str | None = None,
) -> tuple[list[dict[str, Any]], dict[str, str]]:
    matrix = pd.read_csv(matrix_path)
    expected = {
        (str(candidate["recipe_id"]), int(seed), arm)
        for candidate in config["development"]["candidates"]
        for seed in config["development"]["seeds"]
        for arm in ARMS
    }
    observed = {
        (str(row.recipe_id), int(row.seed), str(row.arm))
        for row in matrix.itertuples()
    }
    if len(matrix) != 30 or observed != expected:
        raise RuntimeError("Development matrix differs from the frozen 30-cell maximum")
    records: list[dict[str, Any]] = []
    manifest_hashes: dict[str, str] = {}
    for recipe_id, seed, arm in sorted(
        expected,
        key=lambda item: (
            int(candidate_by_id(config, item[0])["order"]),
            item[1],
            item[2],
        ),
    ):
        path = development_manifest_path(
            development_root, recipe_id, seed, arm
        )
        if not path.is_file():
            continue
        run = json.loads(path.read_text(encoding="utf-8"))
        if run.get("protocol_id") != PROTOCOL_ID:
            raise RuntimeError(f"Development manifest protocol mismatch: {path}")
        cell = run.get("cell", {})
        identity = (
            str(cell.get("recipe_id")),
            int(cell.get("seed", -1)),
            str(cell.get("arm")),
        )
        if identity != (recipe_id, seed, arm):
            raise RuntimeError(f"Development manifest cell mismatch: {path}")
        if (
            freeze_receipt_sha256 is not None
            and run.get("freeze_receipt_sha256") != freeze_receipt_sha256
        ):
            raise RuntimeError(f"Development manifest receipt mismatch: {path}")
        run = dict(run)
        run["recipe_id"] = recipe_id
        run["seed"] = seed
        run["arm"] = arm
        run["_manifest_path"] = str(path.resolve())
        run["_manifest_sha256"] = sha256_file(path)
        records.append(run)
        manifest_hashes[path.name] = sha256_file(path)
    return records, manifest_hashes


def verify_selected_recipe_artifact(
    selected_path: Path,
    development_root: Path,
    development_matrix: Path,
    config: dict[str, Any],
    freeze_receipt_sha256: str,
) -> tuple[dict[str, Any], dict[str, Any]]:
    artifact = json.loads(selected_path.read_text(encoding="utf-8"))
    if artifact.get("protocol_id") != PROTOCOL_ID:
        raise RuntimeError("Selected-recipe artifact protocol mismatch")
    if artifact.get("freeze_receipt_sha256") != freeze_receipt_sha256:
        raise RuntimeError("Selected-recipe artifact receipt mismatch")
    records, hashes = collect_development_records(
        development_root,
        development_matrix,
        config,
        freeze_receipt_sha256,
    )
    recomputed = select_recipe(records, config)
    allowed = {"PASS", "FALLBACK_FAILED_GATE"}
    if recomputed.get("selection_status") not in allowed:
        raise RuntimeError(
            f"Development is not terminally selectable: {recomputed.get('selection_status')}"
        )
    fields = (
        "selection_status",
        "selected_recipe_id",
        "selected_learning_rate",
        "selected_candidate_order",
        "failed_gate",
    )
    for field in fields:
        if artifact.get(field) != recomputed.get(field):
            raise RuntimeError(f"Selected-recipe artifact differs at {field}")
    if artifact.get("development_manifest_sha256") != hashes:
        raise RuntimeError("Selected-recipe artifact manifest-hash map changed")
    return artifact, recomputed
