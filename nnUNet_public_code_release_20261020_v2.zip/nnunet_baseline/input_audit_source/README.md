# Original M&Ms-2 v3 input-audit source

This directory preserves the original input-audit entry point, common module, and configuration. Their exact bytes were recovered from the controlled cloud bundle on 20 October 2026 and matched the frozen receipt. They reconstruct the deterministic patient partition, supervision scope, and content-hash inventory used by the later nnU-Net preparation scripts. No datasets, patient rows, fixed split contents, images, masks, or model weights are distributed here.

Keep the original filenames: the entry point imports `mnms2_scope_control_v3_common`, and the configuration's default filename is resolved beside the entry point.

| File | SHA-256 |
|---|---|
| `80_audit_mnms2_scope_inputs_v3.py` | `e68f725f3504a11dd8c25d3af51af0835aaf83a46b237b362fac59d6c4b09bc7` |
| `mnms2_scope_control_v3_common.py` | `e32305e959ce9870a29ea92ea48ce5abfab4f53933ca122508b7474df558d8f6` |
| `mnms2_scope_control_config_v3.json` | `f60b8784b7ea60c0004888cd6fa0ff0b6fcd444c0555fd005dc042ff750295e9` |

The independent frozen-receipt digest used in the read-only check was `adb7a9cbaaa1a8d94b81a61bd0e2efa80f4eef01a8d63d089b1934cd92f8e826`. This receipt and the private audit tables remain controlled artifacts. Recovering these files closes the previously missing **input-audit generation implementation**; it does not establish all historical training or propagation executions.

## Inputs and outputs

The source reads `MROOT/manifest_mnms2.csv`, image/label paths under `MROOT/all/`, and selected GT NIfTI files under `ROOT/dataset/`. The exact configured manifest digest and historical validation-key digest are checked. Deterministic partitioning uses a local seeded shuffle followed by disease-stratified allocation into one development and ten formal blocks. B uses GT on anchor/outside-span slices and PF on internal non-anchor slices; missing required PF fails. Cneg omits internal non-anchor labels and otherwise uses the same GT rule. The program hashes input files; it does not generate propagated labels or inspect NIfTI physical units.

It generates **five CSVs and one JSON**:

- `patient_partitions_v3.csv`;
- `partition_disease_summary_v3.csv`;
- `label_scope_audit_v3.csv`;
- `input_uses_v3.csv`;
- `input_file_manifest_v3.csv`;
- `input_audit_summary_v3.json`.

These include the four files consumed by downstream nnU-Net preparation. The full audit also preserves supporting disease and input-use tables. Patient-level contents and absolute-path rows remain private. See the package's `PRIVATE_INPUT_SPEC.md` for the controlled layout. The physical-file inventory includes selected PNGs and validation/external GT NIfTI files, rather than a complete raw-image NIfTI archive.

## Verification mode and writing behavior

**The default mode writes new audit outputs; it is not a dry run.** There is no `--write` flag. If the six output names do not already exist, the program writes all five CSVs and the summary. Some audit failures are accumulated, written as a complete `FAIL` audit, and only then cause exit status 1. If any named output already exists, default mode refuses to overwrite it.

Use **`--verify-existing`** for a controlled recomputation of an existing audit. This branch requires all six outputs, compares each existing CSV's SHA-256 with a newly computed in-memory CSV serialization, compares 15 selected summary fields, prints a status/path/summary-digest receipt, and returns before the writing branch. Static review found no application-level writes in this branch or its reachable common helpers. The common module has no operational top-level calls or model imports. Use `python -B` to suppress bytecode-cache writes.

The CLI alone is not the full provenance gate:

1. Independently verify source, common, configuration, and frozen-receipt digests. The CLI does not invoke the common module's `verify_receipt` helper.
2. Independently require the old summary's `status` to be `PASS`, its failure list empty, and all six existing outputs intact. Matching old/new FAIL audits could otherwise produce `PASS_VERIFIED_EXISTING`.
3. Preserve the original absolute input roots. Record the existing six file digests and audit-directory inventory before and after verification if demonstrating that the originals were not changed.

The 15 compared summary fields are `protocol_id`, `status`, `manifest_sha256`, `partition_seed`, `siemens_total_patients`, `validation_patients`, `development_patients`, `formal_patients`, `unused_patients`, `validation_key_sha256`, `block_key_sha256`, `external_patient_counts`, `unique_physical_files`, `outputs`, and `failures`. This is **not** a newly serialized whole-JSON byte comparison. In particular, the comparison excludes the summary's `config_sha256`, configuration path, and manifest path; configuration authenticity must be checked separately.

## Example: check an existing audit on the original cloud layout

Run from the `nnunet_baseline/` package root, after the independent gates above. This is an execution example, not a command run by the offline release verifier:

```bash
INPUT_SOURCE="$PWD/input_audit_source"
/root/autodl-tmp/nnunet-2.8.1-venv/bin/python -B \
  "$INPUT_SOURCE/80_audit_mnms2_scope_inputs_v3.py" \
  --config "$INPUT_SOURCE/mnms2_scope_control_config_v3.json" \
  --mroot /root/autodl-tmp/mnms/seg_lv \
  --root /root/autodl-tmp/mnms/MnM2 \
  --out-dir /root/autodl-tmp/mnms/seg_lv/scope_control_v3_zero_gpu_audit \
  --verify-existing
```

The actual options are `--config`, `--mroot`, `--root`, `--out-dir`, and `--verify-existing`. Without explicit `--config`, the original filename beside the script is used. Other defaults are the cloud roots shown above. No GPU is required. Direct dependencies are the Python standard library, NumPy, and pandas; no additional local Python module beyond the included common source is required. The successful current recomputation used Python 3.12.3, NumPy 2.3.5, and pandas 3.0.3. These record that verification environment, not every historical execution environment. A serialization mismatch under another pandas version is not permission to overwrite frozen outputs. Unsuccessful raw tracebacks may contain controlled paths or keys; keep them private.

## Recorded read-only result and remaining boundaries

The reviewed aggregate report is `../results/input_generator/generator_readonly_audit_public.json` (relative to this directory), SHA-256 `e1fe96c58e6a717146485480da1b151c20f95401a73cff965e2aa7dbb6179bfa`. It records:

- original source/common/configuration hashes matched the frozen receipt, and the existing summary was independently confirmed PASS with no failures;
- all five recomputed CSV digests and the 15 compared summary fields matched;
- 13,501 physical input files were content-hashed;
- the original six audit files, audit-directory inventory, and source/configuration bytes remained unchanged.

This confirms that the recovered implementation and current controlled inputs reproduce the existing input-audit artifacts under the checked environment. With those original inputs, the generation stage can be reconstructed. It does **not** make the package a one-command reproduction of the whole study from raw MRI: the historical lineage of propagation helpers and foundational weights remains limited, and this verification does not prove every historical run or resumed attempt. Dataset/split contents remain private. The check neither resolves unknown spatial-unit declarations nor establishes independently validated physical mL measurements or clinical ED/ES selection. Predictions and frozen endpoints were not altered.
