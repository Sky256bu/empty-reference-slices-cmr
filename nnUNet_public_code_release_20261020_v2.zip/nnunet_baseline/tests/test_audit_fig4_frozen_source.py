"""Synthetic checks only; these tests are not an empirical Fig. 4 audit."""
import copy
import csv
import hashlib
import importlib.util
import io
from pathlib import Path
import tempfile
import unittest
from unittest import mock

SCRIPT = Path(__file__).resolve().parents[1] / "tools" / "audit_fig4_frozen_source.py"
spec = importlib.util.spec_from_file_location("fig4audit", SCRIPT)
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)


def synthetic_fixture():
    rows, expected = [], []
    for phase in ("ed", "es"):
        for arm, budgets in (("A", (5, 10, 15, 25, 50, 100)), ("B", (5, 10, 15, 25, 50, 100)),
                             ("C", (5, 10, 15, 25, 50, 100)), ("I", (5, 10, 15))):
            for budget in budgets:
                value = float((ord(arm) - 64) * 10 + budget + (100 if phase == "es" else 0))
                expected.append(dict(phase=phase, arm=arm, N=str(budget), p25=str(value), p50=str(value), p75=str(value)))
                for seed in ("0", "1", "2"):
                    for patient in range(50):
                        row = dict.fromkeys(audit.SOURCE_COLUMNS, "0")
                        row.update(key="SYNTHETIC_%02d" % patient, phase=phase, arm=arm,
                                   N=str(budget), seed=seed, empty_fp=str(value))
                        rows.append(row)
    return rows, expected


class AuditTests(unittest.TestCase):
    def test_exact_embedded_reference(self):
        empirical = SCRIPT.parent.parent / "results/fig4/Fig4_source_values.csv"
        self.assertEqual(empirical.read_bytes(), audit.EXPECTED_CSV.encode("utf-8"))
        self.assertEqual(len(audit.expected_rows()), 42)

    def test_synthetic_valid_groups(self):
        rows, expected = synthetic_fixture()
        report, per_seed, pooled = audit.summarize_rows(rows, expected)
        self.assertEqual((len(rows), len(per_seed), len(pooled)), (6300, 126, 42))
        self.assertEqual(report["compared_numeric_cells"], 126)
        self.assertEqual(len(report["es_N100_per_seed"]), 9)
        self.assertTrue(all(r["strict_A_lt_B_lt_C"] for r in report["median_ordering_by_phase_budget_seed"]))
        text = str((report, per_seed, pooled))
        self.assertNotIn("SYNTHETIC_", text)

    def test_duplicate_rejected(self):
        rows, expected = synthetic_fixture()
        rows[1] = rows[0].copy()
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            audit.summarize_rows(rows, expected)

    def test_patient_set_change_rejected(self):
        rows, expected = synthetic_fixture()
        rows[50]["key"] = "SYNTHETIC_UNMATCHED"
        with self.assertRaisesRegex(ValueError, "Patient sets"):
            audit.summarize_rows(rows, expected)

    def test_percentile_change_rejected(self):
        rows, expected = synthetic_fixture()
        expected[0]["p50"] = "9999"
        with self.assertRaisesRegex(ValueError, "percentile mismatch"):
            audit.summarize_rows(rows, expected)

    def test_nonfinite_rejected(self):
        rows, expected = synthetic_fixture()
        rows[0]["empty_fp"] = "nan"
        with self.assertRaisesRegex(ValueError, "finite"):
            audit.summarize_rows(rows, expected)

    def test_source_hash_gate_has_no_output(self):
        with tempfile.TemporaryDirectory(dir=None) as td:
            source = Path(td) / "fake.csv"
            source.write_text("not the empirical source", encoding="utf-8")
            output = Path(td) / "out"
            with self.assertRaisesRegex(ValueError, "SHA256 mismatch"):
                audit.main(["--source", str(source), "--output", str(output), "--write"])
            self.assertFalse(output.exists())

    def test_synthetic_write_and_no_overwrite(self):
        rows, expected = synthetic_fixture()
        source_buffer, expected_buffer = io.StringIO(), io.StringIO()
        for buffer, records, columns in ((source_buffer, rows, audit.SOURCE_COLUMNS),
                                         (expected_buffer, expected, ["phase", "arm", "N", "p25", "p50", "p75"])):
            writer = csv.DictWriter(buffer, fieldnames=columns, lineterminator="\n")
            writer.writeheader()
            writer.writerows(records)
        raw = source_buffer.getvalue().encode()
        synthetic_expected = expected_buffer.getvalue()
        with tempfile.TemporaryDirectory(dir=None) as td, mock.patch.multiple(
                audit, SOURCE_SHA256=hashlib.sha256(raw).hexdigest(),
                EXPECTED_CSV=synthetic_expected,
                EXPECTED_SHA256=hashlib.sha256(synthetic_expected.encode()).hexdigest()):
            source, output = Path(td) / "synthetic.csv", Path(td) / "out"
            source.write_bytes(raw)
            argv = ["--source", str(source), "--output", str(output)]
            with mock.patch("sys.stdout", new=io.StringIO()):
                self.assertEqual(audit.main(argv), 0)
                self.assertFalse(output.exists())
                self.assertEqual(audit.main(argv + ["--write"]), 0)
            self.assertEqual(len(list(output.iterdir())), 4)
            with self.assertRaisesRegex(ValueError, "already exists"):
                audit.main(argv + ["--write"])
            self.assertEqual(source.read_bytes(), raw)


if __name__ == "__main__":
    unittest.main()
