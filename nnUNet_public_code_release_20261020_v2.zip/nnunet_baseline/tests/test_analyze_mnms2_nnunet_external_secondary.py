"""Privacy-safe synthetic checks of the read-only rep00 secondary analysis."""

from __future__ import annotations

import csv
import json
import shutil
import subprocess
import sys
import unittest
import uuid
import tempfile
from contextlib import contextmanager
from pathlib import Path

import analyze_mnms2_nnunet_external_secondary as secondary


PARENT = Path(tempfile.gettempdir())
FIELDS = [
    "unit", "arm", "vendor", "patient_key", "edv_gt_ml", "esv_gt_ml",
    "edv_pred_ml", "esv_pred_ml", "edv_abs_error_ml", "esv_abs_error_ml",
    "ed_dice_full_stack", "es_dice_full_stack", "ed_slices", "es_slices",
    "ed_present_slices", "es_present_slices", "ed_empty_gt_slices",
    "es_empty_gt_slices", "ed_empty_gt_fp_slices", "es_empty_gt_fp_slices",
    "ef_invalid",
]


@contextmanager
def synthetic_directory():
    parent = PARENT.resolve(strict=True)
    root = parent / f"secondary_synthetic_{uuid.uuid4().hex}"
    root.mkdir()
    try:
        yield root
    finally:
        if root.resolve().parent != parent:
            raise RuntimeError("Synthetic cleanup target escaped its workspace directory")
        shutil.rmtree(root)


def make_fixture(root: Path, *, invalid: bool = False,
                 corrupt_cohort: bool = False) -> Path:
    (root / "private").mkdir()
    (root / "public").mkdir()
    case_path = root / "private" / "case_metrics_PRIVATE.csv"
    with case_path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=FIELDS)
        writer.writeheader()
        for unit in secondary.UNITS:
            for arm in secondary.ARMS:
                for vendor, count in secondary.VENDORS.items():
                    for index in range(count):
                        key = f"{vendor}_{index:03d}"
                        outlier = unit == "u03" and vendor == "GE" and arm == "B"
                        c_invalid = (invalid and unit == "u04" and arm == "Cneg"
                                     and vendor == "GE" and index < 10)
                        b_invalid = (invalid and unit == "u04" and arm == "B"
                                     and vendor == "GE" and 10 <= index < 12)
                        edv_pred = 0.0 if c_invalid or b_invalid else (140.0 if outlier else (110.0 if arm == "B" else 120.0))
                        esv_pred = 55.0 if arm == "B" else 60.0
                        row_vendor = ("GE" if corrupt_cohort and unit == "u00"
                                      and arm == "B" and vendor == "Philips" and index == 0
                                      else vendor)
                        writer.writerow({
                            "unit": unit, "arm": arm, "vendor": row_vendor,
                            "patient_key": key, "edv_gt_ml": 100, "esv_gt_ml": 50,
                            "edv_pred_ml": edv_pred, "esv_pred_ml": esv_pred,
                            "edv_abs_error_ml": abs(edv_pred - 100),
                            "esv_abs_error_ml": abs(esv_pred - 50),
                            "ed_dice_full_stack": (0 if c_invalid or b_invalid else
                                                    (.1 if outlier else (.8 if arm == "B" else .6))),
                            "es_dice_full_stack": .7 if arm == "B" else .5,
                            "ed_slices": 4, "es_slices": 3,
                            "ed_present_slices": 2, "es_present_slices": 2,
                            "ed_empty_gt_slices": 2, "es_empty_gt_slices": 1,
                            "ed_empty_gt_fp_slices": 0 if c_invalid or b_invalid else (1 if arm == "B" else 0),
                            "es_empty_gt_fp_slices": 0 if arm == "B" else 1,
                            "ef_invalid": int(c_invalid or b_invalid),
                        })
    for relative in secondary.EXPECTED_OUTPUTS - {"private/case_metrics_PRIVATE.csv"}:
        (root / relative).write_text("synthetic\n", encoding="utf-8")
    audit = {
        "schema": "mnms2_nnunet_external_evaluation_v1", "status": "PASS",
        "rep": "rep00", "models": 20, "cases_per_model": 3072,
        "patients_per_model": 141, "evaluator_script_sha256": "0" * 64,
        "bootstrap": {"seed": secondary.BOOTSTRAP_SEED,
                      "draws": secondary.BOOTSTRAP_DRAWS},
        "checkpoint_sha256": {name: "0" * 64 for name in secondary.MODEL_NAMES},
        "prediction_inventories": {name: "0" * 64 for name in secondary.MODEL_NAMES},
        "prediction_audit_sha256": {name: "0" * 64 for name in secondary.MODEL_NAMES},
        "output_sha256": {relative: secondary.sha256(root / relative)
                          for relative in secondary.EXPECTED_OUTPUTS},
    }
    (root / "public" / "evaluation_audit.json").write_text(
        json.dumps(audit), encoding="utf-8")
    return case_path


class SecondaryAnalysisTests(unittest.TestCase):
    def test_paired_effect_unit_directions_bootstrap_and_fp_denominators(self):
        with synthetic_directory() as root:
            make_fixture(root)
            before = sorted(str(path.relative_to(root)) for path in root.rglob("*"))
            result = secondary.analyze(root)
            after = sorted(str(path.relative_to(root)) for path in root.rglob("*"))
            self.assertEqual(before, after)
            self.assertEqual(result["status"], "PASS")
            self.assertEqual(result["private_case_rows_read"], 2820)
            self.assertNotIn("GE_000", json.dumps(result))
            philips, ge, all_vendors = result["by_vendor"]
            self.assertAlmostEqual(philips["metrics"]["ed_dice_full_stack"]["b_minus_cneg_mean"], .2)
            self.assertEqual(philips["metrics"]["ed_dice_full_stack"]["unit_direction"],
                             {"b": 10, "cneg": 0, "tie": 0})
            self.assertAlmostEqual(ge["metrics"]["ed_dice_full_stack"]["b_minus_cneg_mean"], .13)
            self.assertEqual(ge["metrics"]["ed_dice_full_stack"]["unit_direction"],
                             {"b": 9, "cneg": 1, "tie": 0})
            self.assertAlmostEqual(all_vendors["metrics"]["ed_dice_full_stack"]["b_minus_cneg_mean"],
                                   (88 * .2 + 53 * .13) / 141)
            self.assertEqual(ge["by_unit"][3]["unit"], "u03")
            self.assertAlmostEqual(ge["by_unit"][3]["b_minus_cneg_mean"]["edv_abs_error_ml"], 20)
            self.assertEqual(all_vendors["empty_gt_fp"]["ed"]["empty_gt_slices"], 2820)
            self.assertEqual(all_vendors["empty_gt_fp"]["ed"]["b_fp_slices"], 1410)
            self.assertEqual(all_vendors["empty_gt_fp"]["ed"]["cneg_fp_slices"], 0)
            self.assertEqual(all_vendors["empty_gt_fp"]["ed"]["b_minus_cneg_rate_pp"], 50)
            self.assertEqual(all_vendors["empty_gt_fp"]["es"]["b_minus_cneg_rate_pp"], -100)
            self.assertAlmostEqual(philips["metrics"]["ed_dice_full_stack"]["ci95"][0], .2)
            self.assertAlmostEqual(philips["metrics"]["ed_dice_full_stack"]["ci95"][1], .2)

    def test_ef_invalid_rate_and_summary_cli(self):
        with synthetic_directory() as root:
            make_fixture(root, invalid=True)
            result = secondary.analyze(root, include_units=False)
            ge = result["by_vendor"][1]
            self.assertNotIn("by_unit", ge)
            self.assertAlmostEqual(
                ge["metrics"]["ef_invalid_rate_pct"]["b_minus_cneg_mean"],
                100 * (2 - 10) / 530)
            self.assertEqual(ge["metrics"]["ef_invalid_rate_pct"]["unit_direction"],
                             {"b": 1, "cneg": 0, "tie": 9})
            process = subprocess.run(
                [sys.executable, str(Path(secondary.__file__)),
                 "--evaluation-dir", str(root), "--summary"],
                capture_output=True, text=True, check=True)
            printed = json.loads(process.stdout)
            self.assertEqual(printed["status"], "PASS")
            self.assertTrue(all("by_unit" not in item for item in printed["by_vendor"]))
            self.assertEqual(process.stderr, "")

    def test_rejects_checksum_change_and_cohort_mismatch(self):
        with synthetic_directory() as root:
            path = make_fixture(root)
            with path.open("a", encoding="utf-8") as stream:
                stream.write("tampered\n")
            with self.assertRaisesRegex(secondary.AnalysisError, "SHA256"):
                secondary.analyze(root)
        with synthetic_directory() as root:
            make_fixture(root, corrupt_cohort=True)
            with self.assertRaisesRegex(secondary.AnalysisError, "cohort"):
                secondary.analyze(root)


if __name__ == "__main__":
    unittest.main()
