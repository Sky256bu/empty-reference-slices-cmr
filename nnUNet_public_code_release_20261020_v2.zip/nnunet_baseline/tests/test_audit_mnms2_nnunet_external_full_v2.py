"""Synthetic, non-patient checks for the cloud-only full EF failure audit."""

from __future__ import annotations

import io
import math
import tempfile
import sys
import types
import unittest
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path
from unittest.mock import patch

import numpy as np

import audit_mnms2_nnunet_external_full_v2 as audit
import evaluate_mnms2_nnunet_external as evaluator


class FullEFAuditTests(unittest.TestCase):
    def test_undefined_ef_and_finite_extreme_are_separate(self) -> None:
        undefined = {
            "gt_edv_ml": 100.0, "pred_edv_ml": 0.0, "pred_esv_ml": 10.0,
            "pred_ef_pct": None, "undefined_ef": True,
            "finite_ef_out_of_range": False, "abs_error_pp": None,
        }
        flags = audit.classify_case(undefined, 1.0, 0.05)
        self.assertTrue(flags["undefined_ef"])
        self.assertFalse(flags["finite_ef_out_of_range"])
        self.assertTrue(flags["pred_esv_gt_edv"])
        self.assertTrue(flags["core_failure_or_tail_union"])

        extreme = dict(undefined, pred_edv_ml=0.01, pred_esv_ml=0.2,
                       pred_ef_pct=-1900.0, undefined_ef=False,
                       finite_ef_out_of_range=True, abs_error_pp=1950.0)
        flags = audit.classify_case(extreme, 1.0, 0.05)
        self.assertFalse(flags["undefined_ef"])
        self.assertTrue(flags["finite_abs_ef_error_gt_100_pp"])
        self.assertTrue(flags["finite_abs_ef_error_gt_500_pp"])
        self.assertTrue(flags["pred_edv_lt_configured_ml"])
        self.assertTrue(flags["pred_edv_lt_configured_fraction_of_gt"])

    def test_ef_above_100_precision_boundary_preserves_frozen_flag(self) -> None:
        value = 100.0 + math.ulp(100.0)
        row = {
            "gt_edv_ml": 100.0, "pred_edv_ml": 50.0,
            "pred_esv_ml": 0.0, "pred_ef_pct": value,
            "undefined_ef": False, "finite_ef_out_of_range": True,
            "abs_error_pp": 50.0,
        }
        flags = audit.classify_case(row, 1.0, 0.05)
        self.assertTrue(flags["finite_above_100_precision_boundary"])
        self.assertTrue(flags["finite_ef_out_of_range"])
        self.assertFalse(flags["pred_esv_gt_edv"])

    def test_slice_and_case_metrics_detect_changed_prediction(self) -> None:
        ground_truth = np.array([[True, False], [False, False]])
        prediction = np.array([[True, True], [False, False]])
        slice_row = {
            "gt_px": "1", "pred_px": "2", "intersection_px": "1",
            "gt_present": "1", "empty_gt_fp_px": "0", "dice": str(2 / 3),
        }
        self.assertEqual(audit.verify_slice(prediction, ground_truth,
                                            slice_row)["pred_px"], 2)
        with self.assertRaisesRegex(audit.FullAuditError, "slice_metrics"):
            audit.verify_slice(prediction, ground_truth,
                               dict(slice_row, pred_px="3"))

        ed = {
            "gt_volume_ml": 100.0, "pred_volume_ml": 0.01,
            "dice_full_stack": 0.5, "dice_volume_present": 0.5,
            "dice_slice_present": 0.5, "slices": 2,
            "present_slices": 1, "empty_gt_slices": 1,
            "empty_gt_fp_slices": 0, "empty_gt_fp_px": 0,
        }
        es = dict(ed, gt_volume_ml=50.0, pred_volume_ml=0.2)
        ground_truth_ef = audit.ef(100.0, 50.0)
        predicted_ef = audit.ef(0.01, 0.2)
        case_row = {
            f"{phase}_{key}": str(value)
            for phase, item in (("ed", ed), ("es", es))
            for key, value in item.items()
        }
        case_row.update({
            "edv_gt_ml": "100", "edv_pred_ml": "0.01",
            "esv_gt_ml": "50", "esv_pred_ml": "0.2",
            "edv_abs_error_ml": "99.99", "esv_abs_error_ml": "49.8",
            "ef_gt_pct": str(ground_truth_ef),
            "ef_pred_pct": str(predicted_ef),
            "ef_error_pp": str(predicted_ef - ground_truth_ef),
            "ef_abs_error_pp": str(abs(predicted_ef - ground_truth_ef)),
            "ef_invalid": "0", "ef_out_of_range": "1",
        })
        self.assertEqual(audit.verify_case(case_row, ed, es)["pred_ef_pct"],
                         predicted_ef)
        with self.assertRaisesRegex(audit.FullAuditError, "case_metrics"):
            audit.verify_case(dict(case_row, edv_pred_ml="1"), ed, es)

    def test_reconstructed_image_export_shape_and_range(self) -> None:
        raw = np.arange(24, dtype=np.float64).reshape(3, 4, 2)
        frames = audit.exported_u8_frames(raw)
        self.assertEqual(frames.shape, (2, 3, 4))
        self.assertEqual(frames.dtype, np.uint8)
        self.assertEqual(int(frames.min()), 0)
        self.assertEqual(int(frames.max()), 255)

    def test_swapped_phase_in_private_slice_table_is_rejected(self) -> None:
        cases = [
            evaluator.Case("ed_case", "synthetic_key", "ed", 0, "GE",
                           "ed_gt.png", "ed_img.png", 1),
            evaluator.Case("es_case", "synthetic_key", "es", 0, "GE",
                           "es_gt.png", "es_img.png", 1),
        ]
        records = [{
            "unit": "u00", "arm": "B", "case_id": case.case_id,
            "patient_key": case.key, "vendor": case.vendor,
            "phase": case.phase, "z": str(case.z),
        } for case in cases]
        with patch.object(audit, "rows", return_value=records), \
             patch.object(audit, "EXPECTED_SLICE_ROWS", 2):
            self.assertEqual(len(audit.load_private_slice_rows(Path("."), cases)), 2)
            records[0]["phase"] = "es"
            with self.assertRaisesRegex(audit.FullAuditError, "slice_table"):
                audit.load_private_slice_rows(Path("."), cases)

    def test_nifti_export_mapping_rejects_image_or_gt_pixel_change(self) -> None:
        class Header:
            spatial_unit = "mm"

            def get_xyzt_units(self):
                return self.spatial_unit, "sec"

        class Nifti:
            def __init__(self, volume):
                self.volume = volume
                self.shape = volume.shape
                self.affine = np.eye(4)
                self.header = Header()

            def get_fdata(self):
                return self.volume

        base = Path("synthetic_root")
        image_root = base / "mnms" / "seg_lv" / "all"
        raw = np.array([[[0.0], [1.0]], [[2.0], [3.0]]])
        gt = np.array([[[0.0], [1.0]], [[0.0], [1.0]]])
        frame = audit.exported_u8_frames(raw)[0]
        gt_png = np.rint(gt[:, :, 0]) == 1
        cases = []
        stage_map = {}
        physical = {}
        for phase in ("ed", "es"):
            case = evaluator.Case(f"{phase}_case", "synthetic_key", phase, 0,
                                  "GE", f"{phase}_gt.png", f"{phase}_img.png", 2)
            cases.append(case)
            source_gt = image_root / case.gt_rel
            source_img = image_root / case.img_rel
            physical[str(source_gt)] = f"{phase}_gt_hash"
            physical[str(source_img)] = f"{phase}_img_hash"
            stage_map[case.case_id] = {
                "patient_key": case.key, "phase": phase, "z": "0",
                "gt_rel": case.gt_rel, "image_rel": case.img_rel,
                "source_gt_sha256": physical[str(source_gt)],
                "source_image_sha256": physical[str(source_img)],
            }
        volumes = {"gt": Nifti(gt), "raw": Nifti(raw)}
        fake_nib = types.ModuleType("nibabel")
        fake_nib.load = lambda path: volumes["gt" if path.endswith("_gt.nii.gz") else "raw"]
        images = {f"{phase}_img.png": frame.copy() for phase in ("ed", "es")}
        masks = {f"{phase}_gt.png": gt_png.copy() for phase in ("ed", "es")}
        with patch.dict(sys.modules, {"nibabel": fake_nib}), \
             patch.object(evaluator, "EXPECTED_CASES", 2), \
             patch.object(evaluator, "checked_file", return_value="ok"), \
             patch.object(evaluator, "inside", side_effect=lambda root, rel: root / rel), \
             patch.object(evaluator, "read_gray", side_effect=lambda path: images[path.name]), \
             patch.object(evaluator, "binary_mask", side_effect=lambda path, *_: masks[path.name]):
            refs, scales, geometry = audit.source_reference_and_geometry(
                base, cases, stage_map, physical)
            self.assertEqual(len(refs), 2)
            self.assertEqual(geometry["source_image_pngs_compared_to_current_raw_nifti_export"], 2)
            self.assertEqual(scales["synthetic_key", "ed"], 0.001)
            self.assertEqual(geometry["nifti_spatial_units_mm_stacks"], 2)
            self.assertEqual(geometry["nifti_phase_stacks_with_any_unknown_spatial_units"], 0)

            Header.spatial_unit = "unknown"
            with self.assertRaisesRegex(audit.FullAuditError, "nifti_spatial_units"):
                audit.source_reference_and_geometry(base, cases, stage_map, physical)
            unknown_refs, unknown_scales, unknown_geometry = audit.source_reference_and_geometry(
                base, cases, stage_map, physical, True)
            self.assertEqual(len(unknown_refs), 2)
            self.assertEqual(unknown_scales, scales)
            self.assertEqual(unknown_geometry["nifti_spatial_units_mm_stacks"], 0)
            self.assertEqual(unknown_geometry["nifti_gt_spatial_units_unknown_stacks"], 2)
            self.assertEqual(unknown_geometry["nifti_raw_spatial_units_unknown_stacks"], 2)
            self.assertEqual(unknown_geometry["nifti_phase_stacks_with_any_unknown_spatial_units"], 2)
            self.assertEqual(unknown_geometry["patients_with_any_unknown_spatial_units"], 1)
            Header.spatial_unit = "meter"
            with self.assertRaisesRegex(audit.FullAuditError, "nifti_spatial_units"):
                audit.source_reference_and_geometry(base, cases, stage_map, physical, True)
            Header.spatial_unit = "unknown"
            images["ed_img.png"] = frame.copy()
            images["ed_img.png"][0, 0] ^= 1
            with self.assertRaisesRegex(audit.FullAuditError, "raw_image_png_export"):
                audit.source_reference_and_geometry(base, cases, stage_map, physical, True)
            images["ed_img.png"] = frame.copy()
            masks["ed_gt.png"] = gt_png.copy()
            masks["ed_gt.png"][0, 0] = True
            with self.assertRaisesRegex(audit.FullAuditError, "nifti_png_lv_mapping"):
                audit.source_reference_and_geometry(base, cases, stage_map, physical, True)

    def test_only_unknown_units_can_be_conditionally_accepted(self) -> None:
        self.assertEqual(audit.spatial_unit_category("mm", False), "mm")
        self.assertEqual(audit.spatial_unit_category("unknown", True), "unknown")
        for value in ("unknown", "meter", "micron", "", None, "UNKNOWN"):
            with self.assertRaisesRegex(audit.FullAuditError, "nifti_spatial_units"):
                audit.spatial_unit_category(value, False)
        for value in ("meter", "micron", "", None, "UNKNOWN"):
            with self.assertRaisesRegex(audit.FullAuditError, "nifti_spatial_units"):
                audit.spatial_unit_category(value, True)

    def test_conditional_summary_cannot_claim_unqualified_pass(self) -> None:
        records = [{"vendor": "GE", "arm": "B",
                    "count_only_ef_audit": {name: 0 for name in audit.COUNT_ONLY_NAMES},
                    "flags": {name: False for name in audit.FLAG_NAMES}}]
        with patch.object(audit, "EXPECTED_CASE_ROWS", 1):
            report = audit.summarize(records,
                {"nifti_phase_stacks_with_any_unknown_spatial_units": 2},
                6, 1.0, 0.05, "a", "b", "c", "d")
            self.assertEqual(report["status"], "TECHNICAL_PASS_WITH_UNVERIFIED_SPATIAL_UNITS")
            self.assertIn("not establish", report["spatial_units_interpretation"]["ef_scale_cancellation_limit"])
            mm_report = audit.summarize(records,
                {"nifti_phase_stacks_with_any_unknown_spatial_units": 0},
                6, 1.0, 0.05, "a", "b", "c", "d")
            self.assertNotEqual(mm_report["status"], "PASS")

    def test_conditional_output_uses_separate_nonoverwriting_path(self) -> None:
        with tempfile.TemporaryDirectory(dir=Path(__file__).resolve().parent) as directory:
            base = Path(directory)
            old = base / "nnUNet_ef_failure_tail_audit" / "rep00_aggregate.json"
            old.parent.mkdir()
            old.write_text("strict-original", encoding="utf-8")
            result = {"status": "TECHNICAL_PASS_WITH_UNVERIFIED_SPATIAL_UNITS"}
            destination = audit.write_aggregate(base, result)
            self.assertEqual(destination.name, "rep00_conditional_units_v2_aggregate.json")
            self.assertEqual(old.read_text(encoding="utf-8"), "strict-original")
            self.assertEqual(audit.write_aggregate(base, result), destination)
            with self.assertRaisesRegex(audit.FullAuditError, "aggregate_output_conflict"):
                audit.write_aggregate(base, dict(result, changed=True))

    def test_count_only_ef_checks_extreme_finite_error_without_ml_assumption(self) -> None:
        ed = {"gt_px": 5000, "pred_px": 10}
        es = {"gt_px": 2500, "pred_px": 40}
        stored = {"ef_gt_pct": "50", "ef_pred_pct": "-300", "ef_abs_error_pp": "350"}
        measured = {"undefined_ef": False}
        for scale in (0.001, 0.25, 100.0):
            counts = audit.verify_count_only_ef(ed, es, scale, scale, stored, measured)
            self.assertEqual(counts["reference_ef_checked_from_counts"], 1)
            self.assertEqual(counts["predicted_finite_ef_checked_from_counts"], 1)
            self.assertEqual(counts["positive_count_threshold_invalid"], 0)
        with self.assertRaisesRegex(audit.FullAuditError, "count_only_predicted_ef"):
            audit.verify_count_only_ef(ed, es, 0.001, 0.001,
                dict(stored, ef_pred_pct="-299"), measured)
        skipped = audit.verify_count_only_ef(ed, es, 0.001, 0.002, stored, measured)
        self.assertEqual(skipped["unequal_numeric_ed_es_scale_evaluations_skipped"], 1)
        self.assertEqual(skipped["reference_ef_checked_from_counts"], 0)

    def test_count_only_undefined_requires_zero_foreground(self) -> None:
        ed = {"gt_px": 5000, "pred_px": 0}
        es = {"gt_px": 2500, "pred_px": 40}
        counts = audit.verify_count_only_ef(ed, es, 0.001, 0.001,
            {"ef_gt_pct": "50"}, {"undefined_ef": True})
        self.assertEqual(counts["zero_predicted_ed_foreground_count"], 1)
        self.assertEqual(counts["undefined_matches_zero_predicted_ed_count"], 1)
        self.assertEqual(counts["predicted_finite_ef_checked_from_counts"], 0)
        self.assertEqual(counts["positive_count_threshold_invalid"], 0)
        with self.assertRaisesRegex(audit.FullAuditError, "count_only_undefined_not_zero_ed"):
            audit.verify_count_only_ef(dict(ed, pred_px=1), es, 1e-9, 1e-9,
                {"ef_gt_pct": "50"}, {"undefined_ef": True})

    def test_count_only_does_not_replace_frozen_roundoff_out_of_range_flag(self) -> None:
        ed = {"gt_px": 5000, "pred_px": 10}
        es = {"gt_px": 2500, "pred_px": 0}
        stored = {"ef_gt_pct": "50", "ef_pred_pct": str(100.0 + math.ulp(100.0)),
                  "ef_abs_error_pp": str(50.0 + math.ulp(100.0)), "ef_out_of_range": "1"}
        measured = {"undefined_ef": False, "finite_ef_out_of_range": True}
        counts = audit.verify_count_only_ef(ed, es, 0.001, 0.001, stored, measured)
        self.assertEqual(counts["predicted_finite_ef_checked_from_counts"], 1)
        self.assertEqual(stored["ef_out_of_range"], "1")
        self.assertTrue(measured["finite_ef_out_of_range"])

    def test_cli_never_echoes_private_exception(self) -> None:
        stdout, stderr = io.StringIO(), io.StringIO()
        with patch.object(audit, "audit_all",
                          side_effect=RuntimeError("PRIVATE_PATIENT_123")), \
             patch.object(sys, "argv", ["audit", "--base", str(Path.cwd())]), \
             redirect_stdout(stdout), redirect_stderr(stderr):
            code = audit.main()
        self.assertEqual(code, 1)
        self.assertEqual(stdout.getvalue(), "")
        self.assertNotIn("PRIVATE_PATIENT_123", stderr.getvalue())


if __name__ == "__main__":
    unittest.main()
