"""Synthetic, privacy-safe checks of the rep00 aggregate packaging boundary."""

from __future__ import annotations

import csv
import hashlib
import json
import shutil
import unittest
import uuid
import tempfile
from contextlib import contextmanager
from pathlib import Path

import package_mnms2_nnunet_r1_public as package


PARENT = Path(tempfile.gettempdir())
PRIVATE_SENTINEL = "DO_NOT_EXPORT_PATIENT_KEY_123"


@contextmanager
def synthetic_root():
    parent = PARENT.resolve(strict=True)
    root = parent / f"bundle_synthetic_{uuid.uuid4().hex}"
    root.mkdir()
    try:
        yield root
    finally:
        if root.resolve().parent != parent:
            raise RuntimeError("Synthetic cleanup target escaped workspace")
        shutil.rmtree(root)


def save_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def csv_file(path: Path, fields: set[str], rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as stream:
        writer = csv.DictWriter(stream, fieldnames=sorted(fields))
        writer.writeheader()
        writer.writerows(rows)


def make_fixture(base: Path) -> tuple[Path, Path, Path]:
    evaluation = base / "nnUNet_external_evaluation" / "rep00"
    for relative in package.AUDITED_CSVS[:3]:
        path = evaluation / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(f"patient_key\n{PRIVATE_SENTINEL}\n", encoding="utf-8")
    csv_file(evaluation / package.PUBLIC_CSVS[0], package.ARM_FIELDS, [
        {field: (unit if field == "unit" else arm if field == "arm" else
                 vendor if field == "vendor" else 0)
         for field in package.ARM_FIELDS}
        for unit in package.UNITS for arm in package.ARMS for vendor in package.VENDORS
    ])
    csv_file(evaluation / package.PUBLIC_CSVS[1], package.UNIT_FIELDS, [
        {field: (unit if field == "unit" else vendor if field == "vendor" else 0)
         for field in package.UNIT_FIELDS}
        for unit in package.UNITS for vendor in package.VENDORS
    ])
    csv_file(evaluation / package.PUBLIC_CSVS[2], package.OVERALL_FIELDS, [
        {field: (vendor if field == "vendor" else 0) for field in package.OVERALL_FIELDS}
        for vendor in package.VENDORS
    ])
    hashes = {relative: package.sha256(evaluation / relative)
              for relative in package.AUDITED_CSVS}
    zero = "0" * 64
    models = {model: zero for model in package.MODELS}
    audit = {
        "schema": "mnms2_nnunet_external_evaluation_v1", "status": "PASS",
        "created_utc": "2026-09-29T00:00:00+00:00",
        "purpose": "exploratory_additional_analysis_on_previously_used_held_out_vendors",
        "rep": "rep00", "models": 20, "cases_per_model": 3072,
        "evaluator_script_sha256": zero, "patients_per_model": 141,
        "manifest_sha256": zero, "stage_audit_sha256": zero,
        "physical_input_audit_sha256": zero,
        "checkpoint_sha256": models, "prediction_inventories": models,
        "prediction_audit_sha256": models,
        "thresholds": {"source_gt_png": ">127 of 0/255",
                       "nnunet_prediction_png": ">0 of 0/1"},
        "voxel_ml": "abs(det(original_GT_NIfTI_affine_3x3))/1000",
        "ef_formula": "100*(EDV-ESV)/EDV; EDV<=1e-6 mL is invalid",
        "dice_definition": "full_stack counts all slices; volume_present pools GT-positive slices; slice_present averages GT-positive slice Dice; empty-empty slice Dice=1",
        "invalid_ef_policy": "Retained in private case rows and public denominators; no full-endpoint bootstrap if any invalid EF",
        "bootstrap": {"seed": 20260928, "draws": 2000,
                      "resampling": "training unit and vendor-stratified patient, preserving repeated patient measurements across units"},
        "output_sha256": hashes,
    }
    save_json(evaluation / "public" / "evaluation_audit.json", audit)
    for unit in package.UNITS:
        for arm in package.ARMS:
            model = f"{unit}_{arm}"
            dataset_id = 901 + 2 * int(unit[1:]) + int(arm == "Cneg")
            dataset = f"Dataset{dataset_id:03d}_MnMS2_{unit}_{arm}"
            split = base / "nnUNet_preprocessed" / dataset / "splits_final.json"
            split.parent.mkdir(parents=True, exist_ok=True)
            split.write_text("[]\n", encoding="utf-8")
            checkpoint = (base / "nnUNet_results_formal" / "rep00" / dataset
                          / "nnUNetTrainer__nnUNetPlansSharedU00GT__2d"
                          / "fold_0" / "checkpoint_final.pth")
            checkpoint.parent.mkdir(parents=True, exist_ok=True)
            checkpoint.write_bytes(b"synthetic checkpoint " + model.encode())
            checkpoint_sha = package.sha256(checkpoint)
            audit["checkpoint_sha256"][model] = checkpoint_sha
            formal = {
                "schema": "mnms2_nnunet2d_formal_v1", "status": "PASS",
                "unit": unit, "arm": arm, "rep": "rep00", "dataset": dataset,
                "planned_epochs": 1000,
                "final_model_rule": "checkpoint_final.pth_only",
                "fixed_split_sha256": package.sha256(split),
                "validated_artifacts": {
                    "checkpoint_final_sha256": checkpoint_sha,
                    "validation_summary_sha256": zero,
                    "validation_predictions_inventory_sha256": zero,
                },
            }
            save_json(base / "nnUNet_results_formal" / "rep00" / "_audit"
                      / f"{model}.json", formal)
    save_json(evaluation / "public" / "evaluation_audit.json", audit)
    secondary = {
        "status": "PASS", "rep": "rep00",
        "analysis": "post_hoc_exploratory_R1_after_inspecting_EF",
        "models": 20, "private_case_rows_read": 2820,
        "audited_csv_sha256_verified": 6,
        "audit_evaluator_sha256": zero,
        "bootstrap": {"seed": 20260928, "draws": 2000},
        "by_vendor": [],
    }
    for vendor, n in package.VENDORS.items():
        metrics = {name: {
            "b_mean": 1.0, "cneg_mean": 0.0, "b_minus_cneg_mean": 1.0,
            "ci95": [0.0, 2.0],
            "unit_direction": {"b": 10, "cneg": 0, "tie": 0},
        } for name in package.METRICS}
        fp = {phase: {
            "empty_gt_slices": 10, "b_fp_slices": 1,
            "cneg_fp_slices": 0, "b_minus_cneg_fp_slices": 1,
            "b_rate_pct": 10.0, "cneg_rate_pct": 0.0,
            "b_minus_cneg_rate_pp": 10.0, "rate_diff_ci95_pp": [0.0, 20.0],
        } for phase in ("ed", "es")}
        secondary["by_vendor"].append({
            "vendor": vendor, "unique_patients": n,
            "paired_unit_patient_evaluations": 10 * n,
            "metrics": metrics, "empty_gt_fp": fp,
        })
    secondary_path = base / "nnUNet_r1_secondary_summary_rep00.json"
    save_json(secondary_path, secondary)
    outlier_path = base / "nnUNet_r1_outlier_audit_rep00.json"
    save_json(outlier_path, {
        "status": "PASS", "scope": "rep00 u03/B GE largest finite EF absolute error",
        "audited_csv_checksums_verified": 6, "prediction_PNG_inventory": "PASS",
        "manifest_stage_ED_ES_mapping": "PASS",
        "source_GT_PNG_and_NIfTI_affine": "PASS",
        "stored_slice_and_case_metrics_recomputed": "PASS",
        "extreme_B_u03_GE_case_counts": {
            "ef_abs_error_gt_100_pp": 3, "ef_abs_error_gt_500_pp": 1},
        "target_volume_categories": ["predicted_EDV_below_1_mL"],
    })
    return secondary_path, outlier_path, base / "nnUNet_r1_public_bundle_rep00"


class PublicBundleTests(unittest.TestCase):
    def test_preflight_write_whitelist_and_no_overwrite(self):
        with synthetic_root() as base:
            secondary, outlier, bundle = make_fixture(base)
            before = sorted(str(path.relative_to(base)) for path in base.rglob("*"))
            files, provenance = package.preflight(base, secondary, outlier, bundle)
            self.assertEqual(before,
                             sorted(str(path.relative_to(base)) for path in base.rglob("*")))
            self.assertEqual(set(files), {
                "evaluation_audit.json", "unit_arm_vendor_summary.csv",
                "paired_unit_vendor_summary.csv", "paired_overall_summary.csv",
                "secondary_summary_public.json", "outlier_audit_public.json",
                "provenance.json"})
            self.assertEqual(len(provenance["model_artifact_sha256"]), 20)
            package.write_bundle(bundle, files)
            self.assertEqual(set(path.name for path in bundle.iterdir()), set(files))
            self.assertNotIn(PRIVATE_SENTINEL,
                             "".join(path.read_text(encoding="utf-8") for path in bundle.iterdir()))
            with self.assertRaises(package.PackageError):
                package.preflight(base, secondary, outlier, bundle)

    def test_reject_private_hash_change(self):
        with synthetic_root() as base:
            secondary, outlier, bundle = make_fixture(base)
            with (base / "nnUNet_external_evaluation" / "rep00" / "private"
                  / "case_metrics_PRIVATE.csv").open("a", encoding="utf-8") as stream:
                stream.write("changed\n")
            with self.assertRaisesRegex(package.PackageError, "SHA256"):
                package.preflight(base, secondary, outlier, bundle)


if __name__ == "__main__":
    unittest.main()
