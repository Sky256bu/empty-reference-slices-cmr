"""Synthetic tampering tests for the source inventory verifier."""
import hashlib
from pathlib import Path
import tempfile
import unittest

import verify_release


class ReleaseIntegrityTests(unittest.TestCase):
    def fixture(self, root):
        data = b'print("synthetic")\n'
        (root / 'source.py').write_bytes(data)
        (root / 'SHA256SUMS.txt').write_text(hashlib.sha256(data).hexdigest() + '  source.py\n', encoding='ascii')

    def test_content_change_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            self.fixture(root)
            self.assertEqual(verify_release.verify(root)['python_files_compiled'], 1)
            (root / 'source.py').write_text('print("changed")\n')
            with self.assertRaisesRegex(ValueError, 'checksum'):
                verify_release.verify(root)

    def test_unreviewed_extra_file_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            self.fixture(root)
            (root / 'unreviewed.csv').write_text('synthetic\n')
            with self.assertRaisesRegex(ValueError, 'inventory'):
                verify_release.verify(root)

    def test_traversal_and_duplicate_paths_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            self.fixture(root)
            row = (root / 'SHA256SUMS.txt').read_text()
            (root / 'SHA256SUMS.txt').write_text(row.replace('source.py', '../outside.py'))
            with self.assertRaisesRegex(ValueError, 'Unsafe'):
                verify_release.verify(root)
            (root / 'SHA256SUMS.txt').write_text(row + row)
            with self.assertRaisesRegex(ValueError, 'duplicate'):
                verify_release.verify(root)


if __name__ == '__main__':
    unittest.main()
