"""Small synthetic checks for the cloud-only external scorer."""

from __future__ import annotations

import csv
import io
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np

import evaluate_mnms2_nnunet_external as evaluator


class ExternalScorerTests(unittest.TestCase):
    def test_complete_stack_dice_empty_gt_and_ef(self) -> None:
        pred_dir = Path("synthetic_predictions")
        predictions = {}
        with patch.object(evaluator, "binary_mask", side_effect=lambda path, *_: predictions[path.name]):
            masks = {
                ("ed", 0): ([[1, 1], [0, 0]], [[1, 1], [0, 0]]),
                ("ed", 1): ([[0, 0], [0, 0]], [[1, 0], [0, 0]]),
                ("es", 0): ([[1, 0], [0, 0]], [[1, 0], [0, 0]]),
                ("es", 1): ([[0, 0], [0, 0]], [[0, 0], [0, 0]]),
            }
            cases = []
            references = {}
            for (phase, z), (gt, pred) in masks.items():
                cid = evaluator.case_id("001", phase, z)
                cases.append(evaluator.Case(cid, "001", phase, z, "Philips", "unused", "unused", int(np.sum(gt))))
                references[cid] = np.asarray(gt, dtype=bool)
                predictions[f"{cid}.png"] = np.asarray(pred, dtype=bool)
            stream = io.StringIO()
            fields = ["unit", "arm", "vendor", "patient_key", "phase", "z", "case_id", "gt_px",
                      "pred_px", "intersection_px", "dice", "gt_present", "empty_gt_fp_px"]
            writer = csv.DictWriter(stream, fieldnames=fields)
            rows = evaluator.evaluate_model({"unit": "u00", "arm": "B", "pred_dir": pred_dir},
                                            cases, references, {("001", "ed"): 1.0, ("001", "es"): 1.0}, writer)
            self.assertEqual(len(rows), 1)
            row = rows[0]
            self.assertAlmostEqual(row["ed_dice_full_stack"], 0.8)
            self.assertAlmostEqual(row["ed_dice_volume_present"], 1.0)
            self.assertAlmostEqual(row["ed_dice_slice_present"], 1.0)
            self.assertEqual(row["ed_empty_gt_fp_px"], 1)
            self.assertEqual(row["ed_empty_gt_fp_slices"], 1)
            self.assertAlmostEqual(row["ef_gt_pct"], 50.0)
            self.assertAlmostEqual(row["ef_pred_pct"], 100 / 3 * 2)
            self.assertEqual(row["ef_invalid"], 0)

    def test_out_of_range_ef_is_scored_and_zero_edv_is_invalid(self) -> None:
        self.assertEqual(evaluator.ef(1.0, 2.0), -100.0)
        self.assertIsNone(evaluator.ef(0.0, 0.0))
        pred_dir = Path("synthetic_predictions")
        predictions = {}
        with patch.object(evaluator, "binary_mask", side_effect=lambda path, *_: predictions[path.name]):
            cases = []
            refs = {}
            for phase, gt, pred in (("ed", [[1, 0], [0, 0]], [[1, 0], [0, 0]]),
                                    ("es", [[1, 0], [0, 0]], [[1, 1], [0, 0]])):
                cid = evaluator.case_id("001", phase, 0)
                cases.append(evaluator.Case(cid, "001", phase, 0, "GE", "unused", "unused", 1))
                refs[cid] = np.asarray(gt, dtype=bool)
                predictions[f"{cid}.png"] = np.asarray(pred, dtype=bool)
            writer = csv.DictWriter(io.StringIO(), fieldnames=["unit", "arm", "vendor", "patient_key", "phase", "z",
                                                               "case_id", "gt_px", "pred_px", "intersection_px", "dice",
                                                               "gt_present", "empty_gt_fp_px"])
            row = evaluator.evaluate_model({"unit": "u00", "arm": "B", "pred_dir": pred_dir}, cases, refs,
                                           {("001", "ed"): 1.0, ("001", "es"): 1.0}, writer)[0]
            self.assertEqual(row["ef_pred_pct"], -100)
            self.assertEqual(row["ef_abs_error_pp"], 100)
            self.assertEqual(row["ef_invalid"], 0)
            self.assertEqual(row["ef_out_of_range"], 1)

    def test_paired_bootstrap_preserves_repeated_patients(self) -> None:
        cases = []
        for unit in evaluator.UNITS:
            for vendor, count in evaluator.EXPECTED_PATIENTS.items():
                for index in range(count):
                    key = f"{vendor}{index:03d}"
                    for arm, ae in (("B", 1.0), ("Cneg", 3.0)):
                        cases.append({"unit": unit, "arm": arm, "vendor": vendor, "patient_key": key,
                                      "ef_invalid": 0, "ef_abs_error_pp": ae})
        _, by_unit, overall = evaluator.aggregate_pairs(cases)
        self.assertEqual(len(by_unit), 30)
        for row in overall:
            self.assertEqual(row["complete_ef_endpoint"], 1)
            self.assertAlmostEqual(row["paired_b_minus_cneg_mean_pp"], -2)
            self.assertAlmostEqual(row["bootstrap_ci_low_pp"], -2)
            self.assertAlmostEqual(row["bootstrap_ci_high_pp"], -2)
            self.assertEqual(row["units_favoring_b"], 10)

    def test_incomplete_ef_endpoint_keeps_counts_without_headline(self) -> None:
        cases = []
        for unit in evaluator.UNITS:
            for arm in evaluator.ARMS:
                cases.append({"unit": unit, "arm": arm, "vendor": "Philips", "patient_key": "001",
                              "ef_invalid": int(unit == "u00" and arm == "B"),
                              "ef_abs_error_pp": None if unit == "u00" and arm == "B" else 1.0})
        _, _, overall = evaluator.aggregate_pairs(cases)
        row = next(r for r in overall if r["vendor"] == "Philips")
        self.assertEqual(row["complete_ef_endpoint"], 0)
        self.assertEqual(row["b_invalid_evaluations"], 1)
        self.assertIsNone(row["paired_b_minus_cneg_mean_pp"])
        self.assertIsNone(row["bootstrap_ci_low_pp"])


if __name__ == "__main__":
    unittest.main()
