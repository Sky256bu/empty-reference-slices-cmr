"""Synthetic tests only: no cloud experimental data is used by these tests."""
import contextlib
import copy
import importlib.util
import io
import json
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

SCRIPT = Path(__file__).resolve().parents[1] / "tools" / "audit_mnms2_experiment_facts.py"
spec = importlib.util.spec_from_file_location("experiment_facts_audit", SCRIPT)
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)


def fixture():
    partition = []
    number = 1
    for role, block, count in [("validation", "", 43), ("development", "d00", 10),
                               *[("formal", unit, 10) for unit in audit.UNITS],
                               ("unused", "", 66)]:
        for _ in range(count):
            partition.append({"key": f"{number:03d}", "role": role, "block_id": block})
            number += 1
    manifest = []
    for patient in partition:
        for phase in ("ed", "es"):
            for z in range(4):
                manifest.append({"key": patient["key"], "phase": phase, "z": str(z),
                                 "vendor": "SIEMENS", "gt_px": "15" if z < 3 else "1",
                                 "is_anchor": str(int(z in (0, 2))),
                                 "in_lvspan": str(int(z < 3)),
                                 "dist": str(1 if z == 1 else 0 if z < 3 else -1)})
    scopes = []
    for block in audit.BLOCKS:
        keys = {r["key"] for r in partition if r["block_id"] == block}
        for arm in ("B", "Cneg"):
            scopes.append({"block_id": block, "arm": arm,
                           "role": "development" if block == "d00" else "formal",
                           "train_patients": "10", "gt_rows": "60",
                           "pf_rows": "20" if arm == "B" else "0",
                           "label_rows": "80" if arm == "B" else "60",
                           "internal_nonanchor_rows": "20" if arm == "B" else "0",
                           "block_key_sha256": audit.key_sha256(keys)})
    return manifest, partition, scopes


class AuditTests(unittest.TestCase):
    def test_synthetic_complete_partition_and_scopes(self):
        result = audit.audit_tables(*fixture())
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["partition"]["unique_patients"], 219)
        self.assertEqual(result["manifest"]["validation_gt_slices"], 344)
        self.assertEqual(result["label_scope"]["B_Cneg_gt_scope_symmetric_difference_rows"], 0)
        self.assertEqual(len(result["partition"]["pairwise_training_block_overlap_counts"]), 55)

    def test_outside_span_is_not_necessarily_empty(self):
        result = audit.audit_tables(*fixture())
        self.assertEqual(result["anchor_compatibility"]["outside_span_rows_with_positive_gt_pixels"], 438)
        self.assertFalse(result["anchor_compatibility"]["historical_cli_threshold_proven"])

    def test_duplicate_patient_rejected_even_if_roles_unchanged(self):
        m, p, s = fixture()
        p[1]["key"] = p[0]["key"]
        result = audit.audit_tables(m, p, s)
        self.assertEqual(result["status"], "FAIL")
        self.assertEqual(result["partition"]["duplicate_patient_rows"], 1)

    def test_overlap_across_formal_units_rejected(self):
        m, p, s = fixture()
        source = next(r for r in p if r["block_id"] == "u00")
        next(r for r in p if r["block_id"] == "u01")["key"] = source["key"]
        result = audit.audit_tables(m, p, s)
        self.assertEqual(result["partition"]["pairwise_training_block_overlap_counts"]["u00_vs_u01"], 1)
        self.assertIn("patient_overlap", result["failures"])

    def test_anchor_threshold_boundary_mismatch_detected(self):
        m, p, s = fixture()
        m[1]["gt_px"] = "14"  # Only two qualifying slices: frozen rule becomes fallback.
        result = audit.audit_tables(m, p, s)
        self.assertFalse(result["anchor_compatibility"]["threshold_compatible"])
        self.assertEqual(result["anchor_compatibility"]["fewer_than_three_qualifying_stacks"], 1)
        self.assertEqual(result["anchor_compatibility"]["anchor_mismatch_rows"], 2)

    def test_fewer_than_three_fallback_is_supported(self):
        m, p, s = fixture()
        # Validation patient only; all slices correctly fall outside the span.
        for row in m[:4]:
            row.update(gt_px="14", is_anchor="0", in_lvspan="0", dist="-1")
        result = audit.audit_tables(m, p, s)
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["anchor_compatibility"]["fewer_than_three_qualifying_stacks"], 1)

    def test_scope_tampering_rejected(self):
        m, p, s = fixture()
        s[2]["gt_rows"] = "59"
        result = audit.audit_tables(m, p, s)
        self.assertEqual(result["label_scope"]["scope_mismatch_rows"], 1)
        self.assertEqual(result["status"], "FAIL")

    def test_duplicate_case_rejected(self):
        m, p, s = fixture()
        m.append(copy.deepcopy(m[0]))
        result = audit.audit_tables(m, p, s)
        self.assertEqual(result["manifest"]["duplicate_slice_rows"], 1)
        self.assertEqual(result["status"], "FAIL")

    def test_scope_block_hash_tampering_rejected(self):
        m, p, s = fixture()
        s[0]["block_key_sha256"] = "0" * 64
        self.assertEqual(audit.audit_tables(m, p, s)["label_scope"]["scope_mismatch_rows"], 1)

    def test_write_is_new_only_and_preflight_does_not_write(self):
        result = {"status": "PASS", "failures": [], "test_fixture_only": True}
        with tempfile.TemporaryDirectory(dir=None) as temp, patch.object(audit, "audit", return_value=result):
            destination = Path(temp) / "new"
            args = ["--mroot", str(Path(temp) / "source"), "--output-dir", str(destination)]
            with contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(audit.main(args), 0)
                self.assertFalse(destination.exists())
                self.assertEqual(audit.main(args + ["--write"]), 0)
                with self.assertRaises(FileExistsError):
                    audit.main(args + ["--write"])
            self.assertEqual(json.loads((destination / "summary_public.json").read_text()), result)

    def test_failed_audit_never_writes(self):
        with tempfile.TemporaryDirectory(dir=None) as temp, patch.object(audit, "audit", return_value={"status": "FAIL"}):
            destination = Path(temp) / "new"
            with contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(audit.main(["--write", "--output-dir", str(destination)]), 1)
            self.assertFalse(destination.exists())


if __name__ == "__main__":
    unittest.main()
