"""Synthetic archive checks; no clinical records or cloud files are used."""

from __future__ import annotations

import contextlib
import csv
import hashlib
import io
import json
import shutil
import tarfile
import unittest
import uuid
import tempfile
from contextlib import contextmanager
from pathlib import Path
from unittest.mock import patch

import package_mnms2_nnunet_r1_public as package
import verify_mnms2_nnunet_r1_public_bundle as verifier
from test_package_mnms2_nnunet_r1_public import PRIVATE_SENTINEL, make_fixture


@contextmanager
def synthetic_root():
    parent = Path(tempfile.gettempdir())
    root = parent / f"bundle_verify_synthetic_{uuid.uuid4().hex}"
    root.mkdir()
    try:
        yield root
    finally:
        if root.resolve().parent != parent:
            raise RuntimeError("Synthetic cleanup target escaped the workspace")
        shutil.rmtree(root)


def encoded(value: dict) -> bytes:
    return (json.dumps(value, indent=2) + "\n").encode("utf-8")


def make_tar(path: Path, files: dict[str, bytes], extra: list[tuple[str, bytes, bytes | None]] | None = None) -> None:
    with tarfile.open(path, "w:gz") as archive:
        directory = tarfile.TarInfo(verifier.ROOT)
        directory.type = tarfile.DIRTYPE
        archive.addfile(directory)
        for name, content in files.items():
            item = tarfile.TarInfo(f"{verifier.ROOT}/{name}")
            item.size = len(content)
            archive.addfile(item, io.BytesIO(content))
        for name, content, kind in extra or []:
            item = tarfile.TarInfo(name)
            if kind is not None:
                item.type = kind
                item.linkname = "../private"
            else:
                item.size = len(content)
            archive.addfile(item, io.BytesIO(content) if kind is None else None)


def fixture_files(base: Path) -> dict[str, bytes]:
    secondary, outlier, bundle = make_fixture(base)
    files, _ = package.preflight(base, secondary, outlier, bundle)
    for name in verifier.PUBLIC_CSVS:
        reader = csv.DictReader(io.StringIO(files[name].decode("utf-8")))
        fields = reader.fieldnames
        assert fields is not None
        rows = list(reader)
        for row in rows:
            patients = verifier.VENDORS[row["vendor"]]
            if name == "unit_arm_vendor_summary.csv":
                row.update(patients=str(patients), ef_valid_patients=str(patients))
            elif name == "paired_unit_vendor_summary.csv":
                row.update(patients=str(patients), paired_valid_patients=str(patients))
            else:
                row.update(units="10", patients_per_unit=str(patients),
                           complete_ef_endpoint="1", bootstrap_seed="20260928",
                           bootstrap_draws="2000")
        output = io.StringIO(newline="")
        writer = csv.DictWriter(output, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)
        files[name] = output.getvalue().encode("utf-8")
    rechain(files, *verifier.PUBLIC_CSVS)
    return files


def rechain(files: dict[str, bytes], *changed_csvs: str) -> None:
    audit = json.loads(files["evaluation_audit.json"])
    for changed_csv in changed_csvs:
        audit["output_sha256"][f"public/{changed_csv}"] = verifier.hash_bytes(files[changed_csv])
    files["evaluation_audit.json"] = encoded(audit)
    provenance = json.loads(files["provenance.json"])
    provenance["evaluation_audit_sha256"] = verifier.hash_bytes(files["evaluation_audit.json"])
    provenance["copied_or_generated_files_sha256"] = {
        name: verifier.hash_bytes(files[name]) for name in verifier.HASHED_FILES}
    files["provenance.json"] = encoded(provenance)


class PublicBundleVerifierTests(unittest.TestCase):
    def test_valid_bundle_expected_hash_and_no_extraction(self) -> None:
        with synthetic_root() as base:
            files = fixture_files(base)
            archive = base / "bundle.tar.gz"
            make_tar(archive, files)
            before = {path.relative_to(base) for path in base.rglob("*")}
            expected = hashlib.sha256(archive.read_bytes()).hexdigest()
            self.assertEqual(verifier.verify_bundle(archive, expected), expected)
            self.assertEqual(before, {path.relative_to(base) for path in base.rglob("*")})
            stdout = io.StringIO()
            with patch("sys.argv", ["verifier", str(archive), "--expected-sha256", expected]), \
                    contextlib.redirect_stdout(stdout):
                self.assertEqual(verifier.main(), 0)
            self.assertIn("BUNDLE VERIFY PASS", stdout.getvalue())
            self.assertNotIn(PRIVATE_SENTINEL, stdout.getvalue())

    def test_reject_wrong_download_hash(self) -> None:
        with synthetic_root() as base:
            archive = base / "bundle.tar.gz"
            make_tar(archive, fixture_files(base))
            with self.assertRaisesRegex(verifier.VerificationError, "archive SHA256"):
                verifier.verify_bundle(archive, "0" * 64)

    def test_reject_extra_private_member_link_traversal_and_duplicate(self) -> None:
        with synthetic_root() as base:
            files = fixture_files(base)
            variants = [
                ("extra", [(f"{verifier.ROOT}/case_metrics_PRIVATE.csv", b"secret", None)]),
                ("link", [(f"{verifier.ROOT}/escape", b"", tarfile.SYMTYPE)]),
                ("traversal", [(f"{verifier.ROOT}/../escape", b"secret", None)]),
                ("duplicate", [(f"{verifier.ROOT}/provenance.json", b"duplicate", None)]),
            ]
            for label, extra in variants:
                with self.subTest(label=label):
                    archive = base / f"{label}.tar.gz"
                    make_tar(archive, files, extra)
                    with self.assertRaises(verifier.VerificationError):
                        verifier.verify_bundle(archive)

    def test_reject_public_content_hash_change(self) -> None:
        with synthetic_root() as base:
            files = fixture_files(base)
            files["secondary_summary_public.json"] += b" "
            archive = base / "altered.tar.gz"
            make_tar(archive, files)
            with self.assertRaisesRegex(verifier.VerificationError, "provenance SHA256"):
                verifier.verify_bundle(archive)

    def test_reject_audit_csv_hash_even_when_provenance_is_updated(self) -> None:
        with synthetic_root() as base:
            files = fixture_files(base)
            audit = json.loads(files["evaluation_audit.json"])
            audit["output_sha256"]["public/paired_overall_summary.csv"] = "0" * 64
            files["evaluation_audit.json"] = encoded(audit)
            rechain(files)
            archive = base / "bad-audit.tar.gz"
            make_tar(archive, files)
            with self.assertRaisesRegex(verifier.VerificationError, "evaluation audit SHA256"):
                verifier.verify_bundle(archive)

    def test_reject_csv_key_even_when_hashes_are_updated(self) -> None:
        with synthetic_root() as base:
            files = fixture_files(base)
            name = "paired_unit_vendor_summary.csv"
            text = files[name].decode("utf-8")
            self.assertIn("u00,", text)
            files[name] = text.replace("u00,", "u99,", 1).encode("utf-8")
            rechain(files, name)
            archive = base / "bad-key.tar.gz"
            make_tar(archive, files)
            with self.assertRaisesRegex(verifier.VerificationError, "aggregate row"):
                verifier.verify_bundle(archive)

    def test_reject_patient_level_json_field_with_recomputed_hash(self) -> None:
        with synthetic_root() as base:
            files = fixture_files(base)
            secondary = json.loads(files["secondary_summary_public.json"])
            secondary["patient_key"] = PRIVATE_SENTINEL
            files["secondary_summary_public.json"] = encoded(secondary)
            provenance = json.loads(files["provenance.json"])
            provenance["copied_or_generated_files_sha256"]["secondary_summary_public.json"] = (
                verifier.hash_bytes(files["secondary_summary_public.json"]))
            files["provenance.json"] = encoded(provenance)
            archive = base / "private-field.tar.gz"
            make_tar(archive, files)
            with self.assertRaisesRegex(verifier.VerificationError, "secondary summary"):
                verifier.verify_bundle(archive)


if __name__ == "__main__":
    unittest.main()
