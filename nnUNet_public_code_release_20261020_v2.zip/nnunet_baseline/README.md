# Additional nnU-Net baseline: source and audit materials

This package documents the additional 2D nnU-Net experiment accompanying the empty-reference-slice CMR study. Version 2 adds the original v3 input-audit entry point, common module, configuration and read-only reconstruction record to the preserved baseline source, exact reference plan, reviewed aggregate results and offline checks. The source recovery and cloud verification took place on 20 October 2026; this extended local archive was prepared on 21 October 2026. The earlier v1 ZIP is retained unchanged. It does not contain patient images, masks, identifiers, private mappings, fixed case splits, model weights, or the reference fingerprint's training-derived arrays. This prepared package does not by itself establish a public repository commit or an archival DOI.

The experiment comprises ten training units (`u00`–`u09`), two supervision arms (`B`, `Cneg`), and one training run per unit/arm (`rep00`): 20 models. Each unit contains ten SIEMENS training patients; all units use the same 43-patient SIEMENS validation cohort. External inference uses the same 141 unique Philips/GE patients in every unit (88/53), with 3,072 ED/ES slices per model. Counts across units are repeated model–patient evaluations, not additional unique patients.

`B` uses ground-truth labels on anchor and outside-span slices and propagated labels on internal non-anchor slices. `Cneg` uses the same ground-truth supervision and omits the propagated internal labels. The comparison uses the official `nnUNetTrainer`, configuration `2d`, fold `0`, 1,000 epochs, and `checkpoint_final.pth`. `rep00` denotes a run index; the launcher follows independent stochastic defaults and does **not** implement paired random seeds between arms.

## What can be checked offline

From this package's `nnunet_baseline/` directory:

```bash
python tools/verify_release.py
python tools/verify_release.py --self-test
python -B scripts/train_mnms2_nnunet2d_formal.py --help
python -B scripts/run_mnms2_nnunet_external.py --help
```

The verifier checks the expected file inventory and SHA-256 values and compiles Python source in memory. Its optional self-test runs the included synthetic tests against the packaged modules, with the required import paths configured by the runner. Source verification uses only the Python standard library; the synthetic numerical tests also require NumPy. These checks do not train a network, access private data, or establish numerical GPU reproducibility. `--help` checks argument parsing only.

## Provenance and interpretation

The preserved runtime files were collected on 20 October 2026. The author-only collection matched the current initial training launcher to recorded initial-script hashes for 20 models, the prediction entry file for 20 models, and the evaluator entry file for one evaluation. These scoped matches do not establish that every helper, resumed attempt, or historical environment had identical bytes. See the included provenance records rather than inferring complete historical coverage.

`config/nnUNetPlans.json` is the exact Dataset900 train-only reference plan:

- plan SHA-256: `99e7f68f6a700511d41d0e69e9226ad2a8e8e3ffe36eac79d2140c339afe3bae`;
- reference fingerprint SHA-256: `cde585fbb93653bcc9b7c9f5454b8e9372da2b184fa40381748fad8354138671`.

Only the fingerprint hash is supplied publicly. The fingerprint itself contains training-derived arrays and remains private. Target plan files acquire dataset-specific identities and therefore need not have the reference file's whole-file hash. The fixed in-plane spacing `[1, 1]` is a PNG image-coordinate convention, not evidence that source MRI resolution was 1 mm.

The frozen evaluator retains `abs(det(affine[:3,:3])) / 1000`. The examined NIfTI headers omit spatial-unit declarations. Exact metric recomputation therefore supports computational consistency under that convention, not independently validated physical mL units. Absolute-volume values are retained as conditional sensitivity/provenance outputs, not a main claim of physical-volume accuracy. EF and count-ratio parity checks have the limits stated in the audit: equal numerical ED/ES factors do not independently prove equal physical conversion factors. Undefined or extreme EF values were not clipped, imputed, or removed to create a complete-cohort primary comparison.

## Executing the original workflow with controlled inputs

Read `PRIVATE_INPUT_SPEC.md`, `DEPENDENCIES.md` and `input_audit_source/README.md` first. The recovered original input-audit entry point, its complete local common-module dependency and original configuration are now included, with exact hashes matched to the frozen receipt. A read-only execution on the controlled system reproduced all five audit CSV hashes and 15 selected summary fields, hashing 13,501 physical inputs; the original six outputs were unchanged. The package is **not a turnkey raw-data reproduction**: exact audited private exports and audit-table contents remain controlled, and a valid dataset download alone cannot satisfy the frozen hashes. The original generator defaults to writing, including some failed audits; use `python -B ... --verify-existing` for existing outputs and perform the independent source/configuration/receipt/PASS gates described in its README. Do not substitute newly created records for historical inputs. Current reconstruction does not prove every historical execution, physical spatial units or the full propagation/weight lineage.

The commands below are an execution map for an authorized custodian who already has the controlled inputs and compatible Linux/CUDA environment. They are not run by the offline verifier. Choose one working root and use the same root throughout:

```bash
export RELEASE=/absolute/path/to/nnunet_baseline
export BASE=/absolute/path/to/controlled_working_root
export PY="$BASE/nnunet-2.8.1-venv/bin/python"
export nnUNet_raw="$BASE/nnUNet_raw"
export nnUNet_preprocessed="$BASE/nnUNet_preprocessed"
export nnUNet_results="$BASE/nnUNet_results"
```

1. **Raw datasets.** Preflight all pairs; add `--write` only to create missing outputs after successful checks:

```bash
"$PY" "$RELEASE/scripts/prepare_all_mnms2_nnunet2d.py" \
  --mroot "$BASE/mnms/seg_lv" --output-root "$BASE/nnUNet_raw"
"$PY" "$RELEASE/scripts/prepare_all_mnms2_nnunet2d.py" \
  --mroot "$BASE/mnms/seg_lv" --output-root "$BASE/nnUNet_raw" --write
"$PY" "$RELEASE/scripts/prepare_mnms2_clean_planning_dataset.py" \
  --raw-root "$BASE/nnUNet_raw" --write
```

The last command creates Dataset900 from only the 101 u00/Cneg training GT slices and excludes 964 validation slices. It does not fingerprint or plan. Before staging, the controlled `nnUNet_preprocessed/Dataset900_MnMS2_CommonPlan_u00_GT/` must contain the reference plan and private reference fingerprint with the exact hashes above; the raw Dataset900 must contain its generated `planning_scope.json`. Recomputing planning artifacts with another environment is not guaranteed to reproduce those bytes. This package does not bypass that check.

2. **Stage, preprocess, train.** The following illustrates one pair; repeat in order for `u01` through `u09`. Commands with `--write` perform work; commands without it preflight or verify existing outputs.

```bash
"$PY" "$RELEASE/scripts/stage_mnms2_shared_nnunet2d_plan.py" --base "$BASE" --unit u00
"$PY" "$RELEASE/scripts/stage_mnms2_shared_nnunet2d_plan.py" --base "$BASE" --unit u00 --write
"$PY" "$RELEASE/scripts/preprocess_mnms2_shared_nnunet2d.py" --base "$BASE" --unit u00
"$PY" "$RELEASE/scripts/preprocess_mnms2_shared_nnunet2d.py" --base "$BASE" --unit u00 --write
"$PY" "$RELEASE/scripts/train_mnms2_nnunet2d_formal.py" --base "$BASE" --unit u00 --arm both --rep 0
"$PY" "$RELEASE/scripts/train_mnms2_nnunet2d_formal.py" --base "$BASE" --unit u00 --arm both --rep 0 --write
```

**The formal training preflight itself requires a visible CUDA GPU**, even without `--write`. `--resume` is only for an audited interrupted run with a checkpoint; `--validate-only` is only for an existing final checkpoint awaiting validation. Neither flag is a substitute for a fresh run. The launcher refuses conflicting or unaudited existing outputs.

3. **External staging, inference, evaluation.** Stage images only; GT and the patient mapping remain private. Omit `--write` for each preflight before executing the corresponding writing command.

```bash
"$PY" "$RELEASE/scripts/stage_mnms2_nnunet_external.py" \
  --mroot "$BASE/mnms/seg_lv" --output-root "$BASE/nnUNet_external_input" --write
"$PY" "$RELEASE/scripts/run_mnms2_nnunet_external.py" \
  --base "$BASE" --rep 0 --unit all --arm both --write
"$PY" "$RELEASE/scripts/evaluate_mnms2_nnunet_external.py" --base "$BASE" --rep 0 --write
"$PY" "$RELEASE/scripts/analyze_mnms2_nnunet_external_secondary.py" \
  --evaluation-dir "$BASE/nnUNet_external_evaluation/rep00" --summary
"$PY" "$RELEASE/scripts/audit_mnms2_nnunet_external_full_v2.py" \
  --base "$BASE" --allow-unknown-spatial-units
```

Inference requires CUDA and the audited formal models. Evaluation and full auditing score existing predictions rather than retraining. The last command explicitly permits a **conditional numerical** audit of unknown-unit headers; known non-mm units still fail. Without the opt-in, unknown units fail. The strict v1 auditor is retained as historical audit source, not silently repaired. Audit diagnostic thresholds do not define new outcomes or change predictions.

Most Python entry points expose configurable paths. `setup_mnms2_nnunet_gpu.sh`, `activate_mnms2_nnunet.sh`, the two batch shell launchers, and the environment probe retain original `/root/autodl-tmp` paths. Treat these as historical AutoDL conveniences; use the explicit commands and paths above for another working root. Public verification is not permission to publish controlled inputs or checkpoints.
