"""Read original run records and locked repeat CSVs; export anonymous metadata only."""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import math
import pandas as pd

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def rows(p):
    with p.open(encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))

def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--base', type=Path, default=Path('/root/autodl-tmp'))
    ap.add_argument('--write', action='store_true')
    args = ap.parse_args(argv)
    base = args.base
    protocol = base / 'mnms/seg_lv/scope_control_v3_protocol'
    receipt_p = protocol / 'MNMS2_SCOPE_CONTROL_FREEZE_RECEIPT_v3.json'
    selected_p = protocol / 'selected_recipe_v3.json'
    aggregate_p = base / 'mnms/seg_lv/scope_control_v3_R3_analysis/mnms2_scope_control_v3_R_aggregate_manifest.json'
    assert sha(receipt_p) == 'adb7a9cbaaa1a8d94b81a61bd0e2efa80f4eef01a8d63d089b1934cd92f8e826'
    assert sha(selected_p) == '809eea855caac2bd75eb013adc46874d7630629533f38d4dbad6cd1ae025657b'
    assert sha(aggregate_p) == '823ebcca048d17d041d3c79221b10dfaba4ee395c9649dcce890cce3c1556268'
    receipt = json.loads(receipt_p.read_text())
    selected = json.loads(selected_p.read_text())
    aggregate = json.loads(aggregate_p.read_text())
    assert receipt['status'] == 'FROZEN' and aggregate['repeats'] == 3
    assert selected['freeze_receipt_sha256'] == sha(receipt_p) == aggregate['freeze_receipt_sha256']
    bundle = base / 'sam3-main/mnms2_scope_control_v3_bundle'
    config_p = bundle / 'mnms2_scope_control_config_v3.json'
    assert sha(config_p) == selected['config_sha256'] == receipt['files'][config_p.name]
    config = json.loads(config_p.read_text())
    assert config['training'] == receipt['frozen_training']
    current_code = []
    for name, expected in receipt['files'].items():
        p = bundle / name
        current_code.append({'file': name, 'present': p.is_file(),
                             'recorded_sha256': expected,
                             'current_sha256': sha(p) if p.is_file() else None,
                             'current_matches_record': p.is_file() and sha(p) == expected})

    highn = []
    archive_root = base / 'acdc_highN_freeze_20260715/provenance/run_manifests'
    for p in sorted((base / 'acdc/seg_lv/ckpt_unified_highN').glob('*/run_manifest_*.json')):
        j = json.loads(p.read_text())
        archive = archive_root / str(p).lstrip('/')
        keep = ('arm', 'nominal_n_train_pat', 'actual_n_train_pat', 'n_val_pat',
                'data_seed', 'train_seed', 'encoder', 'epochs', 'patience',
                'batch_size', 'learning_rate', 'pretrained', 'augmentation')
        record = {k: j[k] for k in keep}
        record.update(record_sha256=sha(p), archived_copy_byte_identical=archive.is_file() and archive.read_bytes() == p.read_bytes())
        assert not set(j['train_keys']) & set(j['val_keys'])
        highn.append(record)
    assert len(highn) == 18 and all(r['archived_copy_byte_identical'] for r in highn)

    frames = []
    repeat_records = []
    identity = lambda r: tuple(r[k] for k in ('unit_id', 'arm', 'domain', 'key'))
    for entry in aggregate['source_evaluations']:
        folder = Path(entry['dir'])
        mp = folder / 'mnms2_scope_control_v3_evaluation_manifest.json'
        cp = folder / 'mnms2_scope_control_v3_per_case_locked.csv'
        assert sha(mp) == entry['manifest_sha256'] and sha(cp) == entry['cases_sha256']
        m = json.loads(mp.read_text())
        assert m['status'] == 'LOCKED' and m['matrix_cells'] == 20
        assert m['freeze_receipt_sha256'] == sha(receipt_p)
        rr = rows(cp)
        frame = {identity(r): r for r in rr}
        assert len(frame) == len(rr) == 3680
        frames.append(frame)
        repeat_records.append({'repeat': folder.name.rsplit('_', 1)[-1], 'case_rows': len(rr),
                               'model_cells': m['matrix_cells'], 'status': m['status'],
                               'manifest_sha256': sha(mp), 'cases_sha256': sha(cp)})
    assert len(frames) == 3 and all(set(f) == set(frames[0]) for f in frames)
    averaged_p = Path(aggregate['outputs']['averaged_cases']['path'])
    assert sha(averaged_p) == aggregate['outputs']['averaged_cases']['sha256']
    averaged_rows = rows(averaged_p)
    averaged = {identity(r): r for r in averaged_rows}
    assert len(averaged) == len(averaged_rows) == 3680 and set(averaged) == set(frames[0])
    parsed0 = pd.read_csv(Path(aggregate['source_evaluations'][0]['dir']) / 'mnms2_scope_control_v3_per_case_locked.csv', dtype={k: str for k in ('unit_id', 'arm', 'domain', 'key')})
    parsed0idx = {identity(r): r for r in parsed0.to_dict('records')}
    raw_inherit_max_delta = 0.0
    raw_inherit_unequal_cells = 0
    max_delta = 0.0
    nonfinite = 0
    inherited_mismatches = 0
    for key, observed in averaged.items():
        values = [float(f[key]['ef_abs_error']) for f in frames]
        expected = sum(values) / 3
        got = float(observed['ef_abs_error'])
        if math.isfinite(expected) and math.isfinite(got):
            max_delta = max(max_delta, abs(expected - got))
        else:
            assert math.isnan(expected) and math.isnan(got)
            nonfinite += 1
        for col in ('edv_pred', 'esv_pred'):
            x, raw_y = float(observed[col]), float(frames[0][key][col])
            raw_inherit_unequal_cells += x != raw_y and not (math.isnan(x) and math.isnan(raw_y))
            if math.isfinite(x) and math.isfinite(raw_y):
                raw_inherit_max_delta = max(raw_inherit_max_delta, abs(x - raw_y))
            y = float(parsed0idx[key][col])
            inherited_mismatches += not (x == y or (math.isnan(x) and math.isnan(y)))
    assert max_delta < 1e-10 and inherited_mismatches == 0
    result = {
        'status': 'PASS_WITH_PARTIAL_ACDC_RUN_METADATA',
        'audit_version': 2,
        'CSV_reader_for_volume_inheritance': 'pandas default float parser, matching the original aggregator',
        'pandas_version': pd.__version__,
        'initial_strict_stdlib_float_check': {'passed': False, 'unequal_volume_cells': raw_inherit_unequal_cells, 'max_absolute_volume_difference': raw_inherit_max_delta, 'explanation': 'Raw-decimal parsing differs from pandas CSV parsing; inherited volumes match exactly after the original reader convention.'},
        'source_sha256': {p.name: sha(p) for p in (receipt_p, selected_p, aggregate_p, config_p)},
        'formal_MnMS2_training': receipt['frozen_training'],
        'selected_recipe': {k: selected[k] for k in ('selected_recipe_id', 'selected_learning_rate', 'selection_status')},
        'current_bundle_files_compared_with_frozen_receipt': current_code,
        'ACDC_high_budget_run_records': highn,
        'ACDC_run_record_coverage': {'records_checked': 18, 'retained_ACDC_configurations': 63,
                                    'budgets': sorted({r['nominal_n_train_pat'] for r in highn}),
                                    'training_seeds': sorted({r['train_seed'] for r in highn}),
                                    'other_configurations_not_certified_by_these_records': 45},
        'original_locked_repeats': repeat_records,
        'repeat_aggregation': {'identical_identity_sets': True, 'rows_per_repeat': 3680,
                               'EF_absolute_error_mean_max_difference': max_delta,
                               'nonfinite_averaged_rows': nonfinite,
                               'locked_repeat_00_volume_inheritance_mismatch_cells': inherited_mismatches},
        'no_patient_keys_or_images_exported': True,
        'limitations': ['Metadata and frozen numerical table audit; original predictions were not reconstructed.',
                        'Current code/record agreement is not proof of every historical execution.',
                        'ACDC runtime coverage is partial; remaining 45 configurations are not assigned settings from defaults.',
                        'Propagation helper and checkpoint historical provenance is not certified by this audit.']}
    if args.write:
        out = base / 'experiment_facts_audit_20261020/training_metadata_public.json'
        out.parent.mkdir(exist_ok=True)
        with out.open('x', encoding='utf-8', newline='\n') as f:
            f.write(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ('ACDC_high_budget_run_records', 'current_bundle_files_compared_with_frozen_receipt')}, indent=2))
    print('ACDC_RECIPE_COMBINATIONS', sorted({(r['nominal_n_train_pat'], r['actual_n_train_pat'], r['n_val_pat'], r['epochs'], r['patience'], r['augmentation']) for r in highn}))
    print('CURRENT_CODE_MATCHES', sum(r['current_matches_record'] for r in current_code), '/', len(current_code))
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
