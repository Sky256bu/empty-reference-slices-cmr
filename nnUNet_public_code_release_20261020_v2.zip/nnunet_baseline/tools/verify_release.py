#!/usr/bin/env python3
"""Verify this reviewed source inventory without private data or training."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys


def verify(root: Path) -> dict:
    root = root.resolve(strict=True)
    checksums = root / 'SHA256SUMS.txt'
    expected = {}
    for line in checksums.read_text(encoding='ascii').splitlines():
        match = re.fullmatch(r'([0-9a-f]{64})  (.+)', line)
        if not match:
            raise ValueError('Malformed checksum row')
        digest, name = match.groups()
        path = PurePosixPath(name)
        if (path.is_absolute() or '..' in path.parts or '\\' in name or ':' in name
                or path.as_posix() != name or name in expected or name == 'SHA256SUMS.txt'):
            raise ValueError('Unsafe or duplicate checksum path')
        expected[name] = digest
    if not expected:
        raise ValueError('Empty checksum inventory')
    actual = set()
    for item in root.rglob('*'):
        if item.is_symlink():
            raise ValueError('Symlinks are not allowed in the release')
        if '__pycache__' in item.relative_to(root).parts:
            continue
        if item.is_file():
            actual.add(item.relative_to(root).as_posix())
    if actual != set(expected) | {'SHA256SUMS.txt'}:
        raise ValueError('File inventory differs from the reviewed release')
    python_count = 0
    for name, digest in expected.items():
        path = root / name
        if not path.resolve(strict=True).is_relative_to(root):
            raise ValueError('File resolves outside release root')
        raw = path.read_bytes()
        if hashlib.sha256(raw).hexdigest() != digest:
            raise ValueError('Content checksum mismatch: ' + name)
        if path.suffix == '.py':
            compile(raw, str(path), 'exec')
            python_count += 1
    return {'status': 'PASS', 'hashed_files': len(expected), 'python_files_compiled': python_count,
            'scope': 'Inventory, byte integrity and syntax; no model/data execution',
            'checksum_manifest_sha256': hashlib.sha256(checksums.read_bytes()).hexdigest()}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--self-test', action='store_true', help='Run synthetic tests; requires NumPy')
    args = parser.parse_args(argv)
    result = verify(args.root)
    print(json.dumps(result, indent=2), flush=True)
    if args.self_test:
        root = args.root.resolve()
        env = os.environ.copy()
        env['PYTHONPATH'] = os.pathsep.join(str(root / sub) for sub in ('scripts', 'tools', 'tests'))
        env['PYTHONDONTWRITEBYTECODE'] = '1'
        # Keep synthetic fixtures in the writable package tree, including in
        # Windows sandboxes whose default temporary directory is not writable.
        fixture_root = str(root / 'tests')
        if os.name == 'nt' and not fixture_root.startswith('\\\\?\\'):
            fixture_root = '\\\\?\\' + fixture_root
        for variable in ('TMP', 'TEMP', 'TMPDIR'):
            env[variable] = fixture_root
        subprocess.run([sys.executable, '-B', '-m', 'unittest', 'discover', '-s', str(root / 'tests'), '-v'],
                       env=env, cwd=root, check=True)
        verify(root)
        print('PASS: synthetic tests exercised the packaged modules; private data and GPU not used.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
