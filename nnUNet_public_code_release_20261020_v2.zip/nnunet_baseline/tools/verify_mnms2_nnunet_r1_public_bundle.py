#!/usr/bin/env python3
"""Read-only, in-memory verification of the rep00 public tar.gz bundle.

This checks the archive boundary and its internal provenance. Supply the
independently recorded cloud SHA256 to authenticate the downloaded archive.
No archive member is extracted to the filesystem or printed.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import io
import json
import math
import re
import sys
import tarfile
from pathlib import Path


ROOT = "nnUNet_r1_public_bundle_rep00"
PUBLIC_CSVS = (
    "unit_arm_vendor_summary.csv",
    "paired_unit_vendor_summary.csv",
    "paired_overall_summary.csv",
)
OTHER_FILES = (
    "evaluation_audit.json",
    "secondary_summary_public.json",
    "outlier_audit_public.json",
)
HASHED_FILES = (*PUBLIC_CSVS, *OTHER_FILES)
FILES = (*HASHED_FILES, "provenance.json")
PRIVATE_CSVS = (
    "slice_metrics_PRIVATE.csv",
    "case_metrics_PRIVATE.csv",
    "paired_case_metrics_PRIVATE.csv",
)
UNITS = tuple(f"u{i:02d}" for i in range(10))
ARMS = ("B", "Cneg")
VENDORS = {"Philips": 88, "GE": 53, "All": 141}
MODELS = {f"{unit}_{arm}" for unit in UNITS for arm in ARMS}
HEX64 = re.compile(r"[0-9a-f]{64}\Z")
MAX_MEMBER_BYTES = 8 * 1024 * 1024
MAX_TOTAL_BYTES = 24 * 1024 * 1024

PHASE_METRICS = (
    "dice_full_stack", "dice_volume_present", "dice_slice_present",
    "slices", "present_slices", "empty_gt_slices", "empty_gt_fp_slices",
    "empty_gt_fp_px",
)
ARM_FIELDS = {
    "unit", "arm", "vendor", "patients", "ef_valid_patients",
    "ef_invalid_patients", "ef_out_of_range_patients", "ef_mae_pp",
    "ef_ae_median_pp", "ef_ae_p90_pp", "ef_ae_gt20_patients",
    "ef_ae_gt40_patients", "edv_mae_ml", "esv_mae_ml",
} | {
    f"{phase}_{metric}_{'total' if metric in PHASE_METRICS[3:] else 'mean'}"
    for phase in ("ed", "es") for metric in PHASE_METRICS
}
UNIT_FIELDS = {
    "unit", "vendor", "patients", "paired_valid_patients",
    "b_invalid_patients", "cneg_invalid_patients",
    "b_minus_cneg_ef_ae_mean_pp", "b_minus_cneg_ef_ae_median_pp",
}
OVERALL_FIELDS = {
    "vendor", "units", "patients_per_unit", "complete_ef_endpoint",
    "b_invalid_evaluations", "cneg_invalid_evaluations", "b_ef_mae_pp",
    "cneg_ef_mae_pp", "paired_b_minus_cneg_mean_pp", "paired_unit_sd_pp",
    "units_favoring_b", "partial_paired_valid_unit_mean_pp",
    "bootstrap_seed", "bootstrap_draws", "bootstrap_ci_low_pp",
    "bootstrap_ci_high_pp",
}
AUDIT_KEYS = {
    "schema", "status", "created_utc", "purpose", "rep", "models",
    "cases_per_model", "evaluator_script_sha256", "patients_per_model",
    "manifest_sha256", "stage_audit_sha256", "physical_input_audit_sha256",
    "checkpoint_sha256", "prediction_inventories", "prediction_audit_sha256",
    "thresholds", "voxel_ml", "ef_formula", "dice_definition",
    "invalid_ef_policy", "bootstrap", "output_sha256",
}
PROVENANCE_KEYS = {
    "schema", "status", "scope", "copied_or_generated_files_sha256",
    "evaluation_audit_sha256", "private_evaluation_csv_sha256",
    "secondary_source_json_sha256", "outlier_source_json_sha256",
    "evaluator_script_sha256", "manifest_sha256", "stage_audit_sha256",
    "physical_input_audit_sha256", "model_artifact_sha256",
    "excluded_artifact_classes",
}
MODEL_ARTIFACT_KEYS = {
    "formal_audit_sha256", "fixed_split_sha256", "checkpoint_final_sha256",
    "validation_summary_sha256", "validation_predictions_inventory_sha256",
    "external_prediction_inventory_sha256", "external_prediction_audit_sha256",
}
SECONDARY_METRICS = {
    "ed_dice_full_stack", "es_dice_full_stack", "edv_abs_error_ml",
    "esv_abs_error_ml", "ed_empty_gt_fp_slices_per_evaluation",
    "es_empty_gt_fp_slices_per_evaluation", "ef_invalid_rate_pct",
}
OUTLIER_CATEGORIES = {
    "predicted_EDV_below_5_percent_of_GT", "predicted_EDV_below_1_mL",
    "predicted_ESV_exceeds_EDV", "none_of_the_predefined_volume_categories",
}


class VerificationError(Exception):
    """Safe failure category that never includes archive content."""


def require(condition: bool, message: str) -> None:
    if not condition:
        raise VerificationError(message)


def digest(value: object) -> str:
    require(isinstance(value, str) and HEX64.fullmatch(value) is not None,
            "A SHA256 field is invalid")
    return value


def hash_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def hash_file(path: Path) -> str:
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(block)
    return result.hexdigest()


def unique_pairs(pairs: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in pairs:
        require(key not in result, "A JSON object has duplicate keys")
        result[key] = value
    return result


def load_json(value: bytes) -> dict:
    try:
        result = json.loads(value.decode("utf-8"), object_pairs_hook=unique_pairs,
                            parse_constant=lambda _: require(False, "A JSON number is nonfinite"))
    except (UnicodeError, ValueError, TypeError):
        raise VerificationError("A public JSON file is unreadable") from None
    require(isinstance(result, dict), "A public JSON file has the wrong structure")
    return result


def finite(value: object) -> float:
    require(type(value) in (int, float) and math.isfinite(value),
            "An aggregate JSON number is invalid")
    return float(value)


def sha_map(value: object, keys: set[str]) -> dict:
    require(isinstance(value, dict) and set(value) == keys,
            "A SHA256 inventory has unexpected keys")
    for item in value.values():
        digest(item)
    return value


def read_archive(path: Path) -> dict[str, bytes]:
    try:
        with tarfile.open(path, mode="r|gz", ignore_zeros=True) as archive:
            expected = {ROOT, *(f"{ROOT}/{name}" for name in FILES)}
            seen = set()
            data = {}
            total = 0
            for member in archive:
                require(len(seen) < len(expected),
                        "Archive members differ from the fixed public allowlist")
                name = ROOT if member.name in (ROOT, ROOT + "/") else member.name
                require(name in expected and name not in seen and not member.pax_headers,
                        "Archive members differ from the fixed public allowlist")
                seen.add(name)
                if name == ROOT:
                    require(member.type == tarfile.DIRTYPE and member.size == 0,
                            "The archive root is not a plain directory")
                    continue
                filename = name.removeprefix(ROOT + "/")
                require(member.name == f"{ROOT}/{filename}" and filename in FILES
                        and member.type in (tarfile.REGTYPE, tarfile.AREGTYPE)
                        and 0 < member.size <= MAX_MEMBER_BYTES,
                        "An archive member is not an allowed ordinary file")
                total += member.size
                require(total <= MAX_TOTAL_BYTES, "Archive contents exceed the size limit")
                stream = archive.extractfile(member)
                require(stream is not None, "An archive member cannot be read")
                with stream:
                    content = stream.read(member.size + 1)
                require(len(content) == member.size,
                        "An archive member has an invalid size")
                data[filename] = content
            require(seen == expected and not archive.pax_headers,
                    "Archive members differ from the fixed public allowlist")
            return data
    except (tarfile.TarError, EOFError):
        raise VerificationError("The tar.gz archive is unreadable") from None


def csv_rows(value: bytes, fields: set[str], keys: tuple[str, ...],
             expected: set[tuple[str, ...]]) -> dict[tuple[str, ...], dict[str, str]]:
    try:
        with io.StringIO(value.decode("utf-8-sig"), newline="") as stream:
            reader = csv.DictReader(stream)
            require(reader.fieldnames is not None
                    and len(reader.fieldnames) == len(fields)
                    and set(reader.fieldnames) == fields,
                    "A public CSV has unexpected columns")
            rows = {}
            for row in reader:
                require(None not in row and all(item is not None for item in row.values()),
                        "A public CSV has an extra or missing field")
                key = tuple(row[field] for field in keys)
                require(key in expected and key not in rows,
                        "A public CSV has an unexpected or duplicate aggregate row")
                for field, item in row.items():
                    if field not in keys and item != "":
                        require(math.isfinite(float(item)),
                                "A public CSV contains a nonfinite number")
                rows[key] = row
    except (UnicodeError, ValueError, csv.Error):
        raise VerificationError("A public CSV is unreadable or nonnumeric") from None
    require(set(rows) == expected, "A public CSV lacks an aggregate row")
    return rows


def count(row: dict[str, str], field: str) -> int:
    item = row[field]
    require(item.isascii() and item.isdecimal(), "An aggregate count is invalid")
    return int(item)


def verify_csvs(data: dict[str, bytes]) -> None:
    arms = csv_rows(data[PUBLIC_CSVS[0]], ARM_FIELDS, ("unit", "arm", "vendor"),
                    {(unit, arm, vendor) for unit in UNITS for arm in ARMS for vendor in VENDORS})
    units = csv_rows(data[PUBLIC_CSVS[1]], UNIT_FIELDS, ("unit", "vendor"),
                     {(unit, vendor) for unit in UNITS for vendor in VENDORS})
    overall = csv_rows(data[PUBLIC_CSVS[2]], OVERALL_FIELDS, ("vendor",),
                       {(vendor,) for vendor in VENDORS})
    for unit in UNITS:
        for vendor, patients in VENDORS.items():
            paired = units[unit, vendor]
            require(count(paired, "patients") == patients
                    and count(paired, "paired_valid_patients") <= patients,
                    "A paired aggregate has an invalid denominator")
            for arm, field in (("B", "b_invalid_patients"),
                               ("Cneg", "cneg_invalid_patients")):
                row = arms[unit, arm, vendor]
                invalid = count(row, "ef_invalid_patients")
                valid = count(row, "ef_valid_patients")
                require(count(row, "patients") == patients and valid + invalid == patients
                        and count(row, "ef_out_of_range_patients") <= valid
                        and count(paired, field) == invalid,
                        "An arm aggregate has inconsistent patient counts")
        require(count(units[unit, "All"], "paired_valid_patients") == sum(
            count(units[unit, vendor], "paired_valid_patients") for vendor in ("Philips", "GE")),
            "The pooled paired count differs from the vendor counts")
        for arm in ARMS:
            for field in ("ef_valid_patients", "ef_invalid_patients",
                          "ef_out_of_range_patients"):
                require(count(arms[unit, arm, "All"], field) == sum(
                    count(arms[unit, arm, vendor], field) for vendor in ("Philips", "GE")),
                    "A pooled arm count differs from the vendor counts")
    for vendor, patients in VENDORS.items():
        row = overall[(vendor,)]
        complete = all(count(units[unit, vendor], "paired_valid_patients") == patients
                       for unit in UNITS)
        require(count(row, "units") == 10
                and count(row, "patients_per_unit") == patients
                and count(row, "complete_ef_endpoint") == int(complete)
                and count(row, "b_invalid_evaluations") == sum(
                    count(units[unit, vendor], "b_invalid_patients") for unit in UNITS)
                and count(row, "cneg_invalid_evaluations") == sum(
                    count(units[unit, vendor], "cneg_invalid_patients") for unit in UNITS),
                "The overall aggregate is inconsistent with unit counts")
        require(count(row, "bootstrap_seed") == 20260928
                and count(row, "bootstrap_draws") == (2000 if complete else 0)
                and (row["paired_b_minus_cneg_mean_pp"] != "") == complete
                and (row["bootstrap_ci_low_pp"] != "") == complete
                and (row["bootstrap_ci_high_pp"] != "") == complete,
                "The overall endpoint status and bootstrap fields disagree")


def verify_audit(data: dict[str, bytes]) -> dict:
    audit = load_json(data["evaluation_audit.json"])
    require(set(audit) == AUDIT_KEYS
            and audit.get("schema") == "mnms2_nnunet_external_evaluation_v1"
            and audit.get("status") == "PASS" and audit.get("rep") == "rep00"
            and audit.get("purpose") == "exploratory_additional_analysis_on_previously_used_held_out_vendors"
            and audit.get("models") == 20 and audit.get("cases_per_model") == 3072
            and audit.get("patients_per_model") == 141,
            "The evaluation audit is not the expected PASS rep00 run")
    require(isinstance(audit["created_utc"], str)
            and re.fullmatch(r"\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d(?:\.\d+)?\+00:00",
                             audit["created_utc"]) is not None
            and audit["thresholds"] == {
                "source_gt_png": ">127 of 0/255", "nnunet_prediction_png": ">0 of 0/1"}
            and audit["voxel_ml"] == "abs(det(original_GT_NIfTI_affine_3x3))/1000"
            and audit["ef_formula"] == "100*(EDV-ESV)/EDV; EDV<=1e-6 mL is invalid"
            and audit["dice_definition"] == "full_stack counts all slices; volume_present pools GT-positive slices; slice_present averages GT-positive slice Dice; empty-empty slice Dice=1"
            and audit["invalid_ef_policy"] == "Retained in private case rows and public denominators; no full-endpoint bootstrap if any invalid EF"
            and audit["bootstrap"] == {
                "seed": 20260928, "draws": 2000,
                "resampling": "training unit and vendor-stratified patient, preserving repeated patient measurements across units"},
            "The evaluation audit policy differs from the fixed public run")
    for field in ("evaluator_script_sha256", "manifest_sha256", "stage_audit_sha256",
                  "physical_input_audit_sha256"):
        digest(audit[field])
    for field in ("checkpoint_sha256", "prediction_inventories", "prediction_audit_sha256"):
        sha_map(audit[field], MODELS)
    expected = {*(f"private/{name}" for name in PRIVATE_CSVS),
                *(f"public/{name}" for name in PUBLIC_CSVS)}
    sha_map(audit["output_sha256"], expected)
    for name in PUBLIC_CSVS:
        require(hash_bytes(data[name]) == audit["output_sha256"][f"public/{name}"],
                "A public CSV differs from its evaluation audit SHA256")
    return audit


def verify_provenance(data: dict[str, bytes], audit: dict) -> None:
    provenance = load_json(data["provenance.json"])
    require(set(provenance) == PROVENANCE_KEYS
            and provenance.get("schema") == "mnms2_nnunet_r1_public_bundle_v1"
            and provenance.get("status") == "PASS"
            and provenance.get("scope") == "rep00; 10 paired units; 20 models; exploratory external analysis",
            "The bundle provenance has unexpected metadata")
    hashes = sha_map(provenance["copied_or_generated_files_sha256"], set(HASHED_FILES))
    for name in HASHED_FILES:
        require(hash_bytes(data[name]) == hashes[name],
                "A public file differs from its provenance SHA256")
    require(digest(provenance["evaluation_audit_sha256"])
            == hash_bytes(data["evaluation_audit.json"]),
            "The evaluation audit differs from its provenance SHA256")
    private = sha_map(provenance["private_evaluation_csv_sha256"], set(PRIVATE_CSVS))
    for name in PRIVATE_CSVS:
        require(private[name] == audit["output_sha256"][f"private/{name}"],
                "A private CSV hash differs between audit and provenance")
    for field in ("secondary_source_json_sha256", "outlier_source_json_sha256"):
        digest(provenance[field])
    for field in ("evaluator_script_sha256", "manifest_sha256", "stage_audit_sha256",
                  "physical_input_audit_sha256"):
        require(digest(provenance[field]) == audit[field],
                "A source hash differs between audit and provenance")
    models = provenance["model_artifact_sha256"]
    require(isinstance(models, dict) and set(models) == MODELS,
            "The model provenance inventory is incomplete")
    for model, entry in models.items():
        sha_map(entry, MODEL_ARTIFACT_KEYS)
        require(entry["checkpoint_final_sha256"] == audit["checkpoint_sha256"][model]
                and entry["external_prediction_inventory_sha256"] == audit["prediction_inventories"][model]
                and entry["external_prediction_audit_sha256"] == audit["prediction_audit_sha256"][model],
                "A model hash differs between audit and provenance")
    require(provenance["excluded_artifact_classes"] == [
        "private case and slice tables", "patient mappings", "source and prediction PNGs",
        "checkpoint bytes", "fixed split contents", "training and prediction logs"],
        "The bundle exclusion declaration differs")


def verify_secondary_and_outlier(data: dict[str, bytes], audit: dict) -> None:
    secondary = load_json(data["secondary_summary_public.json"])
    require(set(secondary) == {"status", "rep", "analysis", "audited_csv_sha256_verified",
                               "audit_evaluator_sha256", "models", "private_case_rows_read",
                               "bootstrap", "by_vendor"}
            and secondary["status"] == "PASS" and secondary["rep"] == "rep00"
            and secondary["analysis"] == "post_hoc_exploratory_R1_after_inspecting_EF"
            and secondary["models"] == 20 and secondary["private_case_rows_read"] == 2820
            and secondary["audited_csv_sha256_verified"] == 6
            and secondary["audit_evaluator_sha256"] == audit["evaluator_script_sha256"]
            and secondary["bootstrap"] == {
                "seed": 20260928, "draws": 2000,
                "ci": "percentile 95%; exploratory; no multiplicity adjustment"},
            "The secondary summary has unexpected metadata")
    by_vendor = secondary["by_vendor"]
    require(isinstance(by_vendor, list) and len(by_vendor) == 3,
            "The secondary vendor inventory is invalid")
    seen = set()
    for item in by_vendor:
        require(isinstance(item, dict)
                and set(item) == {"vendor", "unique_patients", "paired_unit_patient_evaluations",
                                  "metrics", "empty_gt_fp"},
                "A secondary vendor aggregate has unexpected fields")
        vendor = item["vendor"]
        require(vendor in VENDORS and vendor not in seen
                and item["unique_patients"] == VENDORS[vendor]
                and item["paired_unit_patient_evaluations"] == 10 * VENDORS[vendor],
                "A secondary vendor aggregate has an invalid denominator")
        seen.add(vendor)
        metrics = item["metrics"]
        require(isinstance(metrics, dict) and set(metrics) == SECONDARY_METRICS,
                "The secondary metric inventory is invalid")
        for entry in metrics.values():
            require(isinstance(entry, dict)
                    and set(entry) == {"b_mean", "cneg_mean", "b_minus_cneg_mean",
                                       "ci95", "unit_direction"},
                    "A secondary metric has unexpected fields")
            for field in ("b_mean", "cneg_mean", "b_minus_cneg_mean"):
                finite(entry[field])
            ci = entry["ci95"]
            require(isinstance(ci, list) and len(ci) == 2 and finite(ci[0]) <= finite(ci[1]),
                    "A secondary confidence interval is invalid")
            direction = entry["unit_direction"]
            require(isinstance(direction, dict) and set(direction) == {"b", "cneg", "tie"}
                    and all(type(value) is int and value >= 0 for value in direction.values())
                    and sum(direction.values()) == 10,
                    "A secondary unit direction is invalid")
        fp = item["empty_gt_fp"]
        require(isinstance(fp, dict) and set(fp) == {"ed", "es"},
                "The empty-reference phase inventory is invalid")
        for entry in fp.values():
            require(isinstance(entry, dict) and set(entry) == {
                "empty_gt_slices", "b_fp_slices", "cneg_fp_slices", "b_minus_cneg_fp_slices",
                "b_rate_pct", "cneg_rate_pct", "b_minus_cneg_rate_pp", "rate_diff_ci95_pp"},
                "An empty-reference aggregate has unexpected fields")
            for field in ("empty_gt_slices", "b_fp_slices", "cneg_fp_slices",
                          "b_minus_cneg_fp_slices"):
                require(type(entry[field]) is int, "An empty-reference count is invalid")
            require(entry["empty_gt_slices"] > 0
                    and 0 <= entry["b_fp_slices"] <= entry["empty_gt_slices"]
                    and 0 <= entry["cneg_fp_slices"] <= entry["empty_gt_slices"]
                    and entry["b_minus_cneg_fp_slices"]
                    == entry["b_fp_slices"] - entry["cneg_fp_slices"],
                    "An empty-reference count is inconsistent")
            for field in ("b_rate_pct", "cneg_rate_pct", "b_minus_cneg_rate_pp"):
                if entry[field] is not None:
                    finite(entry[field])
            ci = entry["rate_diff_ci95_pp"]
            require(isinstance(ci, list) and len(ci) == 2 and finite(ci[0]) <= finite(ci[1]),
                    "An empty-reference confidence interval is invalid")
    outlier = load_json(data["outlier_audit_public.json"])
    fixed = {
        "status": "PASS", "scope": "rep00 u03/B GE largest finite EF absolute error",
        "audited_csv_checksums_verified": 6, "prediction_PNG_inventory": "PASS",
        "manifest_stage_ED_ES_mapping": "PASS", "source_GT_PNG_and_NIfTI_affine": "PASS",
        "stored_slice_and_case_metrics_recomputed": "PASS",
    }
    require(set(outlier) == set(fixed) | {"extreme_B_u03_GE_case_counts", "target_volume_categories"}
            and all(outlier.get(key) == value for key, value in fixed.items()),
            "The outlier audit has unexpected metadata")
    counts = outlier["extreme_B_u03_GE_case_counts"]
    require(isinstance(counts, dict)
            and set(counts) == {"ef_abs_error_gt_100_pp", "ef_abs_error_gt_500_pp"}
            and all(type(value) is int and 0 <= value <= 53 for value in counts.values())
            and counts["ef_abs_error_gt_500_pp"] <= counts["ef_abs_error_gt_100_pp"],
            "The outlier aggregate counts are invalid")
    categories = outlier["target_volume_categories"]
    require(isinstance(categories, list) and len(categories) > 0
            and len(categories) == len(set(categories))
            and all(item in OUTLIER_CATEGORIES for item in categories),
            "The outlier category inventory is invalid")


def verify_bundle(path: Path, expected_sha256: str | None = None) -> str:
    if expected_sha256 is not None:
        expected_sha256 = digest(expected_sha256.lower())
    actual = hash_file(path)
    require(expected_sha256 is None or actual == expected_sha256,
            "The archive SHA256 differs from the independently recorded value")
    data = read_archive(path)
    audit = verify_audit(data)
    verify_provenance(data, audit)
    verify_csvs(data)
    verify_secondary_and_outlier(data, audit)
    return actual


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path, help="Downloaded nnUNet_r1_public_bundle_rep00.tar.gz")
    parser.add_argument("--expected-sha256", help="SHA256 recorded on the cloud before download")
    args = parser.parse_args()
    try:
        actual = verify_bundle(args.archive, args.expected_sha256)
    except (VerificationError, OSError, KeyError, TypeError, OverflowError) as exc:
        message = str(exc) if isinstance(exc, VerificationError) else "archive verification failed"
        print(f"BUNDLE VERIFY FAIL: {message}", file=sys.stderr)
        return 1
    print(f"BUNDLE VERIFY PASS: 7 allowed files; aggregate CSV rows 60/30/3; archive SHA256 {actual}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
