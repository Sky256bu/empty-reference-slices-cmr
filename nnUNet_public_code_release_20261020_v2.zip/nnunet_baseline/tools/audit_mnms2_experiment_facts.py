#!/usr/bin/env python3
"""Audit frozen partition, label-scope and anchor facts without reading images.

Default: read-only aggregate JSON on stdout. --write saves one NEW summary only.
No patient identifiers, source image paths, case rows, or medical images are exported.
Compatibility with a threshold is not evidence of a historical CLI invocation.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
from collections import Counter, defaultdict
from pathlib import Path

FROZEN_HASHES = {
    "manifest_mnms2.csv": "fd9f2eba74f0adba7eff7a11c80e856d49e9aebcdcda17920f4e491d2e7f7a24",
    "patient_partitions_v3.csv": "30b0f21fb0e75e969f1e3fc109dc480b5f4e2c70e9e1a4d5dcf4316da8b78e82",
    "label_scope_audit_v3.csv": "5c4f32f1275fa4c2477631c723d0e7debfa65dee00db9e46f6a66855e2448103",
}
UNITS = tuple(f"u{i:02d}" for i in range(10))
BLOCKS = ("d00",) + UNITS
EXPECTED_ROLES = {"validation": 43, "development": 10, "formal": 100, "unused": 66}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_csv(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def norm_key(value: object) -> str:
    text = str(value).strip()
    try:
        return str(int(float(text))).zfill(3)
    except ValueError:
        return text


def key_sha256(keys: set[str]) -> str:
    return hashlib.sha256(",".join(sorted(keys)).encode("utf-8")).hexdigest()


def audit_tables(manifest: list[dict], partition: list[dict], scopes: list[dict]) -> dict:
    """Pure aggregate audit; also used by synthetic tests (not empirical evidence)."""
    failures: list[str] = []
    role_keys: dict[str, set[str]] = defaultdict(set)
    block_keys: dict[str, set[str]] = defaultdict(set)
    partition_keys = [norm_key(row["key"]) for row in partition]
    duplicate_partition_rows = len(partition_keys) - len(set(partition_keys))
    role_counts = dict(Counter(row["role"] for row in partition))
    invalid_role_block_rows = 0
    for row in partition:
        key, role, block = norm_key(row["key"]), row["role"], row["block_id"]
        role_keys[role].add(key)
        if block:
            block_keys[block].add(key)
        correct = ((role == "formal" and block in UNITS)
                   or (role == "development" and block == "d00")
                   or (role in {"validation", "unused"} and not block))
        invalid_role_block_rows += not correct
    if len(partition) != 219 or duplicate_partition_rows or role_counts != EXPECTED_ROLES:
        failures.append("partition_inventory_or_role_counts")
    if invalid_role_block_rows or set(block_keys) != set(BLOCKS):
        failures.append("partition_role_block_assignment")
    if any(len(block_keys[b]) != 10 for b in BLOCKS):
        failures.append("training_block_patient_count")
    role_overlap_counts = {
        f"{a}_vs_{b}": len(role_keys[a] & role_keys[b])
        for i, a in enumerate(EXPECTED_ROLES) for b in list(EXPECTED_ROLES)[i + 1:]
    }
    block_overlaps = {
        f"{a}_vs_{b}": len(block_keys[a] & block_keys[b])
        for i, a in enumerate(BLOCKS) for b in BLOCKS[i + 1:]
    }
    if any(role_overlap_counts.values()) or any(block_overlaps.values()):
        failures.append("patient_overlap")

    stacks: dict[tuple[str, str], list[dict]] = defaultdict(list)
    records: dict[str, list[dict]] = defaultdict(list)
    slice_ids: set[tuple[str, str, int]] = set()
    duplicate_slices = invalid_flags = invalid_phases = invalid_gt_counts = 0
    for source in manifest:
        row = dict(source)
        row["key"] = norm_key(row["key"])
        row["phase"] = row["phase"].lower()
        for name in ("z", "is_anchor", "in_lvspan", "gt_px", "dist"):
            row[name] = int(row[name])
        invalid_flags += row["is_anchor"] not in (0, 1) or row["in_lvspan"] not in (0, 1)
        invalid_phases += row["phase"] not in {"ed", "es"}
        invalid_gt_counts += row["gt_px"] < 0
        sid = (row["key"], row["phase"], row["z"])
        duplicate_slices += sid in slice_ids
        slice_ids.add(sid)
        records[row["key"]].append(row)
        stacks[(row["key"], row["phase"])].append(row)
    siemens_keys = {key for key, rows in records.items()
                    if all("siemens" in row["vendor"].lower() for row in rows)}
    manifest_vendors_inconsistent = sum(
        len({row["vendor"].strip().lower() for row in rows}) != 1 for rows in records.values())
    phase_incomplete_patients = sum(
        {row["phase"] for row in rows} != {"ed", "es"} for rows in records.values())
    if set(partition_keys) != siemens_keys:
        failures.append("partition_vs_siemens_manifest_patient_set")
    if any((duplicate_slices, invalid_flags, invalid_phases, invalid_gt_counts,
            manifest_vendors_inconsistent, phase_incomplete_patients)):
        failures.append("manifest_integrity")

    anchor_mismatches = span_mismatches = dist_mismatches = 0
    fallback_stacks = positive_outside = 0
    for rows in stacks.values():
        qualifying_z = sorted(row["z"] for row in rows if row["gt_px"] >= 15)
        sufficient = len(qualifying_z) >= 3
        fallback_stacks += not sufficient
        lo, hi = (qualifying_z[0], qualifying_z[-1]) if sufficient else (None, None)
        for row in rows:
            z = row["z"]
            expected_span = int(sufficient and lo <= z <= hi)
            expected_anchor = int(sufficient and z in (lo, hi))
            expected_dist = min(z - lo, hi - z) if expected_span else -1
            anchor_mismatches += row["is_anchor"] != expected_anchor
            span_mismatches += row["in_lvspan"] != expected_span
            dist_mismatches += row["dist"] != expected_dist
            positive_outside += row["in_lvspan"] == 0 and row["gt_px"] > 0
    if any((anchor_mismatches, span_mismatches, dist_mismatches)):
        failures.append("threshold15_anchor_span_dist_compatibility")

    scope_index: dict[tuple[str, str], list[dict]] = defaultdict(list)
    for row in scopes:
        scope_index[(row["block_id"], row["arm"])].append(row)
    expected_scopes = {(block, arm) for block in BLOCKS for arm in ("B", "Cneg")}
    if len(scopes) != 22 or set(scope_index) != expected_scopes:
        failures.append("label_scope_inventory")
    scope_mismatch_rows = 0
    gt_scope_differences = 0
    unit_summaries = []
    validation_rows = sum(len(records[key]) for key in role_keys["validation"])
    for block in BLOCKS:
        keys = block_keys[block]
        gt_scope: dict[str, set] = {"B": set(), "Cneg": set()}
        counts: dict[str, dict] = {}
        for arm in ("B", "Cneg"):
            gt_rows = pf_rows = internal_rows = 0
            for key in keys:
                for row in records[key]:
                    sid = (key, row["phase"], row["z"])
                    if row["is_anchor"] == 1 or row["in_lvspan"] == 0:
                        gt_rows += 1
                        gt_scope[arm].add(sid)
                    elif arm == "B":
                        pf_rows += 1
                        internal_rows += 1
            actual = {"train_patients": len(keys), "label_rows": gt_rows + pf_rows,
                      "gt_rows": gt_rows, "pf_rows": pf_rows,
                      "internal_nonanchor_rows": internal_rows,
                      "block_key_sha256": key_sha256(keys),
                      "role": "development" if block == "d00" else "formal"}
            matching = scope_index.get((block, arm), [])
            mismatch = len(matching) != 1
            if not mismatch:
                frozen = matching[0]
                for field, value in actual.items():
                    observed = int(frozen[field]) if isinstance(value, int) else frozen[field]
                    mismatch |= observed != value
            scope_mismatch_rows += mismatch
            counts[arm] = {name: actual[name] for name in
                           ("label_rows", "gt_rows", "pf_rows", "internal_nonanchor_rows")}
        gt_scope_differences += len(gt_scope["B"] ^ gt_scope["Cneg"])
        unit_summaries.append({"block_id": block, "role": actual["role"],
                               "train_patients": len(keys),
                               "validation_patient_overlap": len(keys & role_keys["validation"]),
                               "development_patient_overlap": len(keys & role_keys["development"])
                               if block != "d00" else 0,
                               "block_key_sha256": key_sha256(keys),
                               "B": counts["B"], "Cneg": counts["Cneg"]})
    if scope_mismatch_rows or gt_scope_differences:
        failures.append("label_scope_recomputation")
    return {
        "status": "PASS" if not failures else "FAIL", "failures": failures,
        "partition": {"rows": len(partition), "unique_patients": len(set(partition_keys)),
                      "duplicate_patient_rows": duplicate_partition_rows, "role_counts": role_counts,
                      "invalid_role_block_rows": invalid_role_block_rows,
                      "pairwise_role_overlap_counts": role_overlap_counts,
                      "pairwise_training_block_overlap_counts": block_overlaps},
        "manifest": {"rows": len(manifest), "patients": len(records), "phase_stacks": len(stacks),
                     "siemens_patients": len(siemens_keys), "duplicate_slice_rows": duplicate_slices,
                     "invalid_flags": invalid_flags, "invalid_phases": invalid_phases,
                     "invalid_gt_counts": invalid_gt_counts,
                     "inconsistent_vendor_patients": manifest_vendors_inconsistent,
                     "phase_incomplete_patients": phase_incomplete_patients,
                     "validation_gt_slices": validation_rows},
        "anchor_compatibility": {
            "min_gt_pixels": 15, "minimum_qualifying_slices_for_anchors": 3,
            "rule": "With >=3 qualifying slices, first/last qualifying z are anchors and inclusive span; otherwise no anchors and no span.",
            "threshold_compatible": not any((anchor_mismatches, span_mismatches, dist_mismatches)),
            "historical_cli_threshold_proven": False,
            "anchor_mismatch_rows": anchor_mismatches, "span_mismatch_rows": span_mismatches,
            "dist_mismatch_rows": dist_mismatches, "fewer_than_three_qualifying_stacks": fallback_stacks,
            "outside_span_rows_with_positive_gt_pixels": positive_outside,
            "interpretation": "Outside-span supervision is GT; outside-span does not necessarily mean exactly zero foreground."},
        "label_scope": {"audited_rows": len(scopes), "scope_mismatch_rows": scope_mismatch_rows,
                        "B_Cneg_gt_scope_symmetric_difference_rows": gt_scope_differences,
                        "blocks": unit_summaries},
        "limitations": ["Aggregate metadata audit only; images and masks are not opened.",
                        "Current frozen-table compatibility does not reconstruct historical command lines.",
                        "No patient identifiers or source file paths are included in this report."]}


def audit(mroot: Path) -> dict:
    audit_dir = mroot / "scope_control_v3_zero_gpu_audit"
    paths = {"manifest_mnms2.csv": mroot / "manifest_mnms2.csv",
             **{name: audit_dir / name for name in
                ("patient_partitions_v3.csv", "label_scope_audit_v3.csv", "input_audit_summary_v3.json")}}
    hashes = {name: sha256(path) for name, path in paths.items()}
    input_audit = json.loads(paths["input_audit_summary_v3.json"].read_text(encoding="utf-8"))
    failures = ["frozen_hash_mismatch:" + name for name, expected in FROZEN_HASHES.items()
                if hashes[name] != expected]
    if input_audit.get("status") != "PASS":
        failures.append("input_audit_not_PASS")
    if input_audit.get("manifest_sha256") != hashes["manifest_mnms2.csv"]:
        failures.append("input_audit_manifest_link")
    for name in ("patient_partitions_v3.csv", "label_scope_audit_v3.csv"):
        if input_audit.get("outputs", {}).get(name, {}).get("sha256") != hashes[name]:
            failures.append("input_audit_output_link:" + name)
    result = audit_tables(read_csv(paths["manifest_mnms2.csv"]),
                          read_csv(paths["patient_partitions_v3.csv"]),
                          read_csv(paths["label_scope_audit_v3.csv"]))
    result["failures"] = failures + result["failures"]
    result["status"] = "PASS" if not result["failures"] else "FAIL"
    result["source_sha256"] = hashes
    result["schema_version"] = 1
    result["scope"] = "frozen experiment metadata: patient partitions, label scopes, threshold compatibility"
    return result


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mroot", type=Path, default=Path("/root/autodl-tmp/mnms/seg_lv"))
    parser.add_argument("--output-dir", type=Path,
                        default=Path("/root/autodl-tmp/experiment_facts_audit_20261020"))
    parser.add_argument("--write", action="store_true")
    args = parser.parse_args(argv)
    result = audit(args.mroot)
    output = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    print(output, end="")
    if result["status"] != "PASS":
        return 1
    if args.write:
        destination = args.output_dir.expanduser().resolve()
        if destination.is_relative_to(args.mroot.expanduser().resolve()):
            parser.error("Output directory must be outside the source export root")
        destination.mkdir(parents=True, exist_ok=True)
        with (destination / "summary_public.json").open("x", encoding="utf-8", newline="\n") as stream:
            stream.write(output)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
