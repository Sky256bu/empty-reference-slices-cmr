#!/usr/bin/env python3
"""Read-only recomputation of Fig. 4 from the frozen ACDC stack table.

Only --write creates a NEW output directory; existing outputs are never replaced.
No source, prediction, image, metric definition, or patient-level output is changed.
Requires Python 3 and NumPy. main(argv) is callable after import/exec.
"""
import argparse
import csv
import hashlib
import io
import json
import math
from pathlib import Path

import numpy as np

SOURCE_SHA256 = "d29f91f36fb67a4e7554767631ac4ad8fa26ae9a82efb688e6eb428fe7ff7dae"
EXPECTED_SHA256 = "2da74fcf6c9351d4be42f51d45dbb7567160768030ca0aba31fddf730fb5e76b"
DEFAULT_SOURCE = "/root/autodl-tmp/acdc_step06_freeze_20260725/stack_dice_acdc_clean.csv"
DEFAULT_OUTPUT = "/root/autodl-tmp/fig4_source_audit_20261020"
EXPECTED_CSV = """phase,arm,N,p25,p50,p75
ed,A,5,0.0,0.0,0.0
ed,A,10,0.0,0.0,0.0
ed,A,15,0.0,0.0,0.0
ed,A,25,0.0,0.0,0.0
ed,A,50,0.0,0.0,0.0
ed,A,100,0.0,0.0,0.0
ed,B,5,0.0,0.0,0.0
ed,B,10,0.0,0.0,0.0
ed,B,15,0.0,0.0,0.0
ed,B,25,0.0,0.0,0.0
ed,B,50,0.0,0.0,33.5
ed,B,100,0.0,0.0,0.0
ed,C,5,0.0,0.0,0.0
ed,C,10,0.0,0.0,0.0
ed,C,15,0.0,0.0,0.0
ed,C,25,0.0,0.0,9.0
ed,C,50,0.0,0.0,41.0
ed,C,100,0.0,0.0,35.5
ed,I,5,0.0,0.0,0.0
ed,I,10,0.0,0.0,0.0
ed,I,15,0.0,0.0,26.25
es,A,5,0.0,834.5,1518.5
es,A,10,0.0,7.5,1056.0
es,A,15,0.0,42.0,910.75
es,A,25,0.0,31.0,591.0
es,A,50,0.0,51.0,797.75
es,A,100,0.0,33.0,746.25
es,B,5,0.0,1055.5,1893.0
es,B,10,0.0,323.0,1184.75
es,B,15,0.0,0.0,624.75
es,B,25,0.0,228.5,1090.0
es,B,50,0.0,844.5,1307.0
es,B,100,0.0,91.0,518.25
es,C,5,0.0,865.5,1600.75
es,C,10,0.0,1051.0,1695.75
es,C,15,0.0,942.5,1428.0
es,C,25,0.0,864.0,1472.0
es,C,50,0.0,950.5,1467.5
es,C,100,0.0,906.0,1385.75
es,I,5,0.0,1174.0,1801.25
es,I,10,0.0,1210.0,2018.0
es,I,15,0.0,699.0,1567.0
"""
SOURCE_COLUMNS = ["key", "phase", "inter", "gt", "pred", "present_dice", "empty_fp", "stack_dice", "arm", "N", "seed", "tag", "alias"]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def expected_rows():
    require(sha256_bytes(EXPECTED_CSV.encode("utf-8")) == EXPECTED_SHA256,
            "Embedded Fig4 reference bytes failed SHA256 check")
    return list(csv.DictReader(io.StringIO(EXPECTED_CSV)))


def summarize_rows(rows, expected):
    """Pure in-memory audit. Public results never contain patient keys."""
    require(len(rows) == 6300, "Frozen source must contain exactly 6300 rows")
    expected_keys = {(r["phase"], r["arm"], int(r["N"])) for r in expected}
    require(len(expected_keys) == 42 and len(expected) == 42,
            "Expected source must contain exactly 42 unique groups")
    by_seed, seen, seeds = {}, set(), set()
    for row in rows:
        phase, arm, budget = row["phase"], row["arm"], int(row["N"])
        seed, key = row["seed"], row["key"]
        require(bool(seed) and bool(key), "Source contains an empty seed or patient key")
        require((phase, arm, budget) in expected_keys, "Unexpected phase/arm/budget group")
        identity = (key, phase, arm, budget, seed)
        require(identity not in seen, "Duplicate patient/phase/arm/budget/seed row")
        seen.add(identity)
        value = float(row["empty_fp"])
        require(math.isfinite(value) and value >= 0, "empty_fp must be finite and nonnegative")
        seeds.add(seed)
        by_seed.setdefault((phase, arm, budget, seed), {})[key] = value
    require(len(seeds) == 3 and len(by_seed) == 126, "Expected three seeds and 126 seed groups")
    seed_order = sorted(seeds)
    per_seed, pooled, median_map = [], [], {}
    max_abs_difference = 0.0
    for ref in expected:
        group = (ref["phase"], ref["arm"], int(ref["N"]))
        patient_sets, all_values = [], []
        for seed in seed_order:
            cells = by_seed.get(group + (seed,), {})
            require(len(cells) == 50, "Each seed group must contain 50 unique patients")
            patient_sets.append(set(cells))
            values = list(cells.values())
            q = np.percentile(values, [25, 50, 75], method="linear")
            record = dict(phase=group[0], arm=group[1], N=group[2], seed=seed,
                          n=50, p25=float(q[0]), p50=float(q[1]), p75=float(q[2]))
            per_seed.append(record)
            median_map[group + (seed,)] = record["p50"]
            all_values.extend(values)
        require(patient_sets[0] == patient_sets[1] == patient_sets[2],
                "Patient sets must match across the three seeds within each pooled group")
        require(len(all_values) == 150, "Each pooled group must contain 150 observations")
        q = np.percentile(all_values, [25, 50, 75], method="linear")
        target = np.array([float(ref[k]) for k in ("p25", "p50", "p75")])
        delta = float(np.max(np.abs(q - target)))
        max_abs_difference = max(max_abs_difference, delta)
        require(bool(np.allclose(q, target, rtol=0, atol=1e-9)),
                "Pooled percentile mismatch for %s/%s/N%d" % group)
        pooled.append(dict(phase=group[0], arm=group[1], N=group[2], n=150,
                           unique_patients=50, seeds=3,
                           p25=float(q[0]), p50=float(q[1]), p75=float(q[2])))
    ordering = []
    for phase in ("ed", "es"):
        for budget in (5, 10, 15, 25, 50, 100):
            for seed in seed_order:
                a, b, c = [median_map[(phase, arm, budget, seed)] for arm in ("A", "B", "C")]
                ordering.append(dict(phase=phase, N=budget, seed=seed,
                                     A_p50=a, B_p50=b, C_p50=c,
                                     strict_A_lt_B_lt_C=(a < b < c)))
    summary = dict(
        status="PASS", metric="empty_fp", metric_units="foreground pixels on reference-empty slices, summed per patient-phase stack",
        source_rows=6300, unique_patient_phase_arm_budget_seed_rows=len(seen),
        seed_groups=126, patients_per_seed_group=50, pooled_groups=42,
        observations_per_pooled_group=150, unique_patients_per_pooled_group=50,
        seeds_per_pooled_group=3, patient_sets_identical_across_seeds=True,
        percentile_method="numpy.percentile(method='linear')",
        compared_numeric_cells=126, max_absolute_percentile_difference=max_abs_difference,
        reference_percentiles_match=True,
        interpretation="The plotted quartiles pool 50 patient observations across three seeds (150 observations), not 150 independent patients and not quartiles of three seed summaries.",
        es_N100_per_seed=[r for r in per_seed if r["phase"] == "es" and r["N"] == 100 and r["arm"] in ("A", "B", "C")],
        median_ordering_by_phase_budget_seed=ordering,
        no_patient_keys_in_outputs=True,
        limitation="This audit checks frozen table aggregation and descriptive ordering; it does not independently audit prediction masks or establish a universal seed-level ordering.",
    )
    return summary, per_seed, pooled


def csv_bytes(records):
    buffer = io.StringIO(newline="")
    writer = csv.DictWriter(buffer, fieldnames=list(records[0]), lineterminator="\n")
    writer.writeheader()
    writer.writerows(records)
    return buffer.getvalue().encode("utf-8")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", default=DEFAULT_SOURCE)
    parser.add_argument("--output", default=DEFAULT_OUTPUT)
    parser.add_argument("--write", action="store_true")
    args = parser.parse_args(argv)
    reference = expected_rows()
    raw = Path(args.source).read_bytes()
    require(sha256_bytes(raw) == SOURCE_SHA256, "Frozen source SHA256 mismatch; no audit outputs written")
    reader = csv.DictReader(io.StringIO(raw.decode("utf-8-sig")))
    require(reader.fieldnames == SOURCE_COLUMNS, "Frozen source column schema mismatch")
    summary, per_seed, pooled = summarize_rows(list(reader), reference)
    summary.update(source_sha256=SOURCE_SHA256, expected_fig4_csv_sha256=EXPECTED_SHA256,
                   numpy_version=np.__version__, source_files_modified=False,
                   output_mode="new-directory-only" if args.write else "read-only")
    payloads = {
        "fig4_source_audit_public.json": (json.dumps(summary, ensure_ascii=False, indent=2) + "\n").encode("utf-8"),
        "fig4_per_seed_summary_public.csv": csv_bytes(per_seed),
        "fig4_pooled_recomputed_public.csv": csv_bytes(pooled),
    }
    if args.write:
        output = Path(args.output)
        require(not output.exists(), "Output already exists; no overwriting is permitted")
        require(output.parent.is_dir(), "Output parent directory must already exist")
        output.mkdir(exist_ok=False)
        for name, data in payloads.items():
            with (output / name).open("xb") as handle:
                handle.write(data)
        manifest = "".join(sha256_bytes(data) + "  " + name + "\n" for name, data in payloads.items())
        with (output / "SHA256SUMS.txt").open("x", encoding="utf-8", newline="\n") as handle:
            handle.write(manifest)
    console_summary = {key: value for key, value in summary.items()
                       if key not in ("median_ordering_by_phase_budget_seed", "es_N100_per_seed")}
    console_summary["es_N100_seed_medians"] = [row for row in summary["median_ordering_by_phase_budget_seed"]
                                             if row["phase"] == "es" and row["N"] == 100]
    console_summary["es_strict_A_lt_B_lt_C_seeds_per_budget"] = {
        str(budget): sum(row["strict_A_lt_B_lt_C"] for row in summary["median_ordering_by_phase_budget_seed"]
                        if row["phase"] == "es" and row["N"] == budget)
        for budget in (5, 10, 15, 25, 50, 100)}
    print(json.dumps(console_summary, ensure_ascii=False, indent=2))
    print("PASS: 126 Fig4 percentile cells reproduced; " + ("new anonymous audit files saved." if args.write else "read-only; no files written."))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
