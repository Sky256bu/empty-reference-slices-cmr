#!/usr/bin/env python3
"""Collect an author-only current nnU-Net source/config snapshot, without training.

Default: read-only preflight. --write creates new files only. No patient rows,
images, model weights, logs, split contents, environment dumps or audit rows are
copied. Exact source bytes are retained; this is not public-release approval.
"""
from __future__ import annotations

import argparse
import base64
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path, PurePosixPath
import platform
import re
import stat
import sys
import zipfile

SNAPSHOT_NAME = "nnUNet_source_snapshot_20261020"
REFERENCE = "nnUNet_preprocessed/Dataset900_MnMS2_CommonPlan_u00_GT"
CONFIGS = {
    "nnUNetPlans.json": "99e7f68f6a700511d41d0e69e9226ad2a8e8e3ffe36eac79d2140c339afe3bae",
    "dataset_fingerprint.json": "cde585fbb93653bcc9b7c9f5454b8e9372da2b184fa40381748fad8354138671",
}
SCRIPTS = (
    "prepare_mnms2_nnunet2d.py", "verify_mnms2_nnunet2d_pair.py",
    "prepare_all_mnms2_nnunet2d.py", "prepare_mnms2_clean_planning_dataset.py",
    "stage_mnms2_shared_nnunet2d_plan.py", "preprocess_mnms2_shared_nnunet2d.py",
    "benchmark_mnms2_nnunet2d_u00.py", "train_mnms2_nnunet2d_formal.py",
    "summarize_mnms2_nnunet2d_formal.py", "stage_mnms2_nnunet_external.py",
    "run_mnms2_nnunet_external.py", "evaluate_mnms2_nnunet_external.py",
    "diagnose_mnms2_nnunet_external.py", "analyze_mnms2_nnunet_external_secondary.py",
    "audit_mnms2_nnunet_external_outlier.py", "audit_mnms2_nnunet_external_full.py",
    "audit_mnms2_nnunet_external_full_v2.py", "package_mnms2_nnunet_r1_public.py",
    "verify_mnms2_nnunet_r1_public_bundle.py", "probe_mnms2_nnunet_env.py",
    "setup_mnms2_nnunet_gpu.sh", "activate_mnms2_nnunet.sh",
    "run_mnms2_u03_u06.sh", "run_mnms2_u07_u09.sh",
)
# Helpers imported by essential entry points are also essential. Historical
# convenience launchers/checkers may never have been uploaded to this instance.
OPTIONAL_SCRIPTS = frozenset({
    "benchmark_mnms2_nnunet2d_u00.py", "verify_mnms2_nnunet_r1_public_bundle.py",
    "probe_mnms2_nnunet_env.py", "setup_mnms2_nnunet_gpu.sh",
    "activate_mnms2_nnunet.sh", "run_mnms2_u03_u06.sh", "run_mnms2_u07_u09.sh",
})
PACKAGES = (
    "nnunetv2", "torch", "dynamic-network-architectures", "numpy", "scipy",
    "nibabel", "Pillow", "SimpleITK", "scikit-image", "pandas", "matplotlib",
    "acvl-utils", "batchgenerators", "batchgeneratorsv2", "tifffile", "scikit-learn",
)
PLAN_KEYS = frozenset({
    "dataset_name", "plans_name", "original_median_spacing_after_transp",
    "original_median_shape_after_transp", "image_reader_writer", "transpose_forward",
    "transpose_backward", "configurations", "experiment_planner_used", "label_manager",
    "foreground_intensity_properties_per_channel",
})
FINGERPRINT_KEYS = frozenset({
    "spacings", "shapes_after_crop", "foreground_intensity_properties_per_channel",
    "median_relative_size_after_cropping",
})
FORBIDDEN_KEY = re.compile(
    r"(?i)(?:patient|subject|case)(?:_?(?:id|key|name|rows?|list|mapping|ids))?$|"
    r"(?:password|passwd|secret|token|credential|authorization|cookie|api_key|"
    r"private_map|absolute_path|source_path|filename|file_name)$"
)
SHA_RE = re.compile(r"[0-9a-f]{64}\Z")


def require(condition: bool, code: str) -> None:
    if not condition:
        raise RuntimeError(code)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def encoded(value: object) -> bytes:
    return (json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8")


def safe_member(name: str) -> str:
    require(isinstance(name, str) and bool(name), "archive_member_empty")
    require("\\" not in name and ":" not in name and "\x00" not in name,
            "archive_member_unsafe_separator")
    path = PurePosixPath(name)
    require(not path.is_absolute() and ".." not in path.parts
            and str(path) == name and not name.endswith("/"), "archive_member_unsafe_path")
    return name


def read_exact(base: Path, relative: str, limit: int = 2_000_000) -> bytes:
    safe_member(relative)
    candidate = base / relative
    require(not candidate.is_symlink(), "source_symlink_rejected")
    path = candidate.resolve(strict=True)
    require(path.is_relative_to(base.resolve()), "source_outside_base")
    require(path.is_file(), "source_not_regular_file")
    before = path.stat()
    require(before.st_size <= limit, "source_size_limit")
    result = path.read_bytes()
    after = path.stat()
    require((before.st_ino, before.st_size, before.st_mtime_ns)
            == (after.st_ino, after.st_size, after.st_mtime_ns)
            and len(result) == after.st_size, "source_changed_during_read")
    return result


def scan_text(data: bytes) -> None:
    text = data.decode("utf-8-sig")
    require("\x00" not in text, "text_contains_nul")
    patterns = (
        r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----",
        r"(?i)https?://[^/\s:@]+:[^/\s@]+@",
        r"(?i)[?&](?:token|access_token|api_key|password)=[^&\s\"']+",
        r"(?i)(?:api[_-]?key|access[_-]?token|password|passwd|client[_-]?secret|"
        r"authorization|cookie)\s*[:=]\s*['\"][^'\"\r\n]+['\"]",
        r"\bcase_[0-9a-f]{20}\b",
    )
    require(not any(re.search(pattern, text) for pattern in patterns),
            "possible_secret_or_concrete_case_identifier")


def inspect_config(filename: str, data: bytes) -> dict:
    scan_text(data)
    value = json.loads(data.decode("utf-8-sig"))
    require(isinstance(value, dict), "config_not_object")
    allowed = PLAN_KEYS if filename == "nnUNetPlans.json" else FINGERPRINT_KEYS
    require(set(value).issubset(allowed), "config_unreviewed_top_level_key")

    def walk(item: object) -> None:
        if isinstance(item, dict):
            for key, child in item.items():
                require(isinstance(key, str) and not FORBIDDEN_KEY.search(key),
                        "config_identifier_or_credential_key")
                walk(child)
        elif isinstance(item, list):
            for child in item:
                walk(child)
        elif isinstance(item, str):
            require(not re.search(r"(?:https?://|^/|^[A-Za-z]:[\\/]|\\\\)", item),
                    "config_path_or_url_value")
        elif item is not None:
            require(isinstance(item, (int, float, bool)), "config_value_type")

    walk(value)
    result = {"top_level_keys": sorted(value), "structural_privacy_scan": "PASS"}
    if filename == "nnUNetPlans.json":
        require(value.get("dataset_name") == "Dataset900_MnMS2_CommonPlan_u00_GT",
                "reference_plan_identity")
        config = value.get("configurations", {}).get("2d")
        require(isinstance(config, dict), "reference_plan_2d_missing")
        result["shared_2d"] = {key: config.get(key) for key in (
            "patch_size", "batch_size", "spacing", "normalization_schemes", "use_mask_for_norm")}
        architecture = config.get("architecture", {})
        result["shared_2d"]["architecture_class"] = (
            architecture.get("network_class_name") if isinstance(architecture, dict) else None)
    else:
        require({"spacings", "shapes_after_crop"}.issubset(value),
                "fingerprint_required_keys")
        result["spacings_entries"] = len(value["spacings"])
        result["shapes_entries"] = len(value["shapes_after_crop"])
        result["note"] = "Exact training-derived arrays retained in author-only config; not reproduced in this summary."
    return result


def compare_audits(base: Path, paths: list[str], field: str,
                   current_sha: str, expected: int) -> dict:
    counts: Counter = Counter()
    recorded: Counter = Counter()
    audit_hashes: list[str] = []
    for relative in paths:
        if not (base / relative).exists():
            counts["missing_audit"] += 1
            continue
        data = read_exact(base, relative)
        audit_hashes.append(sha(data))
        value = json.loads(data.decode("utf-8-sig"))
        require(isinstance(value, dict), "historical_audit_not_object")
        if value.get("status") == "PASS":
            counts["audit_status_pass"] += 1
        digest = value.get(field)
        if not isinstance(digest, str) or not SHA_RE.fullmatch(digest):
            counts["missing_or_invalid_recorded_hash"] += 1
        else:
            recorded[digest] += 1
            counts["entry_hash_match" if digest == current_sha else "entry_hash_mismatch"] += 1
    return {
        "expected_audits": expected, "audits_read": len(audit_hashes),
        "current_entry_script_sha256": current_sha, "recorded_hash_field": field,
        "counts": {key: counts[key] for key in (
            "audit_status_pass", "entry_hash_match", "entry_hash_mismatch",
            "missing_audit", "missing_or_invalid_recorded_hash")},
        "recorded_entry_hash_counts": dict(sorted(recorded.items())),
        "audit_file_sha256_sorted": sorted(audit_hashes),
    }


def historical_summary(base: Path, sources: dict[str, bytes]) -> dict:
    names = [f"u{i:02d}_{arm}.json" for i in range(10) for arm in ("B", "Cneg")]
    return {
        "formal_initial_entry_only": compare_audits(base, [
            f"nnUNet_results_formal/rep00/_audit/{name}" for name in names],
            "initial_script_sha256", sha(sources["scripts/train_mnms2_nnunet2d_formal.py"]), 20),
        "external_prediction_entry": compare_audits(base, [
            f"nnUNet_external_predictions/rep00/_audit/{name}" for name in names],
            "script_sha256", sha(sources["scripts/run_mnms2_nnunet_external.py"]), 20),
        "external_evaluation_entry": compare_audits(base, [
            "nnUNet_external_evaluation/rep00/public/evaluation_audit.json"],
            "evaluator_script_sha256", sha(sources["scripts/evaluate_mnms2_nnunet_external.py"]), 1),
        "limitation": "Entry-script hash matches do not establish all historical dependency bytes or per-attempt code; helpers remain current snapshots.",
    }


def package_versions() -> dict:
    versions = {}
    for name in PACKAGES:
        try:
            version = importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            version = None
        if version is not None:
            require(bool(re.fullmatch(r"[A-Za-z0-9.+!_\-]+", version)), "package_version_unusual")
        versions[name] = version
    return {"scope": "Current collector interpreter; not historical training environment proof",
            "python_version": platform.python_version(), "packages": versions}


def collect(base: Path) -> tuple[dict[str, bytes], dict, dict]:
    payloads: dict[str, bytes] = {}
    records: list[dict] = []
    config_summary = {}
    for name, expected in CONFIGS.items():
        data = read_exact(base, f"{REFERENCE}/{name}")
        require(sha(data) == expected, "frozen_reference_config_sha256_mismatch")
        config_summary[name] = inspect_config(name, data)
        member = f"config/{name}"
        payloads[member] = data
        records.append({"member": member, "source_relative": f"{REFERENCE}/{name}",
                        "bytes": len(data), "sha256": sha(data), "status": "frozen_reference_hash_match"})
    for name in SCRIPTS:
        if not (base / name).exists():
            require(name in OPTIONAL_SCRIPTS, "essential_script_missing:" + name)
            records.append({"member": f"scripts/{name}", "source_relative": name,
                            "bytes": None, "sha256": None, "status": "optional_absent"})
            continue
        data = read_exact(base, name)
        scan_text(data)
        member = f"scripts/{name}"
        payloads[member] = data
        records.append({"member": member, "source_relative": name,
                        "bytes": len(data), "sha256": sha(data), "status": "current_cloud_snapshot"})
    own = Path(__file__).resolve()
    own_data = read_exact(own.parent, own.name)
    scan_text(own_data)
    own_member = "scripts/archive_mnms2_nnunet_sources.py"
    payloads[own_member] = own_data
    records.append({"member": own_member, "source_relative": "collector_running_file",
                    "bytes": len(own_data), "sha256": sha(own_data), "status": "collector_source_snapshot"})
    history = historical_summary(base, payloads)
    manifest = {
        "schema": "mnms2_nnunet_author_source_snapshot_v1",
        "status": "CURRENT_SNAPSHOT_COLLECTED_WITH_SCOPED_HISTORY_COMPARISON",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "visibility": "author_only_not_public_release_approval",
        "scope": "rep00 additional nnU-Net baseline source/config; no retraining or source mutation",
        "requested_runtime_scripts": len(SCRIPTS),
        "present_runtime_scripts": sum(r["status"] == "current_cloud_snapshot" for r in records),
        "sources": records, "config_summary": config_summary, "historical_entry_comparison": history,
        "excluded": ["private case/slice rows", "patient mappings", "split contents", "images",
                     "weights", "logs", "audit rows", "environment dumps", "pip configuration"],
        "limitations": [
            "Snapshot is current source, not blanket proof of historical executed dependency versions.",
            "Formal initial script hash binds initial entry only, not every resumed attempt.",
            "Reference plan hash is not the byte hash of dataset-specific moved target plans.",
            "Exact fingerprint contains training-derived geometry arrays; retain author-only until release review.",
            "No source spatial units, clinical phase correctness or model performance claim is established here.",
            "Frozen private data inputs are required for end-to-end execution and are intentionally not included.",
        ],
    }
    return payloads, manifest, package_versions()


README = """# Author-only nnU-Net source and reference-config snapshot

This immutable collection preserves exact bytes read on the collection date.
It does not retrain, alter frozen results, repair NIfTI unit headers, or authorize
public release. Patient tables, mappings, fixed splits, images, checkpoints,
logs and full historical audit rows are excluded by an explicit file allowlist.

manifest.json records exact source hashes and anonymous counts comparing current
entry-script bytes with historical recorded hashes. Formal initial_script_sha256
binds the initial launcher only. Prediction and evaluator fields bind the recorded
entry file only. Helpers remain current snapshots, even where an entry matches.
No claim is made that every historical attempt used these complete dependency bytes.

config/ holds exact Dataset900 train-only reference files. Moved target plan files
have dataset-specific identities and may have different complete byte hashes.
The fingerprint includes training-derived geometry arrays: author-only retention
does not imply this material has been reviewed for public release. package_versions.json
contains selected package names and versions of the current collector interpreter;
it is not a historical environment lockfile.

SHA256SUMS.txt covers all members except itself. The ZIP uses explicit regular-file
members, fixed timestamps, sorted names, and DEFLATE level 9. It is checked for
exact inventory, byte/hash equality and CRC after creation. A separate transfer
manifest preserves generated-file bytes and exact config bytes as base64, enabling
local reconstruction using source files only when their hashes match. The transfer
manifest is also author-only. No scripts or data are executed from this archive.
"""


def finish_payloads(sources: dict[str, bytes], manifest: dict, versions: dict) -> dict[str, bytes]:
    payloads = dict(sources)
    payloads["manifest.json"] = encoded(manifest)
    payloads["package_versions.json"] = encoded(versions)
    payloads["README.md"] = README.encode("utf-8")
    sums = "".join(f"{sha(data)}  {name}\n" for name, data in sorted(payloads.items()))
    payloads["SHA256SUMS.txt"] = sums.encode("ascii")
    for name in payloads:
        safe_member(name)
    return payloads


def write_zip(path: Path, payloads: dict[str, bytes]) -> None:
    with zipfile.ZipFile(path, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name, data in sorted(payloads.items()):
            safe_member(name)
            info = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
            info.create_system = 3
            info.external_attr = (stat.S_IFREG | 0o600) << 16
            info.compress_type = zipfile.ZIP_DEFLATED
            archive.writestr(info, data, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)


def verify_zip(path: Path, payloads: dict[str, bytes]) -> None:
    with zipfile.ZipFile(path, "r") as archive:
        infos = archive.infolist()
        require(len(infos) == len(payloads) and {i.filename for i in infos} == set(payloads),
                "archive_member_inventory_mismatch")
        for info in infos:
            safe_member(info.filename)
            require(stat.S_IFMT(info.external_attr >> 16) == stat.S_IFREG,
                    "archive_nonregular_member")
            require(info.file_size == len(payloads[info.filename])
                    and archive.read(info) == payloads[info.filename], "archive_content_mismatch")
        require(archive.testzip() is None, "archive_crc_failed")


def write_snapshot(base: Path, payloads: dict[str, bytes], manifest: dict) -> dict:
    destination = base / SNAPSHOT_NAME
    archive_path = base / f"{SNAPSHOT_NAME}.zip"
    transfer_path = base / f"{SNAPSHOT_NAME}_transfer.json"
    require(all(not p.exists() and not p.is_symlink() for p in (
        destination, archive_path, transfer_path)), "snapshot_outputs_already_exist_no_overwrite")
    destination.mkdir(mode=0o700)
    for name, data in sorted(payloads.items()):
        target = destination / safe_member(name)
        target.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
        with target.open("xb") as stream:
            stream.write(data)
        os.chmod(target, 0o600)
        require(target.read_bytes() == data, "snapshot_file_verification_failed")
    write_zip(archive_path, payloads)
    os.chmod(archive_path, 0o600)
    verify_zip(archive_path, payloads)
    archive_bytes = archive_path.read_bytes()
    transfer = {
        "schema": "mnms2_nnunet_author_snapshot_transfer_v1", "status": "SNAPSHOT_ARCHIVE_VERIFIED",
        "visibility": "author_only_not_public_release_approval", "archive_name": archive_path.name,
        "archive_bytes": len(archive_bytes), "archive_sha256": sha(archive_bytes),
        "zip_recipe": {"compression": "DEFLATE", "compresslevel": 9,
                       "timestamp": [1980, 1, 1, 0, 0, 0], "create_system": 3,
                       "external_attr": (stat.S_IFREG | 0o600) << 16, "member_order": "sorted"},
        "sources": manifest["sources"], "config_summary": manifest["config_summary"],
        "historical_entry_comparison": manifest["historical_entry_comparison"],
        "members": [{"name": name, "bytes": len(data), "sha256": sha(data)}
                    for name, data in sorted(payloads.items())],
        "exact_non_runtime_members_base64": {
            name: base64.b64encode(data).decode("ascii") for name, data in sorted(payloads.items())
            if not name.startswith("scripts/")},
        "note": "Reconstruct only from exact matching source bytes plus embedded non-runtime members. DEFLATE implementations may differ: verify member bytes first, and claim identical ZIP only if its archive hash also matches.",
    }
    with transfer_path.open("xb") as stream:
        stream.write(encoded(transfer))
    os.chmod(transfer_path, 0o600)
    return {key: transfer[key] for key in ("status", "archive_name", "archive_bytes", "archive_sha256")}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, default=Path("/root/autodl-tmp"))
    parser.add_argument("--write", action="store_true", help="Create a new author-only snapshot; never overwrite")
    args = parser.parse_args()
    base = args.base.expanduser().resolve(strict=True)
    require(base.is_dir(), "base_not_directory")
    sources, manifest, versions = collect(base)
    payloads = finish_payloads(sources, manifest, versions)
    summary = {"status": "PREFLIGHT_PASS", "config_hashes_matched": 2,
               "runtime_scripts_present": manifest["present_runtime_scripts"],
               "runtime_scripts_requested": len(SCRIPTS),
               "optional_absent": [r["member"] for r in manifest["sources"] if r["status"] == "optional_absent"],
               "archive_members": len(payloads),
               "entry_comparison_counts": {key: value["counts"] for key, value in
                    manifest["historical_entry_comparison"].items() if isinstance(value, dict)}}
    print(json.dumps(summary, indent=2), flush=True)
    if not args.write:
        print("Read-only preflight complete; no files written and no training started.")
        return 0
    print(json.dumps(write_snapshot(base, payloads, manifest), indent=2), flush=True)
    print("Author-only source/config snapshot complete; no training or data mutation.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (RuntimeError, OSError, ValueError, KeyError, TypeError, UnicodeError) as error:
        # Error codes and allowlisted script names are safe; raw source/audit values
        # are never printed. Unexpected decoder details are not exposed.
        if isinstance(error, RuntimeError):
            print("SNAPSHOT FAIL: " + str(error), file=sys.stderr)
        else:
            print("SNAPSHOT FAIL: " + type(error).__name__, file=sys.stderr)
        raise SystemExit(1)
