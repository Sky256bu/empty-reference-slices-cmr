# Empty reference slices in cardiac MRI segmentation and implications for functional assessment

This source package contains the ACDC and M&Ms-2 analysis scripts in `analysis/`, exploratory checks in `audit/`, figure scripts in `figpack/`, the nnU-Net baseline in `nnunet_baseline/`, and the constant EF reference in `constant_ef/`.

The corresponding author can provide the original analysis scripts, source archives and checksum records to editors and reviewers on request. The SHA-256 values reported in the manuscript and supplement identify the original files.

Training and inference require the relevant datasets, environments and model weights. ACDC and M&Ms-2 are available from their respective challenge organisers under their access terms. The figure scripts read the required input tables from `figpack/data/` or the directory specified by `FROZEN_DATA_DIR`. Archive verification tools require the complete original archives.

See `LICENSE` and `nnunet_baseline/THIRD_PARTY_NOTICES.md` for licensing information.
