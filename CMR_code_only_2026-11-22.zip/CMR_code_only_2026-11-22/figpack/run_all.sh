#!/usr/bin/env bash
# Render every figure of the manuscript from the frozen source tables.
set -e
mkdir -p out
export FROZEN_DATA_DIR="$(cd "$(dirname "$0")/data" && pwd)"
export FIG_OUT_DIR="$(cd "$(dirname "$0")/out" && pwd)"

echo "== Fig. 1 (definitional schematic, reads no data) =="
( cd out && python3 ../make_fig1_scope_schematic.py )

echo
echo "== Fig. 2-5 (frozen source tables) =="
python3 make_figs_2_to_5.py --data data --out out

echo
echo "== Fig. 6 + Table S5/S6 (frozen tail-risk table) =="
python3 make_fig6_tableS5S6.py

echo
echo "done. outputs in out/"
ls -la out
