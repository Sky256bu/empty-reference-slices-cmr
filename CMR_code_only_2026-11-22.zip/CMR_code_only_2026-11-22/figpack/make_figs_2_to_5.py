#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
make_figs_2_to_5.py -- render Fig. 2-5 from the frozen source tables.

This is a reconstruction written to the published captions, not the original
generating script (which is not part of the released code). Every value plotted
is read from a frozen CSV; nothing is recomputed beyond the quantiles and means
the captions name. The script prints the caption-critical numbers it reproduces
so that the figures can be checked against the text.

Usage:
    python3 make_figs_2_to_5.py                 # reads ./data, writes ./out
    python3 make_figs_2_to_5.py --data D --out O

Dependencies: pandas, numpy, matplotlib
"""

import argparse
import os

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

LOW = [5, 10, 15]          # seed-dependent patient partitions
HIGH = [25, 50, 100]       # frozen nested partition
BUDGETS = LOW + HIGH

ARM_COLOR = {"A": "#1f4e79", "B": "#2e7d32", "C": "#b03030", "I": "#8a6d3b"}
GREY = "#9e9e9e"

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 8.5,
    "axes.spines.top": False,
    "axes.spines.right": False,
})


def boundary_x(xs):
    """x position of the dashed partition-regime boundary."""
    return (xs.index(15) + xs.index(25)) / 2.0


# ---------------------------------------------------------------- Fig. 2
def fig2(data, out):
    d = pd.read_csv(os.path.join(data, "step07_a6_paired_ES_ED_ABC.csv"))
    fig, ax = plt.subplots(figsize=(3.5, 3.6))
    for _, r in d.iterrows():
        high = r["N"] in HIGH
        ax.plot([0, 1], [r["ed"], r["es"]],
                color=ARM_COLOR[r["arm"]] if high else GREY,
                lw=1.0 if high else 0.7,
                alpha=0.9 if high else 0.55,
                marker="o", ms=2.6, zorder=3 if high else 2)
    ax.set_xlim(-0.22, 1.22)
    ax.set_xticks([0, 1])
    ax.set_xticklabels(["End-diastole", "End-systole"])
    ax.set_ylabel("Empty-slice penalty\n(volume-present Dice \u2212 full-stack Dice)")
    handles = [plt.Line2D([], [], color=ARM_COLOR[a], lw=1.2, label=f"arm {a}")
               for a in "ABC"]
    handles.append(plt.Line2D([], [], color=GREY, lw=1.0,
                              label="low budget (N = 5/10/15)"))
    ax.legend(handles=handles, fontsize=7, frameon=False, loc="upper left")
    fig.tight_layout()
    for e in ("pdf", "png"):
        fig.savefig(os.path.join(out, f"Fig2_empty_slice_penalty_ED_vs_ES.{e}"),
                    dpi=400, bbox_inches="tight")
    plt.close(fig)
    print(f"[Fig 2] {len(d)} cells | ES>ED in all: {(d.es_minus_ed > 0).all()} "
          f"| mean ES-ED {d.es_minus_ed.mean():.5f} "
          f"| ED {d.ed.mean():.5f} ES {d.es.mean():.5f} "
          f"ratio {d.es.mean()/d.ed.mean():.2f}")


# ---------------------------------------------------------------- Fig. 3
def fig3(data, out):
    d = pd.read_csv(os.path.join(data, "step07_BC_ranking_by_seed.csv"))
    fig, axes = plt.subplots(1, 2, figsize=(7.16, 3.4), sharey=True)
    for ax, phase, title in zip(axes, ["ed", "es"],
                                ["(a) End-diastole", "(b) End-systole"]):
        s = d[d.phase == phase].sort_values(["N", "seed"]).reset_index(drop=True)
        xs = []
        for i, (_, r) in enumerate(s.iterrows()):
            flip = bool(r["flip_volume_vs_stack"])
            ax.plot([i, i], [r["delta_BC_volume_present"], r["delta_BC_stack"]],
                    color="#c62828" if flip else "#9e9e9e",
                    lw=1.4 if flip else 0.8, zorder=2)
            ax.plot(i, r["delta_BC_volume_present"], marker="o", ms=4.2,
                    mfc="white", mec="#1f4e79", mew=1.0, zorder=3)
            ax.plot(i, r["delta_BC_stack"], marker="o", ms=4.2,
                    mfc="#1f4e79", mec="#1f4e79", zorder=3)
            xs.append((i, r["N"], r["seed"]))
        ax.axhline(0, color="#333333", lw=0.8, zorder=1)
        nlist = list(s["N"])
        b = nlist.index(25) - 0.5
        ax.axvline(b, color="#666666", lw=0.9, ls="--", zorder=1)
        ticks = [i for i, n, sd in xs if sd == 1]
        ax.set_xticks(ticks)
        ax.set_xticklabels([f"N={n}" for i, n, sd in xs if sd == 1], fontsize=7.5)
        ax.set_title(title, fontsize=9)
        ax.set_xlabel("Budget level (three seeds each)")
    axes[0].set_ylabel("Dice difference, arm B \u2212 arm C")
    handles = [
        plt.Line2D([], [], marker="o", ls="none", ms=5, mfc="white",
                   mec="#1f4e79", label="volume-present Dice"),
        plt.Line2D([], [], marker="o", ls="none", ms=5, mfc="#1f4e79",
                   mec="#1f4e79", label="full-stack Dice"),
        plt.Line2D([], [], color="#c62828", lw=1.6, label="sign of B \u2212 C changes"),
    ]
    fig.legend(handles=handles, fontsize=7.5, frameon=False, ncol=3,
               loc="upper center", bbox_to_anchor=(0.5, 1.02))
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    for e in ("pdf", "png"):
        fig.savefig(os.path.join(out, f"Fig3_arm_ordering_reversal.{e}"),
                    dpi=400, bbox_inches="tight")
    plt.close(fig)
    es = d[d.phase == "es"]
    per = {int(n): int(es[es.N == n].flip_volume_vs_stack.sum())
           for n in sorted(es.N.unique())}
    print(f"[Fig 3] ES flips by budget {per} | total flips {int(d.flip_volume_vs_stack.sum())}")


# ---------------------------------------------------------------- Fig. 4
def fig4(data, out):
    d = pd.read_csv(os.path.join(data, "Fig4_source_values.csv"))
    fig, axes = plt.subplots(1, 2, figsize=(7.16, 3.5), sharey=True)
    xs = BUDGETS
    for ax, phase, title in zip(axes, ["ed", "es"],
                                ["(a) End-diastole", "(b) End-systole"]):
        s = d[d.phase == phase]
        for arm in ["A", "B", "C", "I"]:
            a = s[s.arm == arm].set_index("N").reindex(xs)
            col = ARM_COLOR[arm]
            for grp in (LOW, HIGH):          # broken at the regime boundary
                g = a.loc[[n for n in grp if n in a.index]].dropna(subset=["p50"])
                if len(g) > 1:
                    ax.plot([xs.index(n) for n in g.index], g["p50"],
                            color=col, lw=1.1, zorder=2)
            for n in xs:
                if n not in a.index or pd.isna(a.loc[n, "p50"]):
                    continue
                i = xs.index(n)
                ax.plot([i, i], [a.loc[n, "p25"], a.loc[n, "p75"]],
                        color=col, lw=1.0, alpha=0.55, zorder=1)
                ax.plot(i, a.loc[n, "p50"], marker="o", ms=4.4,
                        mfc=col, mec=col, zorder=3)
        ax.axvline(boundary_x(xs), color="#666666", lw=0.9, ls="--", zorder=1)
        ax.set_xticks(range(len(xs)))
        ax.set_xticklabels([str(n) for n in xs])
        ax.set_xlabel("Annotation budget N (patients)")
        ax.set_title(title, fontsize=9)
    axes[0].set_ylabel("Per-case empty-slice false-positive volume (px)")
    handles = [plt.Line2D([], [], color=ARM_COLOR[a], lw=1.4, marker="o", ms=4,
                          label=f"arm {a}") for a in ["A", "B", "C", "I"]]
    fig.legend(handles=handles, fontsize=7.5, frameon=False, ncol=4,
               loc="upper center", bbox_to_anchor=(0.5, 1.02))
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    for e in ("pdf", "png"):
        fig.savefig(os.path.join(out, f"Fig4_empty_slice_fp_volume_vs_budget.{e}"),
                    dpi=400, bbox_inches="tight")
    plt.close(fig)
    ed = d[d.phase == "ed"]
    c = d[(d.phase == "es") & (d.arm == "C")]
    print(f"[Fig 4] p25 zero in every cell: {(d.p25 == 0).all()} | "
          f"ED median zero in every cell: {(ed.p50 == 0).all()} | "
          f"ES arm C median band {c.p50.min():.0f}-{c.p50.max():.0f} px")


# ---------------------------------------------------------------- Fig. 5
PANEL_HEADER = {
    "Philips + GE": "Pooled held-out domains\n\u0394 = \u22127.4919  [\u221212.8133, \u22123.0245]",
    "Philips": "Philips\n\u0394 = \u22128.0729  [\u221214.1888, \u22122.9523]",
    "GE": "GE\n\u0394 = \u22126.5272  [\u221211.1924, \u22121.9375]",
}


def fig5(data, out):
    d = pd.read_csv(os.path.join(data, "Fig5_source_values.csv"))
    panels = ["Philips + GE", "Philips", "GE"]
    fig, axes = plt.subplots(1, 3, figsize=(7.16, 4.1), sharey=True, sharex=True)
    for ax, panel in zip(axes, panels):
        s = d[d.panel == panel].sort_values("unit_id").reset_index(drop=True)
        for i, r in s.iterrows():
            worse = r["Cneg"] < r["B"]        # control attains the lower error
            col = "#c62828" if worse else "#37474f"
            ax.annotate("", xy=(r["B"], i), xytext=(r["Cneg"], i),
                        arrowprops=dict(arrowstyle="-|>", color=col, lw=1.0,
                                        mutation_scale=7), zorder=2)
            ax.plot(r["Cneg"], i, marker="o", ms=4.6, mfc="white",
                    mec=col, mew=1.1, zorder=3)
            ax.plot(r["B"], i, marker="o", ms=4.6, mfc=col, mec=col, zorder=3)
        n = len(s)
        ax.axhline(n - 0.5 + 0.5, color="#333333", lw=0.7)
        ax.plot(s["Cneg"].mean(), n + 0.4, marker="o", ms=7, mfc="white",
                mec="#000000", mew=1.6, zorder=4)
        ax.plot(s["B"].mean(), n + 0.4, marker="o", ms=7, mfc="#000000",
                mec="#000000", zorder=4)
        ax.set_yticks(list(range(n)) + [n + 0.4])
        ax.set_yticklabels(list(s["unit_id"]) + ["mean"], fontsize=7.5)
        ax.invert_yaxis()
        ax.set_title(PANEL_HEADER[panel], fontsize=7.6)
        ax.set_xlabel("Case-level EF MAE (EF points)")
    handles = [
        plt.Line2D([], [], marker="o", ls="none", ms=5, mfc="white",
                   mec="#37474f", label="arm Cneg (control)"),
        plt.Line2D([], [], marker="o", ls="none", ms=5, mfc="#37474f",
                   mec="#37474f", label="arm B (propagated)"),
        plt.Line2D([], [], color="#c62828", lw=1.4,
                   label="control attains the lower error"),
    ]
    fig.legend(handles=handles, fontsize=7.5, frameon=False, ncol=3,
               loc="upper center", bbox_to_anchor=(0.5, 1.02))
    fig.tight_layout(rect=[0, 0, 1, 0.93])
    for e in ("pdf", "png"):
        fig.savefig(os.path.join(out, f"Fig5_mnms2_per_unit_EF.{e}"),
                    dpi=400, bbox_inches="tight")
    plt.close(fig)
    for panel in panels:
        s = d[d.panel == panel]
        rev = sorted(s.loc[s.Cneg < s.B, "unit_id"])
        print(f"[Fig 5] {panel:14s} B favoured {int((s.B < s.Cneg).sum())}/{len(s)} "
              f"| mean B-Cneg {(s.B - s.Cneg).mean():+.4f} | control lower in {rev}")


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    here = os.path.dirname(os.path.abspath(__file__))
    ap.add_argument("--data", default=os.environ.get(
        "FROZEN_DATA_DIR", os.path.join(here, "data")))
    ap.add_argument("--out", default=os.environ.get(
        "FIG_OUT_DIR", os.path.join(here, "out")))
    args = ap.parse_args()
    probe = os.path.join(args.data, "Fig5_source_values.csv")
    if not os.path.exists(probe):
        raise SystemExit(f"source tables not found in {args.data}\n"
                         f"pass --data or set FROZEN_DATA_DIR")
    os.makedirs(args.out, exist_ok=True)
    fig2(args.data, args.out)
    fig3(args.data, args.out)
    fig4(args.data, args.out)
    fig5(args.data, args.out)
    print(f"\nwrote PDF and PNG for Fig. 2-5 into {args.out}/")


if __name__ == "__main__":
    main()
