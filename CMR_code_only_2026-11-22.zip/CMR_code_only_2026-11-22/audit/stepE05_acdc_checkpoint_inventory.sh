#!/usr/bin/env bash
# stepE05_acdc_checkpoint_inventory.sh
# ====================================
#
#
#
#   bash stepE05_acdc_checkpoint_inventory.sh /root/autodl-tmp /root/autodl-tmp/design_phase_quarantine
set -uo pipefail

ROOT="${1:-/root/autodl-tmp}"
OUT="${2:-/root/autodl-tmp/design_phase_quarantine}"
mkdir -p "$OUT"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
LIST="$OUT/stepE05_ckpt_inventory_${STAMP}.tsv"
SUM="$OUT/stepE05_ckpt_summary_${STAMP}.txt"


mapfile -t CKPTS < <(find "$ROOT" -type f \
  \( -name '*.pt' -o -name '*.pth' -o -name '*.ckpt' -o -name '*.safetensors' \) 2>/dev/null | sort)

printf 'path\tbucket\tsize_bytes\tmtime_utc\tarm\tN\tseed\tsha256\n' > "$LIST"
n_mnms=0; n_acdc=0; n_other=0
for f in "${CKPTS[@]}"; do
  low="${f,,}"
  if   [[ "$low" == *"/mnms"* ]]; then b="mnms2"; ((n_mnms++))
  elif [[ "$low" == *"acdc"* || "$low" == *"seg_students"* || "$low" == *"stack_dice"* ]]; then b="acdc"; ((n_acdc++))
  else b="other"; ((n_other++)); fi

  arm=$(sed -nE 's|.*[_/-](arm)?[_-]?([ABCI]\|Cneg)([_/.-].*)?$|\2|Ip' <<<"$f" | head -n1)
  Nv=$( sed -nE 's|.*[_/-]N[_-]?([0-9]+)([_/.-].*)?$|\1|Ip'            <<<"$f" | head -n1)
  sd=$( sed -nE 's|.*[_/-]s(eed)?[_-]?([0-9]+)([_/.-].*)?$|\2|Ip'      <<<"$f" | head -n1)

  sz=$(stat -c %s "$f" 2>/dev/null || echo "")
  mt=$(date -u -d "@$(stat -c %Y "$f" 2>/dev/null || echo 0)" +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || echo "")

  if [[ "$b" == "acdc" ]]; then h=$(sha256sum "$f" | awk '{print $1}'); else h=""; fi
  printf '%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n' "$f" "$b" "$sz" "$mt" "$arm" "$Nv" "$sd" "$h" >> "$LIST"
done

{
  echo
  awk -F'\t' 'NR>1 && $2=="acdc" && $5!="" && $6!="" && $7!="" {print $5"_"$6"_"$7}' "$LIST" \
    | sort -u | tee "$OUT/stepE05_acdc_cells_${STAMP}.txt" | wc -l
  echo
  echo
} | tee -a "$SUM"
