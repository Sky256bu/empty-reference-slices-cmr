"""Archive-time public aggregate verifier; not the cloud runtime source.

Uses only the Python standard library. Reads files only and writes JSON to stdout.
It reconstructs the three public CSV tables in memory from summary_aggregate.json
and the frozen Fig5 source, then verifies every field at absolute tolerance 1e-10.
It cannot recompute patient-level EF or training medians without controlled data.
"""
from pathlib import Path
import csv
import hashlib
import json
import math
import statistics
import sys

TOLERANCE = 1e-10
EXPECTED_SOURCE_SHA256 = {
    "runtime_source.py": "0b7e75b0d9b5158d42fe2099c44ed50c4b726556c0e99d90fa1bd7cee20a57e3",
    "summary_aggregate.json": "fa7890c12e472cdaf406718e47d58246f31c27467ed2865bb364b173ce0c8861",
    "constant_by_unit_vendor.csv": "4851d794fff1a45382e677c1285734336aa24edc3edcb4a3695a9d6066d1bd39",
    "model_comparison_by_unit_vendor.csv": "f7bb58a120decfbf8d2383abd99a5967a81307db7e17bc9ea52c19ea9640520c",
    "model_comparison_summary.csv": "19b4eb6690af5de85a085c1991ca31201442af043dbabd9bbcd6cfa609429523",
    "model_comparison_audit.json": "d445c61ec5e8081f0c508c3b349357f2e7f6aad41a5713cd2bbd35c3907a61bb",
    "Fig5_source_values.csv": "7e67e5f3ea50e64ccb43df50b56710984c0b0b373b37fc1f9e5d45d1d3852211",
}
VENDORS = ("All", "Philips", "GE")
UNITS = tuple(f"u{i:02d}" for i in range(10))
PATIENTS = {"All": 141, "Philips": 88, "GE": 53}
INTERPRETATION = "Descriptive paired unit aggregates only; no new CI or p-value."


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


class NumericChecks:
    def __init__(self):
        self.count = 0
        self.maximum_absolute_difference = 0.0

    def equal(self, actual, expected, context):
        actual, expected = float(actual), float(expected)
        require(math.isfinite(actual) and math.isfinite(expected), f"Nonfinite value: {context}")
        difference = abs(actual - expected)
        self.count += 1
        self.maximum_absolute_difference = max(self.maximum_absolute_difference, difference)
        require(difference <= TOLERANCE, f"Numeric mismatch {context}: {actual} vs {expected}")


def read_csv(path):
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        rows = list(reader)
        return reader.fieldnames, rows


def compare_table(base, name, expected_rows, key_columns, checks):
    fields, actual_rows = read_csv(base / name)
    require(fields == list(expected_rows[0]), f"Unexpected CSV columns: {name}")
    require(len(actual_rows) == len(expected_rows), f"Wrong row count: {name}")
    index = {}
    for row in actual_rows:
        key = tuple(row[field] for field in key_columns)
        require(key not in index, f"Duplicate CSV key: {name} {key}")
        index[key] = row
    require(set(index) == {tuple(str(row[field]) for field in key_columns) for row in expected_rows},
            f"CSV key set differs: {name}")
    for expected in expected_rows:
        key = tuple(str(expected[field]) for field in key_columns)
        actual = index[key]
        for field, value in expected.items():
            if isinstance(value, (float, int)):
                checks.equal(actual[field], value, f"{name} {key} {field}")
            else:
                require(actual[field] == value, f"Text mismatch: {name} {key} {field}")
    return len(actual_rows)


def verify_manifest(base):
    listed = set()
    for line in (base / "SHA256SUMS.txt").read_text(encoding="utf-8").splitlines():
        checksum, name = line.split("  ", 1)
        require(name and Path(name).name == name and name not in listed, "Unsafe/duplicate checksum name")
        listed.add(name)
        require(digest(base / name) == checksum, f"Archive manifest hash mismatch: {name}")
    expected_names = {p.name for p in base.iterdir() if p.is_file() and p.name != "SHA256SUMS.txt"}
    require(listed == expected_names, "Archive file inventory does not match SHA256SUMS.txt")
    return len(listed)


def main():
    base = Path(__file__).resolve().parent
    require(len(sys.argv) == 1, "Usage: python verify_public_results.py (no arguments)")
    for name, expected in EXPECTED_SOURCE_SHA256.items():
        require(digest(base / name) == expected, f"Frozen source bytes changed: {name}")
    manifest_count = verify_manifest(base)
    checks = NumericChecks()
    summary = json.loads((base / "summary_aggregate.json").read_text(encoding="utf-8"))
    audit = json.loads((base / "model_comparison_audit.json").read_text(encoding="utf-8"))
    require(summary["status"] == "PASS", "Source summary is not PASS")
    require(summary["protocol"]["test_information_used_to_fit_constant"] is False, "Unexpected fit scope")
    require(summary["protocol"]["annotation_budget_matched"] is False, "Annotation budget claim changed")
    by_unit = {row["unit"]: row for row in summary["unit_results"]}
    require(len(by_unit) == len(summary["unit_results"]) == 10 and set(by_unit) == set(UNITS), "Wrong units")
    fields, figure_rows = read_csv(base / "Fig5_source_values.csv")
    require(fields == ["unit_id", "B", "Cneg", "panel"], "Unexpected frozen Fig5 schema")
    model = {}
    panel_map = {"Philips + GE": "All", "Philips": "Philips", "GE": "GE"}
    for row in figure_rows:
        require(row["panel"] in panel_map, "Unexpected Fig5 panel")
        key = (row["unit_id"], panel_map[row["panel"]])
        require(key not in model, "Duplicate Fig5 unit/panel")
        model[key] = {arm: float(row[arm]) for arm in ("B", "Cneg")}
    require(set(model) == {(u, v) for u in UNITS for v in VENDORS}, "Wrong Fig5 cell inventory")
    constant_rows = []
    comparison_rows = []
    summary_rows = []
    s12 = []
    for unit in UNITS:
        row = by_unit[unit]
        checks.equal(row["training_patients"], 10, f"{unit} training count")
        require(0 <= row["training_reference_median_ef_pct"] <= 100, "Invalid reference constant")
        checks.equal(row["All"]["mae_pp"], sum(PATIENTS[v] * row[v]["mae_pp"] for v in ("Philips", "GE")) / 141,
                     f"{unit} constant vendor weighting")
        for arm in ("B", "Cneg"):
            checks.equal(model[(unit, "All")][arm], sum(PATIENTS[v] * model[(unit, v)][arm] for v in ("Philips", "GE")) / 141,
                         f"{unit} {arm} vendor weighting")
        for vendor in VENDORS:
            checks.equal(row[vendor]["patients"], PATIENTS[vendor], f"{unit} {vendor} patient count")
            constant_rows.append(dict(unit=unit, vendor=vendor, training_patients=10,
                                      test_patients=PATIENTS[vendor], training_median_ef_pct=row["training_reference_median_ef_pct"],
                                      constant_mae_pp=row[vendor]["mae_pp"]))
    for vendor in VENDORS:
        constants = [by_unit[u][vendor]["mae_pp"] for u in UNITS]
        aggregate = summary["aggregate"][vendor]
        for name, expected in {"units": 10, "unique_test_patients": PATIENTS[vendor],
                               "mean_unit_mae_pp": statistics.mean(constants),
                               "sample_sd_across_units_pp": statistics.stdev(constants),
                               "unit_mae_min_pp": min(constants), "unit_mae_max_pp": max(constants)}.items():
            checks.equal(aggregate[name], expected, f"Source aggregate {vendor} {name}")
        for unit in UNITS:
            constant = by_unit[unit][vendor]["mae_pp"]
            predicted = model[(unit, vendor)]
            comparison_rows.append(dict(unit=unit, vendor=vendor, constant_mae_pp=constant,
                                        B_mae_pp=predicted["B"], Cneg_mae_pp=predicted["Cneg"],
                                        B_minus_constant_pp=predicted["B"]-constant,
                                        Cneg_minus_constant_pp=predicted["Cneg"]-constant))
        for arm in ("B", "Cneg"):
            values = [model[(u, vendor)][arm] for u in UNITS]
            summary_rows.append(dict(vendor=vendor, arm=arm, units=10,
                                     model_mean_unit_mae_pp=statistics.mean(values),
                                     model_sd_across_units_pp=statistics.stdev(values),
                                     constant_mean_unit_mae_pp=statistics.mean(constants),
                                     model_minus_constant_mean_pp=statistics.mean(values)-statistics.mean(constants),
                                     units_with_lower_model_mae_than_constant=sum(x < c for x,c in zip(values,constants)),
                                     interpretation=INTERPRETATION))
        b_values = [model[(u, vendor)]["B"] for u in UNITS]
        c_values = [model[(u, vendor)]["Cneg"] for u in UNITS]
        s12.append(dict(vendor=vendor, patients=PATIENTS[vendor], units=10,
                        constant_mae_pp=statistics.mean(constants), constant_sd_pp=statistics.stdev(constants),
                        B_mae_pp=statistics.mean(b_values), Cneg_mae_pp=statistics.mean(c_values),
                        B_minus_constant_pp=statistics.mean(b_values)-statistics.mean(constants),
                        units_favoring_B=sum(x < c for x,c in zip(b_values,constants))))
    csv_counts = {
        "constant_by_unit_vendor.csv": compare_table(base, "constant_by_unit_vendor.csv", constant_rows, ("unit", "vendor"), checks),
        "model_comparison_by_unit_vendor.csv": compare_table(base, "model_comparison_by_unit_vendor.csv", comparison_rows, ("unit", "vendor"), checks),
        "model_comparison_summary.csv": compare_table(base, "model_comparison_summary.csv", summary_rows, ("vendor", "arm"), checks),
    }
    require(audit["model_aggregate_sha256"] == EXPECTED_SOURCE_SHA256["Fig5_source_values.csv"], "Audit Fig5 hash mismatch")
    require(audit["constant_summary_sha256"] == EXPECTED_SOURCE_SHA256["summary_aggregate.json"], "Audit summary hash mismatch")
    require(audit["unit_definitions_aligned"] is True and audit["vendor_weighted_overall_check"] == "PASS", "Source audit scope mismatch")
    require(len(audit["comparisons"]) == 6, "Unexpected audit comparisons")
    for row, expected in zip(audit["comparisons"], summary_rows):
        for field, value in expected.items():
            if isinstance(value, (int, float)):
                checks.equal(row[field], value, f"Audit comparison {row['vendor']} {row['arm']} {field}")
            else:
                require(row[field] == value, f"Audit text mismatch: {field}")
    expected_s12 = {"All": (12.22,3.80,10.74,18.23,7), "Philips": (11.60,4.14,9.05,17.13,8), "GE": (13.24,3.23,13.54,20.07,4)}
    for row in s12:
        observed = tuple(round(row[k],2) for k in ("constant_mae_pp","constant_sd_pp","B_mae_pp","Cneg_mae_pp")) + (row["units_favoring_B"],)
        require(observed == expected_s12[row["vendor"]], f"S12 displayed summary mismatch: {row['vendor']}")
    print(json.dumps(dict(status="PASS", helper_origin="Added at archive time; not the original cloud runtime",
                          scope="Public aggregate consistency only; no patient-level or NIfTI recomputation",
                          absolute_tolerance=TOLERANCE, numeric_checks=checks.count,
                          maximum_absolute_difference=checks.maximum_absolute_difference,
                          fixed_source_hashes_checked=len(EXPECTED_SOURCE_SHA256), manifest_members_checked=manifest_count,
                          reconstructed_csv_row_counts=csv_counts, s12_summary=s12), indent=2, allow_nan=False))


if __name__ == "__main__":
    try:
        main()
    except (ValueError, KeyError, OSError, csv.Error, json.JSONDecodeError) as error:
        print(json.dumps({"status":"FAIL", "error":str(error)}), file=sys.stderr)
        raise SystemExit(1)
