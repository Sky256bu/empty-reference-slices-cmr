# Constant EF baseline source and aggregate results

This independent archive supports the post hoc descriptive constant-predictor
reference reported in supplementary Table S12 of the cardiac MRI empty-reference
slice study. It contains anonymous training-unit and vendor aggregates, the
retained cloud computation source, and an offline aggregate consistency helper.
It contains no patient-level rows, patient identifiers, medical images, masks,
weights, credentials, cloud connection receipts, or screenshots.

## Analysis and interpretation

For each of the ten paired training units u00-u09, a separate constant prediction
was the median reference EF of that unit's ten SIEMENS training patients. That
constant was applied unchanged to the same 141 held-out patients: 88 Philips and
53 GE. The ten units were not pooled to fit a single 100-patient median. No
test-set information was used to fit the constants. Errors are in percentage
points; the constant predictions themselves are EF percentages.

| Evaluation group | Patients | Constant EF-MAE | SD across units | B EF-MAE | Cneg EF-MAE | Units favoring B over constant |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| All | 141 | 12.22 | 3.80 | 10.74 | 18.23 | 7/10 |
| Philips | 88 | 11.60 | 4.14 | 9.05 | 17.13 | 8/10 |
| GE | 53 | 13.24 | 3.23 | 13.54 | 20.07 | 4/10 |

These are means across ten training units. SD is the sample standard deviation
across units, not a confidence interval. B/Cneg values are the frozen original
lightweight-model results averaged over three runs per unit. The constants are
deterministic single calculations. B minus constant is -1.48 overall, -2.55 for
Philips, and +0.29 for GE, computed before rounding. This comparison is post hoc
and descriptive. Complete training-reference EF supplies more information than
the matched sparse segmentation-annotation budget; it is not a new comparison
with equal annotation costs. No new confidence interval or significance test is
reported, and the original B-versus-Cneg interval/p-value does not apply to this
reference. This baseline does not resolve undefined EF in the separate nnU-Net
experiment or establish clinical acceptability.

## File inventory

- `runtime_source.py`: byte-preserved retained source of the original cloud
  reference-EF/constant-baseline computation. It requires controlled cloud inputs
  and NumPy/nibabel. It does not create the three public comparison CSVs.
- `summary_aggregate.json`: byte-preserved archived cloud-derived anonymous
  results: ten training medians, vendor MAEs, cohort/geometry audits and hashes.
- `constant_by_unit_vendor.csv`: 30 anonymous unit/vendor constant results.
- `model_comparison_by_unit_vendor.csv`: 30 descriptive unit/vendor comparisons
  against frozen original B/Cneg values.
- `model_comparison_summary.csv`: six vendor/arm aggregate comparisons.
- `model_comparison_audit.json`: retained local comparison provenance and audit.
- `Fig5_source_values.csv`: byte-preserved frozen original lightweight-model
  figure-source table. Its rows are unit aggregates, not individual patients.
- `verify_public_results.py`: NEW archive-time standard-library helper. It is
  separate from `runtime_source.py` and is not historical execution evidence.
- `PROVENANCE.json`: source identities, archival handling and scope limits.
- `SHA256SUMS.txt`: SHA-256 of the ten other archive members.

Existing source bytes are preserved, including historical local/cloud path
strings in source/audit records. Paths do not provide access to the controlled
inputs. Current file hashes identify retained files; they do not by themselves
prove contemporaneous execution or close earlier model-weight provenance gaps.

## Offline aggregate verification

Extract this directory and run with Python 3.8 or newer:

```console
python verify_public_results.py
```

The helper uses only the Python standard library, reads files without changing
them, and prints a JSON PASS/FAIL result. It verifies the seven fixed source
SHA-256 identities and the full SHA256SUMS file inventory. From the archived
anonymous summary and frozen Fig5 source it reconstructs all three public CSVs
in memory and checks their schemas, keys and every numeric value at absolute
tolerance 1e-10 (no relative tolerance). It recomputes group means, sample SDs,
vendor weighting, model-minus-constant differences and direction counts, and
checks the displayed S12 group summaries. It also checks comparison-audit
numbers. It performs no inference, fitting, training, or new significance test.

This is aggregate-level verification, not an independent recomputation of EF
from NIfTI data. Training medians and per-unit constant MAEs enter through the
retained summary and cannot be regenerated from this public archive alone.

## Repeating the controlled cloud computation

`runtime_source.py` is preserved rather than rewritten as a public turnkey
pipeline. Inspect it before use; on an authorized cloud environment it reads:

- `/root/autodl-tmp/mnms/seg_lv/manifest_mnms2.csv`
- `/root/autodl-tmp/mnms/seg_lv/scope_control_v3_zero_gpu_audit/patient_partitions_v3.csv`
- `/root/autodl-tmp/nnUNet_external_evaluation/rep00/private/case_metrics_PRIVATE.csv`
- `/root/autodl-tmp/mnms/seg_lv/scope_control_v3_zero_gpu_audit/input_file_manifest_v3.csv`
- 482 reference NIfTI files under
  `/root/autodl-tmp/mnms/MnM2/dataset/<key>/<key>_SA_ED_gt.nii.gz` and the ES analogue.

Those controlled data and patient mappings are not included. Repeating the
source therefore requires authorized access to the original M&Ms-2 data and
retained study-specific manifests/partitions/evaluation records, with the frozen
identities declared in the source and summary. Dataset access remains governed
by the original organizers' terms. Do not interpret this package as granting
permission to redistribute the original data.

The source checks fixed input hashes, training/test separation, complete-stack
foreground counts and ED/ES numeric voxel factors, and recomputes reference EF
as `100 * (1 - N_ES/N_ED)` when the factors agree. The retained audit covers 241
patients: 100 training plus 141 held-out; 282 held-out GT files match retained
historical physical-file hashes. The 200 training GT files have current recorded
identities but must not be described as having all matched historical hashes.
Unknown NIfTI spatial units do not establish physical mL calibration. The
count-ratio EF computation does not replace an independent anatomical/phase
review, which was not performed here.

The retained runtime prints its result; the summary and the three comparison
CSVs are archived results, not files emitted directly by that source. The
runtime's original `ef_unit` metadata label was later clarified in the archived
summary to distinguish `reference_ef_unit=percent` and
`error_unit=percentage points`. The summary also retains subsequent audit/source
linkage fields. This documented metadata handling did not change numeric
results; the archived source and summary each keep their fixed byte identity.

## Provenance and archive verification

See `PROVENANCE.json` for fixed source hashes. The adjacent ZIP checksum file
identifies this exact distribution artifact; `SHA256SUMS.txt` identifies its
member files. Neither creates retrospective evidence for an unrecorded earlier
run. No repository was published or modified while preparing this archive.
