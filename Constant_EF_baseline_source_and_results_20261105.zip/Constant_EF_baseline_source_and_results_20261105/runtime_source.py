from pathlib import Path
from collections import defaultdict, Counter
import csv, hashlib, json, math, statistics
import numpy as np
import nibabel as nib
BASE = Path('/root/autodl-tmp')
PATHS = {'manifest':BASE/'mnms/seg_lv/manifest_mnms2.csv','partitions':BASE/'mnms/seg_lv/scope_control_v3_zero_gpu_audit/patient_partitions_v3.csv','cases':BASE/'nnUNet_external_evaluation/rep00/private/case_metrics_PRIVATE.csv','physical':BASE/'mnms/seg_lv/scope_control_v3_zero_gpu_audit/input_file_manifest_v3.csv'}
EXPECTED = {'manifest':'fd9f2eba74f0adba7eff7a11c80e856d49e9aebcdcda17920f4e491d2e7f7a24','partitions':'30b0f21fb0e75e969f1e3fc109dc480b5f4e2c70e9e1a4d5dcf4316da8b78e82','cases':'ad1a0ec6de7c7aa16aa492b27288dcc9bae285574bf26ead6c5a85c0019f23d0'}
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def rows(p):
    with p.open(newline='', encoding='utf-8-sig') as f: return list(csv.DictReader(f))
def key(s): return str(s).strip().zfill(3)
def vendor(s):
    s=s.lower()
    if 'siemens' in s: return 'SIEMENS'
    if 'philips' in s: return 'Philips'
    if s.startswith('ge') or 'general electric' in s: return 'GE'
    raise ValueError('Unrecognised vendor')
source_hashes={n:digest(p) for n,p in PATHS.items()}
assert all(source_hashes[n]==h for n,h in EXPECTED.items()), 'Frozen input hash mismatch'
manifest=rows(PATHS['manifest']); partitions=rows(PATHS['partitions']); cases=rows(PATHS['cases'])
assert len(manifest)==8128 and len(partitions)==219 and len(cases)==2820
units=[f'u{i:02d}' for i in range(10)]
train={u:{key(r['key']) for r in partitions if r['block_id']==u} for u in units}
assert all(len(v)==10 for v in train.values())
train_keys=set.union(*train.values()); assert len(train_keys)==100
test={}; repetitions=Counter(); model_sets=defaultdict(set)
for r in cases:
    k=key(r['patient_key']); v=vendor(r['vendor']); ef=float(r['ef_gt_pct'])
    assert math.isfinite(ef)
    if k in test:
        assert test[k]['vendor']==v and math.isclose(test[k]['ef'],ef,rel_tol=1e-12,abs_tol=1e-10)
    else: test[k]={'vendor':v,'ef':ef}
    repetitions[k]+=1; model_sets[k].add((r['unit'],r['arm']))
expected_models={(u,a) for u in units for a in ['B','Cneg']}
assert len(test)==141 and not train_keys.intersection(test)
assert Counter(x['vendor'] for x in test.values())=={'Philips':88,'GE':53}
assert set(repetitions.values())=={20} and all(x==expected_models for x in model_sets.values())
selected=train_keys|set(test); by_phase=defaultdict(dict); vendors={}
for r in manifest:
    k=key(r['key'])
    if k not in selected: continue
    phase=r['phase'].lower(); z=int(r['z']); v=vendor(r['vendor'])
    assert phase in ['ed','es'] and z not in by_phase[(k,phase)]
    by_phase[(k,phase)][z]=int(r['gt_px'])
    if k in vendors: assert vendors[k]==v
    vendors[k]=v
assert all(vendors[k]=='SIEMENS' for k in train_keys)
assert all(vendors[k]==test[k]['vendor'] for k in test)
physical={r['absolute_path']:r['sha256'] for r in rows(PATHS['physical'])}
current_gt_hashes=[]; matched_frozen=0; header_units=Counter(); equal_factors=0; reference={}; max_stored_gt_difference=0.0
for index,k in enumerate(sorted(selected),1):
    counts={}; factors={}
    for phase in ['ed','es']:
        p=BASE/'mnms/MnM2/dataset'/k/f'{k}_SA_{phase.upper()}_gt.nii.gz'
        h=digest(p); current_gt_hashes.append((str(p),h))
        if str(p) in physical:
            assert physical[str(p)]==h, 'Current GT differs from frozen physical record'
            matched_frozen+=1
        img=nib.load(p); array=np.asanyarray(img.dataobj)
        assert array.ndim==3
        slice_counts=np.count_nonzero(array==1,axis=(0,1)).astype(np.int64)
        frozen_counts=by_phase[(k,phase)]
        assert set(frozen_counts)==set(range(len(slice_counts))), 'Manifest does not cover complete GT stack'
        assert all(frozen_counts[z]==int(n) for z,n in enumerate(slice_counts)), 'Frozen per-slice foreground counts disagree with current full GT'
        counts[phase]=int(slice_counts.sum()); factors[phase]=abs(float(np.linalg.det(img.affine[:3,:3])))
        assert math.isfinite(factors[phase]) and factors[phase]>0
        header_units[str(img.header.get_xyzt_units()[0])]+=1
    assert counts['ed']>0 and counts['es']>=0
    assert math.isclose(factors['ed'],factors['es'],rel_tol=1e-12,abs_tol=0.0), 'Unequal ED/ES numeric voxel factors: count ratio is not eligible'
    equal_factors+=1
    ef=100.0*(1.0-counts['es']/counts['ed']); assert math.isfinite(ef)
    reference[k]=ef
    if k in test:
        difference=abs(ef-test[k]['ef']); max_stored_gt_difference=max(max_stored_gt_difference,difference)
        assert difference<=1e-8, 'Recomputed GT EF differs from frozen case table'
    if index%50==0: print(f'GT_REFERENCE_CHECK {index}/{len(selected)}',flush=True)
unit_results=[]
for u in units:
    constant=statistics.median(reference[k] for k in train[u])
    row={'unit':u,'training_patients':10,'training_reference_median_ef_pct':constant}
    for v in ['All','Philips','GE']:
        errors=[abs(constant-reference[k]) for k in test if v=='All' or test[k]['vendor']==v]
        row[v]={'patients':len(errors),'mae_pp':statistics.mean(errors)}
    assert math.isclose(row['All']['mae_pp'],(88*row['Philips']['mae_pp']+53*row['GE']['mae_pp'])/141,abs_tol=1e-10)
    unit_results.append(row)
aggregate={}
for v in ['All','Philips','GE']:
    values=[r[v]['mae_pp'] for r in unit_results]
    aggregate[v]={'units':10,'unique_test_patients':141 if v=='All' else (88 if v=='Philips' else 53),'mean_unit_mae_pp':statistics.mean(values),'sample_sd_across_units_pp':statistics.stdev(values),'unit_mae_min_pp':min(values),'unit_mae_max_pp':max(values)}
result={'status':'PASS','analysis':'POST_HOC_TRAINING_REFERENCE_EF_MEDIAN_CONSTANT_BASELINE','protocol':{'prediction':'Separate constant for each unit: median of its ten SIEMENS training patients reference EF; applied unchanged to all 141 held-out patients.','test_information_used_to_fit_constant':False,'annotation_budget_matched':False,'training_information':'Complete training reference EF, beyond sparse segmentation labels; a descriptive distribution baseline.','repeats':'Deterministic; no model training and no added stochastic repeats.','source_ed_es_labels':'Dataset-supplied; no new independent clinical phase review.','ef_unit':'percentage points','absolute_volume_claim':False},'source_sha256':source_hashes,'audit':{'training_unique_patients':100,'test_unique_patients':141,'test_gt_duplicate_rows_checked':2820,'gt_nifti_files_recounted':len(current_gt_hashes),'gt_files_matching_frozen_physical_hashes':matched_frozen,'gt_file_inventory_sha256':hashlib.sha256(json.dumps(current_gt_hashes,separators=(',',':')).encode()).hexdigest(),'complete_stack_and_frozen_slice_counts_checked':len(current_gt_hashes),'patients_with_equal_ed_es_numeric_voxel_factors':equal_factors,'nifti_spatial_unit_counts':dict(header_units),'maximum_reference_ef_difference_from_frozen_test_table_pp':max_stored_gt_difference,'reference_ef_outside_0_to_100_count':sum(not 0<=ef<=100 for ef in reference.values())},'unit_results':unit_results,'aggregate':aggregate}
print('CONSTANT_EF_BASELINE_RESULT_BEGIN')
print(json.dumps(result,indent=2,allow_nan=False))
print('CONSTANT_EF_BASELINE_RESULT_END')